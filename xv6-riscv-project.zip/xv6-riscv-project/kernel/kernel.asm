
kernel/kernel:     file format elf64-littleriscv


Disassembly of section .text:

0000000080000000 <_entry>:
_entry:
        # set up a stack for C.
        # stack0 is declared in start.c,
        # with a 4096-byte stack per CPU.
        # sp = stack0 + ((hartid + 1) * 4096)
        la sp, stack0
    80000000:	0000a117          	auipc	sp,0xa
    80000004:	2e813103          	ld	sp,744(sp) # 8000a2e8 <_GLOBAL_OFFSET_TABLE_+0x8>
        li a0, 1024*4
    80000008:	6505                	lui	a0,0x1
        csrr a1, mhartid
    8000000a:	f14025f3          	csrr	a1,mhartid
        addi a1, a1, 1
    8000000e:	0585                	addi	a1,a1,1
        mul a0, a0, a1
    80000010:	02b50533          	mul	a0,a0,a1
        add sp, sp, a0
    80000014:	912a                	add	sp,sp,a0
        # jump to start() in start.c
        call start
    80000016:	042000ef          	jal	80000058 <start>

000000008000001a <spin>:
spin:
        j spin
    8000001a:	a001                	j	8000001a <spin>

000000008000001c <timerinit>:
}

// ask each hart to generate timer interrupts.
void
timerinit()
{
    8000001c:	1141                	addi	sp,sp,-16
    8000001e:	e406                	sd	ra,8(sp)
    80000020:	e022                	sd	s0,0(sp)
    80000022:	0800                	addi	s0,sp,16
static inline uint64
r_menvcfg()
{
  uint64 x;
  // asm volatile("csrr %0, menvcfg" : "=r" (x) );
  asm volatile("csrr %0, 0x30a" : "=r"(x));
    80000024:	30a027f3          	csrr	a5,0x30a
  // enable the sstc extension (i.e. stimecmp).
  w_menvcfg(r_menvcfg() | MENVCFG_STCE);
    80000028:	577d                	li	a4,-1
    8000002a:	177e                	slli	a4,a4,0x3f
    8000002c:	8fd9                	or	a5,a5,a4

static inline void
w_menvcfg(uint64 x)
{
  // asm volatile("csrw menvcfg, %0" : : "r" (x));
  asm volatile("csrw 0x30a, %0" : : "r"(x));
    8000002e:	30a79073          	csrw	0x30a,a5

static inline uint64
r_mcounteren()
{
  uint64 x;
  asm volatile("csrr %0, mcounteren" : "=r"(x));
    80000032:	306027f3          	csrr	a5,mcounteren

  // allow supervisor to use stimecmp and time.
  w_mcounteren(r_mcounteren() | 2);
    80000036:	0027e793          	ori	a5,a5,2
  asm volatile("csrw mcounteren, %0" : : "r"(x));
    8000003a:	30679073          	csrw	mcounteren,a5
// machine-mode cycle counter
static inline uint64
r_time()
{
  uint64 x;
  asm volatile("csrr %0, time" : "=r"(x));
    8000003e:	c01027f3          	rdtime	a5

  // ask for the very first timer interrupt.
  w_stimecmp(r_time() + 1000000);
    80000042:	000f4737          	lui	a4,0xf4
    80000046:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    8000004a:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r"(x));
    8000004c:	14d79073          	csrw	stimecmp,a5
}
    80000050:	60a2                	ld	ra,8(sp)
    80000052:	6402                	ld	s0,0(sp)
    80000054:	0141                	addi	sp,sp,16
    80000056:	8082                	ret

0000000080000058 <start>:
{
    80000058:	1141                	addi	sp,sp,-16
    8000005a:	e406                	sd	ra,8(sp)
    8000005c:	e022                	sd	s0,0(sp)
    8000005e:	0800                	addi	s0,sp,16
  asm volatile("csrr %0, mstatus" : "=r"(x));
    80000060:	300027f3          	csrr	a5,mstatus
  x &= ~MSTATUS_MPP_MASK;
    80000064:	7779                	lui	a4,0xffffe
    80000066:	7ff70713          	addi	a4,a4,2047 # ffffffffffffe7ff <end+0xffffffff7ffdb1af>
    8000006a:	8ff9                	and	a5,a5,a4
  x |= MSTATUS_MPP_S;
    8000006c:	6705                	lui	a4,0x1
    8000006e:	80070713          	addi	a4,a4,-2048 # 800 <_entry-0x7ffff800>
    80000072:	8fd9                	or	a5,a5,a4
  asm volatile("csrw mstatus, %0" : : "r"(x));
    80000074:	30079073          	csrw	mstatus,a5
  asm volatile("csrw mepc, %0" : : "r"(x));
    80000078:	00001797          	auipc	a5,0x1
    8000007c:	de678793          	addi	a5,a5,-538 # 80000e5e <main>
    80000080:	34179073          	csrw	mepc,a5
  asm volatile("csrw satp, %0" : : "r"(x));
    80000084:	4781                	li	a5,0
    80000086:	18079073          	csrw	satp,a5
  asm volatile("csrw medeleg, %0" : : "r"(x));
    8000008a:	67c1                	lui	a5,0x10
    8000008c:	17fd                	addi	a5,a5,-1 # ffff <_entry-0x7fff0001>
    8000008e:	30279073          	csrw	medeleg,a5
  asm volatile("csrw mideleg, %0" : : "r"(x));
    80000092:	30379073          	csrw	mideleg,a5
  asm volatile("csrr %0, sie" : "=r"(x));
    80000096:	104027f3          	csrr	a5,sie
  w_sie(r_sie() | SIE_SEIE | SIE_STIE);
    8000009a:	2207e793          	ori	a5,a5,544
  asm volatile("csrw sie, %0" : : "r"(x));
    8000009e:	10479073          	csrw	sie,a5
  asm volatile("csrw pmpaddr0, %0" : : "r"(x));
    800000a2:	57fd                	li	a5,-1
    800000a4:	83a9                	srli	a5,a5,0xa
    800000a6:	3b079073          	csrw	pmpaddr0,a5
  asm volatile("csrw pmpcfg0, %0" : : "r"(x));
    800000aa:	47bd                	li	a5,15
    800000ac:	3a079073          	csrw	pmpcfg0,a5
  asm volatile("csrr %0, 0x30a" : "=r"(x));
    800000b0:	30a027f3          	csrr	a5,0x30a
  w_menvcfg(r_menvcfg() | MENVCFG_ADUE);
    800000b4:	4705                	li	a4,1
    800000b6:	1776                	slli	a4,a4,0x3d
    800000b8:	8fd9                	or	a5,a5,a4
  asm volatile("csrw 0x30a, %0" : : "r"(x));
    800000ba:	30a79073          	csrw	0x30a,a5
  timerinit();
    800000be:	f5fff0ef          	jal	8000001c <timerinit>
  asm volatile("csrr %0, mhartid" : "=r"(x));
    800000c2:	f14027f3          	csrr	a5,mhartid
  w_tp(id);
    800000c6:	2781                	sext.w	a5,a5
}

static inline void
w_tp(uint64 x)
{
  asm volatile("mv tp, %0" : : "r"(x));
    800000c8:	823e                	mv	tp,a5
  asm volatile("mret");
    800000ca:	30200073          	mret
}
    800000ce:	60a2                	ld	ra,8(sp)
    800000d0:	6402                	ld	s0,0(sp)
    800000d2:	0141                	addi	sp,sp,16
    800000d4:	8082                	ret

00000000800000d6 <consolewrite>:
// user write() system calls to the console go here.
// uses sleep() and UART interrupts.
//
int
consolewrite(int user_src, uint64 src, int n)
{
    800000d6:	7119                	addi	sp,sp,-128
    800000d8:	fc86                	sd	ra,120(sp)
    800000da:	f8a2                	sd	s0,112(sp)
    800000dc:	f4a6                	sd	s1,104(sp)
    800000de:	0100                	addi	s0,sp,128
  char buf[32]; // move batches from user space to uart.
  int i = 0;

  while (i < n) {
    800000e0:	06c05b63          	blez	a2,80000156 <consolewrite+0x80>
    800000e4:	f0ca                	sd	s2,96(sp)
    800000e6:	ecce                	sd	s3,88(sp)
    800000e8:	e8d2                	sd	s4,80(sp)
    800000ea:	e4d6                	sd	s5,72(sp)
    800000ec:	e0da                	sd	s6,64(sp)
    800000ee:	fc5e                	sd	s7,56(sp)
    800000f0:	f862                	sd	s8,48(sp)
    800000f2:	f466                	sd	s9,40(sp)
    800000f4:	f06a                	sd	s10,32(sp)
    800000f6:	8b2a                	mv	s6,a0
    800000f8:	8bae                	mv	s7,a1
    800000fa:	8a32                	mv	s4,a2
  int i = 0;
    800000fc:	4481                	li	s1,0
    int nn = sizeof(buf);
    if (nn > n - i)
    800000fe:	02000c93          	li	s9,32
    80000102:	02000d13          	li	s10,32
      nn = n - i;
    if (either_copyin(buf, user_src, src + i, nn) == -1)
    80000106:	f8040a93          	addi	s5,s0,-128
    8000010a:	5c7d                	li	s8,-1
    8000010c:	a025                	j	80000134 <consolewrite+0x5e>
    if (nn > n - i)
    8000010e:	0009099b          	sext.w	s3,s2
    if (either_copyin(buf, user_src, src + i, nn) == -1)
    80000112:	86ce                	mv	a3,s3
    80000114:	01748633          	add	a2,s1,s7
    80000118:	85da                	mv	a1,s6
    8000011a:	8556                	mv	a0,s5
    8000011c:	1d4020ef          	jal	800022f0 <either_copyin>
    80000120:	03850d63          	beq	a0,s8,8000015a <consolewrite+0x84>
      break;
    uartwrite(buf, nn);
    80000124:	85ce                	mv	a1,s3
    80000126:	8556                	mv	a0,s5
    80000128:	7c2000ef          	jal	800008ea <uartwrite>
    i += nn;
    8000012c:	009904bb          	addw	s1,s2,s1
  while (i < n) {
    80000130:	0144d963          	bge	s1,s4,80000142 <consolewrite+0x6c>
    if (nn > n - i)
    80000134:	409a07bb          	subw	a5,s4,s1
    80000138:	893e                	mv	s2,a5
    8000013a:	fcfcdae3          	bge	s9,a5,8000010e <consolewrite+0x38>
    8000013e:	896a                	mv	s2,s10
    80000140:	b7f9                	j	8000010e <consolewrite+0x38>
    80000142:	7906                	ld	s2,96(sp)
    80000144:	69e6                	ld	s3,88(sp)
    80000146:	6a46                	ld	s4,80(sp)
    80000148:	6aa6                	ld	s5,72(sp)
    8000014a:	6b06                	ld	s6,64(sp)
    8000014c:	7be2                	ld	s7,56(sp)
    8000014e:	7c42                	ld	s8,48(sp)
    80000150:	7ca2                	ld	s9,40(sp)
    80000152:	7d02                	ld	s10,32(sp)
    80000154:	a821                	j	8000016c <consolewrite+0x96>
  int i = 0;
    80000156:	4481                	li	s1,0
    80000158:	a811                	j	8000016c <consolewrite+0x96>
    8000015a:	7906                	ld	s2,96(sp)
    8000015c:	69e6                	ld	s3,88(sp)
    8000015e:	6a46                	ld	s4,80(sp)
    80000160:	6aa6                	ld	s5,72(sp)
    80000162:	6b06                	ld	s6,64(sp)
    80000164:	7be2                	ld	s7,56(sp)
    80000166:	7c42                	ld	s8,48(sp)
    80000168:	7ca2                	ld	s9,40(sp)
    8000016a:	7d02                	ld	s10,32(sp)
  }

  return i;
}
    8000016c:	8526                	mv	a0,s1
    8000016e:	70e6                	ld	ra,120(sp)
    80000170:	7446                	ld	s0,112(sp)
    80000172:	74a6                	ld	s1,104(sp)
    80000174:	6109                	addi	sp,sp,128
    80000176:	8082                	ret

0000000080000178 <consoleread>:
// user_dst indicates whether dst is a user
// or kernel address.
//
int
consoleread(int user_dst, uint64 dst, int n)
{
    80000178:	711d                	addi	sp,sp,-96
    8000017a:	ec86                	sd	ra,88(sp)
    8000017c:	e8a2                	sd	s0,80(sp)
    8000017e:	e4a6                	sd	s1,72(sp)
    80000180:	e0ca                	sd	s2,64(sp)
    80000182:	fc4e                	sd	s3,56(sp)
    80000184:	f852                	sd	s4,48(sp)
    80000186:	f05a                	sd	s6,32(sp)
    80000188:	ec5e                	sd	s7,24(sp)
    8000018a:	1080                	addi	s0,sp,96
    8000018c:	8b2a                	mv	s6,a0
    8000018e:	8a2e                	mv	s4,a1
    80000190:	89b2                	mv	s3,a2
  uint target;
  int c;
  char cbuf;

  target = n;
    80000192:	8bb2                	mv	s7,a2
  acquire(&cons.lock);
    80000194:	00012517          	auipc	a0,0x12
    80000198:	19c50513          	addi	a0,a0,412 # 80012330 <cons>
    8000019c:	24d000ef          	jal	80000be8 <acquire>
  while (n > 0) {
    // wait until interrupt handler has put some
    // input into cons.buffer.
    while (cons.r == cons.w) {
    800001a0:	00012497          	auipc	s1,0x12
    800001a4:	19048493          	addi	s1,s1,400 # 80012330 <cons>
      if (killed(myproc())) {
        release(&cons.lock);
        return -1;
      }
      sleep_prepare(&cons.r);
    800001a8:	00012917          	auipc	s2,0x12
    800001ac:	22090913          	addi	s2,s2,544 # 800123c8 <cons+0x98>
  while (n > 0) {
    800001b0:	0d305263          	blez	s3,80000274 <consoleread+0xfc>
    while (cons.r == cons.w) {
    800001b4:	0984a783          	lw	a5,152(s1)
    800001b8:	09c4a703          	lw	a4,156(s1)
    800001bc:	0af71763          	bne	a4,a5,8000026a <consoleread+0xf2>
      if (killed(myproc())) {
    800001c0:	748010ef          	jal	80001908 <myproc>
    800001c4:	7ad010ef          	jal	80002170 <killed>
    800001c8:	e925                	bnez	a0,80000238 <consoleread+0xc0>
      sleep_prepare(&cons.r);
    800001ca:	854a                	mv	a0,s2
    800001cc:	547010ef          	jal	80001f12 <sleep_prepare>
      release(&cons.lock);
    800001d0:	8526                	mv	a0,s1
    800001d2:	29f000ef          	jal	80000c70 <release>
      sleep();
    800001d6:	579010ef          	jal	80001f4e <sleep>
      acquire(&cons.lock);
    800001da:	8526                	mv	a0,s1
    800001dc:	20d000ef          	jal	80000be8 <acquire>
    while (cons.r == cons.w) {
    800001e0:	0984a783          	lw	a5,152(s1)
    800001e4:	09c4a703          	lw	a4,156(s1)
    800001e8:	fcf70ce3          	beq	a4,a5,800001c0 <consoleread+0x48>
    800001ec:	f456                	sd	s5,40(sp)
    }

    c = cons.buf[cons.r++ % INPUT_BUF_SIZE];
    800001ee:	00012717          	auipc	a4,0x12
    800001f2:	14270713          	addi	a4,a4,322 # 80012330 <cons>
    800001f6:	0017869b          	addiw	a3,a5,1
    800001fa:	08d72c23          	sw	a3,152(a4)
    800001fe:	07f7f693          	andi	a3,a5,127
    80000202:	9736                	add	a4,a4,a3
    80000204:	01874703          	lbu	a4,24(a4)
    80000208:	00070a9b          	sext.w	s5,a4

    if (c == C('D')) { // end-of-file
    8000020c:	4691                	li	a3,4
    8000020e:	04da8663          	beq	s5,a3,8000025a <consoleread+0xe2>
      }
      break;
    }

    // copy the input byte to the user-space buffer.
    cbuf = c;
    80000212:	fae407a3          	sb	a4,-81(s0)
    if (either_copyout(user_dst, dst, &cbuf, 1) == -1)
    80000216:	4685                	li	a3,1
    80000218:	faf40613          	addi	a2,s0,-81
    8000021c:	85d2                	mv	a1,s4
    8000021e:	855a                	mv	a0,s6
    80000220:	084020ef          	jal	800022a4 <either_copyout>
    80000224:	57fd                	li	a5,-1
    80000226:	04f50663          	beq	a0,a5,80000272 <consoleread+0xfa>
      break;

    dst++;
    8000022a:	0a05                	addi	s4,s4,1
    --n;
    8000022c:	39fd                	addiw	s3,s3,-1

    if (c == '\n') {
    8000022e:	47a9                	li	a5,10
    80000230:	04fa8b63          	beq	s5,a5,80000286 <consoleread+0x10e>
    80000234:	7aa2                	ld	s5,40(sp)
    80000236:	bfad                	j	800001b0 <consoleread+0x38>
        release(&cons.lock);
    80000238:	00012517          	auipc	a0,0x12
    8000023c:	0f850513          	addi	a0,a0,248 # 80012330 <cons>
    80000240:	231000ef          	jal	80000c70 <release>
        return -1;
    80000244:	557d                	li	a0,-1
    }
  }
  release(&cons.lock);

  return target - n;
}
    80000246:	60e6                	ld	ra,88(sp)
    80000248:	6446                	ld	s0,80(sp)
    8000024a:	64a6                	ld	s1,72(sp)
    8000024c:	6906                	ld	s2,64(sp)
    8000024e:	79e2                	ld	s3,56(sp)
    80000250:	7a42                	ld	s4,48(sp)
    80000252:	7b02                	ld	s6,32(sp)
    80000254:	6be2                	ld	s7,24(sp)
    80000256:	6125                	addi	sp,sp,96
    80000258:	8082                	ret
      if (n < target) {
    8000025a:	0179fa63          	bgeu	s3,s7,8000026e <consoleread+0xf6>
        cons.r--;
    8000025e:	00012717          	auipc	a4,0x12
    80000262:	16f72523          	sw	a5,362(a4) # 800123c8 <cons+0x98>
    80000266:	7aa2                	ld	s5,40(sp)
    80000268:	a031                	j	80000274 <consoleread+0xfc>
    8000026a:	f456                	sd	s5,40(sp)
    8000026c:	b749                	j	800001ee <consoleread+0x76>
    8000026e:	7aa2                	ld	s5,40(sp)
    80000270:	a011                	j	80000274 <consoleread+0xfc>
    80000272:	7aa2                	ld	s5,40(sp)
  release(&cons.lock);
    80000274:	00012517          	auipc	a0,0x12
    80000278:	0bc50513          	addi	a0,a0,188 # 80012330 <cons>
    8000027c:	1f5000ef          	jal	80000c70 <release>
  return target - n;
    80000280:	413b853b          	subw	a0,s7,s3
    80000284:	b7c9                	j	80000246 <consoleread+0xce>
    80000286:	7aa2                	ld	s5,40(sp)
    80000288:	b7f5                	j	80000274 <consoleread+0xfc>

000000008000028a <consputc>:
{
    8000028a:	1141                	addi	sp,sp,-16
    8000028c:	e406                	sd	ra,8(sp)
    8000028e:	e022                	sd	s0,0(sp)
    80000290:	0800                	addi	s0,sp,16
  if (c == BACKSPACE) {
    80000292:	10000793          	li	a5,256
    80000296:	00f50863          	beq	a0,a5,800002a6 <consputc+0x1c>
    uartputc_sync(c);
    8000029a:	6d6000ef          	jal	80000970 <uartputc_sync>
}
    8000029e:	60a2                	ld	ra,8(sp)
    800002a0:	6402                	ld	s0,0(sp)
    800002a2:	0141                	addi	sp,sp,16
    800002a4:	8082                	ret
    uartputc_sync('\b');
    800002a6:	4521                	li	a0,8
    800002a8:	6c8000ef          	jal	80000970 <uartputc_sync>
    uartputc_sync(' ');
    800002ac:	02000513          	li	a0,32
    800002b0:	6c0000ef          	jal	80000970 <uartputc_sync>
    uartputc_sync('\b');
    800002b4:	4521                	li	a0,8
    800002b6:	6ba000ef          	jal	80000970 <uartputc_sync>
    800002ba:	b7d5                	j	8000029e <consputc+0x14>

00000000800002bc <consoleintr>:
// do erase/kill processing, append to cons.buf,
// wake up consoleread() if a whole line has arrived.
//
void
consoleintr(int c)
{
    800002bc:	1101                	addi	sp,sp,-32
    800002be:	ec06                	sd	ra,24(sp)
    800002c0:	e822                	sd	s0,16(sp)
    800002c2:	e426                	sd	s1,8(sp)
    800002c4:	1000                	addi	s0,sp,32
    800002c6:	84aa                	mv	s1,a0
  acquire(&cons.lock);
    800002c8:	00012517          	auipc	a0,0x12
    800002cc:	06850513          	addi	a0,a0,104 # 80012330 <cons>
    800002d0:	119000ef          	jal	80000be8 <acquire>

  switch (c) {
    800002d4:	47d5                	li	a5,21
    800002d6:	08f48d63          	beq	s1,a5,80000370 <consoleintr+0xb4>
    800002da:	0297c563          	blt	a5,s1,80000304 <consoleintr+0x48>
    800002de:	47a1                	li	a5,8
    800002e0:	0ef48263          	beq	s1,a5,800003c4 <consoleintr+0x108>
    800002e4:	47c1                	li	a5,16
    800002e6:	10f49363          	bne	s1,a5,800003ec <consoleintr+0x130>
  case C('P'): // Print process list.
    procdump();
    800002ea:	052020ef          	jal	8000233c <procdump>
      }
    }
    break;
  }

  release(&cons.lock);
    800002ee:	00012517          	auipc	a0,0x12
    800002f2:	04250513          	addi	a0,a0,66 # 80012330 <cons>
    800002f6:	17b000ef          	jal	80000c70 <release>
}
    800002fa:	60e2                	ld	ra,24(sp)
    800002fc:	6442                	ld	s0,16(sp)
    800002fe:	64a2                	ld	s1,8(sp)
    80000300:	6105                	addi	sp,sp,32
    80000302:	8082                	ret
  switch (c) {
    80000304:	07f00793          	li	a5,127
    80000308:	0af48e63          	beq	s1,a5,800003c4 <consoleintr+0x108>
    if (c != 0 && cons.e - cons.r < INPUT_BUF_SIZE) {
    8000030c:	00012717          	auipc	a4,0x12
    80000310:	02470713          	addi	a4,a4,36 # 80012330 <cons>
    80000314:	0a072783          	lw	a5,160(a4)
    80000318:	09872703          	lw	a4,152(a4)
    8000031c:	9f99                	subw	a5,a5,a4
    8000031e:	07f00713          	li	a4,127
    80000322:	fcf766e3          	bltu	a4,a5,800002ee <consoleintr+0x32>
      c = (c == '\r') ? '\n' : c;
    80000326:	47b5                	li	a5,13
    80000328:	0cf48563          	beq	s1,a5,800003f2 <consoleintr+0x136>
      consputc(c);
    8000032c:	8526                	mv	a0,s1
    8000032e:	f5dff0ef          	jal	8000028a <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    80000332:	00012717          	auipc	a4,0x12
    80000336:	ffe70713          	addi	a4,a4,-2 # 80012330 <cons>
    8000033a:	0a072683          	lw	a3,160(a4)
    8000033e:	0016879b          	addiw	a5,a3,1
    80000342:	863e                	mv	a2,a5
    80000344:	0af72023          	sw	a5,160(a4)
    80000348:	07f6f693          	andi	a3,a3,127
    8000034c:	9736                	add	a4,a4,a3
    8000034e:	00970c23          	sb	s1,24(a4)
      if (c == '\n' || c == C('D') || cons.e - cons.r == INPUT_BUF_SIZE) {
    80000352:	ff648713          	addi	a4,s1,-10
    80000356:	c371                	beqz	a4,8000041a <consoleintr+0x15e>
    80000358:	14f1                	addi	s1,s1,-4
    8000035a:	c0e1                	beqz	s1,8000041a <consoleintr+0x15e>
    8000035c:	00012717          	auipc	a4,0x12
    80000360:	06c72703          	lw	a4,108(a4) # 800123c8 <cons+0x98>
    80000364:	9f99                	subw	a5,a5,a4
    80000366:	08000713          	li	a4,128
    8000036a:	f8e792e3          	bne	a5,a4,800002ee <consoleintr+0x32>
    8000036e:	a075                	j	8000041a <consoleintr+0x15e>
    80000370:	e04a                	sd	s2,0(sp)
    while (cons.e != cons.w &&
    80000372:	00012717          	auipc	a4,0x12
    80000376:	fbe70713          	addi	a4,a4,-66 # 80012330 <cons>
    8000037a:	0a072783          	lw	a5,160(a4)
    8000037e:	09c72703          	lw	a4,156(a4)
           cons.buf[(cons.e - 1) % INPUT_BUF_SIZE] != '\n') {
    80000382:	00012497          	auipc	s1,0x12
    80000386:	fae48493          	addi	s1,s1,-82 # 80012330 <cons>
    while (cons.e != cons.w &&
    8000038a:	4929                	li	s2,10
    8000038c:	02f70863          	beq	a4,a5,800003bc <consoleintr+0x100>
           cons.buf[(cons.e - 1) % INPUT_BUF_SIZE] != '\n') {
    80000390:	37fd                	addiw	a5,a5,-1
    80000392:	07f7f713          	andi	a4,a5,127
    80000396:	9726                	add	a4,a4,s1
    while (cons.e != cons.w &&
    80000398:	01874703          	lbu	a4,24(a4)
    8000039c:	03270263          	beq	a4,s2,800003c0 <consoleintr+0x104>
      cons.e--;
    800003a0:	0af4a023          	sw	a5,160(s1)
      consputc(BACKSPACE);
    800003a4:	10000513          	li	a0,256
    800003a8:	ee3ff0ef          	jal	8000028a <consputc>
    while (cons.e != cons.w &&
    800003ac:	0a04a783          	lw	a5,160(s1)
    800003b0:	09c4a703          	lw	a4,156(s1)
    800003b4:	fcf71ee3          	bne	a4,a5,80000390 <consoleintr+0xd4>
    800003b8:	6902                	ld	s2,0(sp)
    800003ba:	bf15                	j	800002ee <consoleintr+0x32>
    800003bc:	6902                	ld	s2,0(sp)
    800003be:	bf05                	j	800002ee <consoleintr+0x32>
    800003c0:	6902                	ld	s2,0(sp)
    800003c2:	b735                	j	800002ee <consoleintr+0x32>
    if (cons.e != cons.w) {
    800003c4:	00012717          	auipc	a4,0x12
    800003c8:	f6c70713          	addi	a4,a4,-148 # 80012330 <cons>
    800003cc:	0a072783          	lw	a5,160(a4)
    800003d0:	09c72703          	lw	a4,156(a4)
    800003d4:	f0f70de3          	beq	a4,a5,800002ee <consoleintr+0x32>
      cons.e--;
    800003d8:	37fd                	addiw	a5,a5,-1
    800003da:	00012717          	auipc	a4,0x12
    800003de:	fef72b23          	sw	a5,-10(a4) # 800123d0 <cons+0xa0>
      consputc(BACKSPACE);
    800003e2:	10000513          	li	a0,256
    800003e6:	ea5ff0ef          	jal	8000028a <consputc>
    800003ea:	b711                	j	800002ee <consoleintr+0x32>
    if (c != 0 && cons.e - cons.r < INPUT_BUF_SIZE) {
    800003ec:	f00481e3          	beqz	s1,800002ee <consoleintr+0x32>
    800003f0:	bf31                	j	8000030c <consoleintr+0x50>
      consputc(c);
    800003f2:	4529                	li	a0,10
    800003f4:	e97ff0ef          	jal	8000028a <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    800003f8:	00012797          	auipc	a5,0x12
    800003fc:	f3878793          	addi	a5,a5,-200 # 80012330 <cons>
    80000400:	0a07a703          	lw	a4,160(a5)
    80000404:	0017069b          	addiw	a3,a4,1
    80000408:	8636                	mv	a2,a3
    8000040a:	0ad7a023          	sw	a3,160(a5)
    8000040e:	07f77713          	andi	a4,a4,127
    80000412:	97ba                	add	a5,a5,a4
    80000414:	4729                	li	a4,10
    80000416:	00e78c23          	sb	a4,24(a5)
        cons.w = cons.e;
    8000041a:	00012797          	auipc	a5,0x12
    8000041e:	fac7a923          	sw	a2,-78(a5) # 800123cc <cons+0x9c>
        wakeup(&cons.r);
    80000422:	00012517          	auipc	a0,0x12
    80000426:	fa650513          	addi	a0,a0,-90 # 800123c8 <cons+0x98>
    8000042a:	355010ef          	jal	80001f7e <wakeup>
    8000042e:	b5c1                	j	800002ee <consoleintr+0x32>

0000000080000430 <consoleinit>:

void
consoleinit(void)
{
    80000430:	1141                	addi	sp,sp,-16
    80000432:	e406                	sd	ra,8(sp)
    80000434:	e022                	sd	s0,0(sp)
    80000436:	0800                	addi	s0,sp,16
  initlock(&cons.lock, "cons");
    80000438:	00007597          	auipc	a1,0x7
    8000043c:	bc858593          	addi	a1,a1,-1080 # 80007000 <etext>
    80000440:	00012517          	auipc	a0,0x12
    80000444:	ef050513          	addi	a0,a0,-272 # 80012330 <cons>
    80000448:	720000ef          	jal	80000b68 <initlock>

  uartinit();
    8000044c:	448000ef          	jal	80000894 <uartinit>

  // connect read and write system calls
  // to consoleread and consolewrite.
  devsw[CONSOLE].read = consoleread;
    80000450:	00022797          	auipc	a5,0x22
    80000454:	06878793          	addi	a5,a5,104 # 800224b8 <devsw>
    80000458:	00000717          	auipc	a4,0x0
    8000045c:	d2070713          	addi	a4,a4,-736 # 80000178 <consoleread>
    80000460:	eb98                	sd	a4,16(a5)
  devsw[CONSOLE].write = consolewrite;
    80000462:	00000717          	auipc	a4,0x0
    80000466:	c7470713          	addi	a4,a4,-908 # 800000d6 <consolewrite>
    8000046a:	ef98                	sd	a4,24(a5)
}
    8000046c:	60a2                	ld	ra,8(sp)
    8000046e:	6402                	ld	s0,0(sp)
    80000470:	0141                	addi	sp,sp,16
    80000472:	8082                	ret

0000000080000474 <printint>:

static char digits[] = "0123456789abcdef";

static void
printint(long long xx, int base, int sign)
{
    80000474:	7139                	addi	sp,sp,-64
    80000476:	fc06                	sd	ra,56(sp)
    80000478:	f822                	sd	s0,48(sp)
    8000047a:	f04a                	sd	s2,32(sp)
    8000047c:	0080                	addi	s0,sp,64
  char buf[20];
  int i;
  unsigned long long x;

  if (sign && (sign = (xx < 0)))
    8000047e:	c219                	beqz	a2,80000484 <printint+0x10>
    80000480:	08054163          	bltz	a0,80000502 <printint+0x8e>
    x = -xx;
  else
    x = xx;
    80000484:	4301                	li	t1,0

  i = 0;
    80000486:	fc840913          	addi	s2,s0,-56
    x = xx;
    8000048a:	86ca                	mv	a3,s2
  i = 0;
    8000048c:	4701                	li	a4,0
  do {
    buf[i++] = digits[x % base];
    8000048e:	00007817          	auipc	a6,0x7
    80000492:	2ba80813          	addi	a6,a6,698 # 80007748 <digits>
    80000496:	88ba                	mv	a7,a4
    80000498:	0017061b          	addiw	a2,a4,1
    8000049c:	8732                	mv	a4,a2
    8000049e:	02b577b3          	remu	a5,a0,a1
    800004a2:	97c2                	add	a5,a5,a6
    800004a4:	0007c783          	lbu	a5,0(a5)
    800004a8:	00f68023          	sb	a5,0(a3)
  } while ((x /= base) != 0);
    800004ac:	87aa                	mv	a5,a0
    800004ae:	02b55533          	divu	a0,a0,a1
    800004b2:	0685                	addi	a3,a3,1
    800004b4:	feb7f1e3          	bgeu	a5,a1,80000496 <printint+0x22>

  if (sign)
    800004b8:	00030c63          	beqz	t1,800004d0 <printint+0x5c>
    buf[i++] = '-';
    800004bc:	fe060793          	addi	a5,a2,-32
    800004c0:	00878633          	add	a2,a5,s0
    800004c4:	02d00793          	li	a5,45
    800004c8:	fef60423          	sb	a5,-24(a2)
    800004cc:	0028871b          	addiw	a4,a7,2

  while (--i >= 0)
    800004d0:	02e05463          	blez	a4,800004f8 <printint+0x84>
    800004d4:	f426                	sd	s1,40(sp)
    800004d6:	377d                	addiw	a4,a4,-1
    800004d8:	00e904b3          	add	s1,s2,a4
    800004dc:	197d                	addi	s2,s2,-1
    800004de:	993a                	add	s2,s2,a4
    800004e0:	1702                	slli	a4,a4,0x20
    800004e2:	9301                	srli	a4,a4,0x20
    800004e4:	40e90933          	sub	s2,s2,a4
    consputc(buf[i]);
    800004e8:	0004c503          	lbu	a0,0(s1)
    800004ec:	d9fff0ef          	jal	8000028a <consputc>
  while (--i >= 0)
    800004f0:	14fd                	addi	s1,s1,-1
    800004f2:	ff249be3          	bne	s1,s2,800004e8 <printint+0x74>
    800004f6:	74a2                	ld	s1,40(sp)
}
    800004f8:	70e2                	ld	ra,56(sp)
    800004fa:	7442                	ld	s0,48(sp)
    800004fc:	7902                	ld	s2,32(sp)
    800004fe:	6121                	addi	sp,sp,64
    80000500:	8082                	ret
    x = -xx;
    80000502:	40a00533          	neg	a0,a0
  if (sign && (sign = (xx < 0)))
    80000506:	4305                	li	t1,1
    x = -xx;
    80000508:	bfbd                	j	80000486 <printint+0x12>

000000008000050a <printk>:
}

// Print to the console.
int
printk(char *fmt, ...)
{
    8000050a:	7131                	addi	sp,sp,-192
    8000050c:	fc86                	sd	ra,120(sp)
    8000050e:	f8a2                	sd	s0,112(sp)
    80000510:	f0ca                	sd	s2,96(sp)
    80000512:	0100                	addi	s0,sp,128
    80000514:	892a                	mv	s2,a0
    80000516:	e40c                	sd	a1,8(s0)
    80000518:	e810                	sd	a2,16(s0)
    8000051a:	ec14                	sd	a3,24(s0)
    8000051c:	f018                	sd	a4,32(s0)
    8000051e:	f41c                	sd	a5,40(s0)
    80000520:	03043823          	sd	a6,48(s0)
    80000524:	03143c23          	sd	a7,56(s0)
  va_list ap;
  int i, cx, c0, c1, c2;
  char *s;

  if (panicking == 0)
    80000528:	0000a797          	auipc	a5,0xa
    8000052c:	ddc7a783          	lw	a5,-548(a5) # 8000a304 <panicking>
    80000530:	cf9d                	beqz	a5,8000056e <printk+0x64>
    acquire(&pr.lock);

  va_start(ap, fmt);
    80000532:	00840793          	addi	a5,s0,8
    80000536:	f8f43423          	sd	a5,-120(s0)
  for (i = 0; (cx = fmt[i] & 0xff) != 0; i++) {
    8000053a:	00094503          	lbu	a0,0(s2)
    8000053e:	22050663          	beqz	a0,8000076a <printk+0x260>
    80000542:	f4a6                	sd	s1,104(sp)
    80000544:	ecce                	sd	s3,88(sp)
    80000546:	e8d2                	sd	s4,80(sp)
    80000548:	e4d6                	sd	s5,72(sp)
    8000054a:	e0da                	sd	s6,64(sp)
    8000054c:	fc5e                	sd	s7,56(sp)
    8000054e:	f862                	sd	s8,48(sp)
    80000550:	f06a                	sd	s10,32(sp)
    80000552:	ec6e                	sd	s11,24(sp)
    80000554:	4a01                	li	s4,0
    if (cx != '%') {
    80000556:	02500993          	li	s3,37
      printint(va_arg(ap, uint64), 10, 1);
      i += 1;
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
      printint(va_arg(ap, uint64), 10, 1);
      i += 2;
    } else if (c0 == 'u') {
    8000055a:	07500c13          	li	s8,117
      printint(va_arg(ap, uint64), 10, 0);
      i += 1;
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'u') {
      printint(va_arg(ap, uint64), 10, 0);
      i += 2;
    } else if (c0 == 'x') {
    8000055e:	07800d13          	li	s10,120
      printint(va_arg(ap, uint64), 16, 0);
      i += 1;
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'x') {
      printint(va_arg(ap, uint64), 16, 0);
      i += 2;
    } else if (c0 == 'p') {
    80000562:	07000d93          	li	s11,112
      printint(va_arg(ap, uint64), 10, 0);
    80000566:	4b29                	li	s6,10
    if (c0 == 'd') {
    80000568:	06400b93          	li	s7,100
    8000056c:	a015                	j	80000590 <printk+0x86>
    acquire(&pr.lock);
    8000056e:	00012517          	auipc	a0,0x12
    80000572:	e6a50513          	addi	a0,a0,-406 # 800123d8 <pr>
    80000576:	672000ef          	jal	80000be8 <acquire>
    8000057a:	bf65                	j	80000532 <printk+0x28>
      consputc(cx);
    8000057c:	d0fff0ef          	jal	8000028a <consputc>
      continue;
    80000580:	84d2                	mv	s1,s4
  for (i = 0; (cx = fmt[i] & 0xff) != 0; i++) {
    80000582:	2485                	addiw	s1,s1,1
    80000584:	8a26                	mv	s4,s1
    80000586:	94ca                	add	s1,s1,s2
    80000588:	0004c503          	lbu	a0,0(s1)
    8000058c:	1c050663          	beqz	a0,80000758 <printk+0x24e>
    if (cx != '%') {
    80000590:	ff3516e3          	bne	a0,s3,8000057c <printk+0x72>
    i++;
    80000594:	001a079b          	addiw	a5,s4,1
    80000598:	84be                	mv	s1,a5
    c0 = fmt[i + 0] & 0xff;
    8000059a:	00f90733          	add	a4,s2,a5
    8000059e:	00074a83          	lbu	s5,0(a4)
    if (c0)
    800005a2:	200a8963          	beqz	s5,800007b4 <printk+0x2aa>
      c1 = fmt[i + 1] & 0xff;
    800005a6:	00174683          	lbu	a3,1(a4)
    if (c1)
    800005aa:	1e068c63          	beqz	a3,800007a2 <printk+0x298>
    if (c0 == 'd') {
    800005ae:	037a8863          	beq	s5,s7,800005de <printk+0xd4>
    } else if (c0 == 'l' && c1 == 'd') {
    800005b2:	f94a8713          	addi	a4,s5,-108
    800005b6:	00173713          	seqz	a4,a4
    800005ba:	f9c68613          	addi	a2,a3,-100
    800005be:	ee05                	bnez	a2,800005f6 <printk+0xec>
    800005c0:	cb1d                	beqz	a4,800005f6 <printk+0xec>
      printint(va_arg(ap, uint64), 10, 1);
    800005c2:	f8843783          	ld	a5,-120(s0)
    800005c6:	00878713          	addi	a4,a5,8
    800005ca:	f8e43423          	sd	a4,-120(s0)
    800005ce:	4605                	li	a2,1
    800005d0:	85da                	mv	a1,s6
    800005d2:	6388                	ld	a0,0(a5)
    800005d4:	ea1ff0ef          	jal	80000474 <printint>
      i += 1;
    800005d8:	002a049b          	addiw	s1,s4,2
    800005dc:	b75d                	j	80000582 <printk+0x78>
      printint(va_arg(ap, int), 10, 1);
    800005de:	f8843783          	ld	a5,-120(s0)
    800005e2:	00878713          	addi	a4,a5,8
    800005e6:	f8e43423          	sd	a4,-120(s0)
    800005ea:	4605                	li	a2,1
    800005ec:	85da                	mv	a1,s6
    800005ee:	4388                	lw	a0,0(a5)
    800005f0:	e85ff0ef          	jal	80000474 <printint>
    800005f4:	b779                	j	80000582 <printk+0x78>
      c2 = fmt[i + 2] & 0xff;
    800005f6:	97ca                	add	a5,a5,s2
    800005f8:	8636                	mv	a2,a3
    800005fa:	0027c683          	lbu	a3,2(a5)
    800005fe:	a2c9                	j	800007c0 <printk+0x2b6>
      printint(va_arg(ap, uint64), 10, 1);
    80000600:	f8843783          	ld	a5,-120(s0)
    80000604:	00878713          	addi	a4,a5,8
    80000608:	f8e43423          	sd	a4,-120(s0)
    8000060c:	4605                	li	a2,1
    8000060e:	45a9                	li	a1,10
    80000610:	6388                	ld	a0,0(a5)
    80000612:	e63ff0ef          	jal	80000474 <printint>
      i += 2;
    80000616:	003a049b          	addiw	s1,s4,3
    8000061a:	b7a5                	j	80000582 <printk+0x78>
      printint(va_arg(ap, uint32), 10, 0);
    8000061c:	f8843783          	ld	a5,-120(s0)
    80000620:	00878713          	addi	a4,a5,8
    80000624:	f8e43423          	sd	a4,-120(s0)
    80000628:	4601                	li	a2,0
    8000062a:	85da                	mv	a1,s6
    8000062c:	0007e503          	lwu	a0,0(a5)
    80000630:	e45ff0ef          	jal	80000474 <printint>
    80000634:	b7b9                	j	80000582 <printk+0x78>
      printint(va_arg(ap, uint64), 10, 0);
    80000636:	f8843783          	ld	a5,-120(s0)
    8000063a:	00878713          	addi	a4,a5,8
    8000063e:	f8e43423          	sd	a4,-120(s0)
    80000642:	4601                	li	a2,0
    80000644:	85da                	mv	a1,s6
    80000646:	6388                	ld	a0,0(a5)
    80000648:	e2dff0ef          	jal	80000474 <printint>
      i += 1;
    8000064c:	002a049b          	addiw	s1,s4,2
    80000650:	bf0d                	j	80000582 <printk+0x78>
      printint(va_arg(ap, uint64), 10, 0);
    80000652:	f8843783          	ld	a5,-120(s0)
    80000656:	00878713          	addi	a4,a5,8
    8000065a:	f8e43423          	sd	a4,-120(s0)
    8000065e:	4601                	li	a2,0
    80000660:	45a9                	li	a1,10
    80000662:	6388                	ld	a0,0(a5)
    80000664:	e11ff0ef          	jal	80000474 <printint>
      i += 2;
    80000668:	003a049b          	addiw	s1,s4,3
    8000066c:	bf19                	j	80000582 <printk+0x78>
      printint(va_arg(ap, uint32), 16, 0);
    8000066e:	f8843783          	ld	a5,-120(s0)
    80000672:	00878713          	addi	a4,a5,8
    80000676:	f8e43423          	sd	a4,-120(s0)
    8000067a:	4601                	li	a2,0
    8000067c:	45c1                	li	a1,16
    8000067e:	0007e503          	lwu	a0,0(a5)
    80000682:	df3ff0ef          	jal	80000474 <printint>
    80000686:	bdf5                	j	80000582 <printk+0x78>
      printint(va_arg(ap, uint64), 16, 0);
    80000688:	f8843783          	ld	a5,-120(s0)
    8000068c:	00878713          	addi	a4,a5,8
    80000690:	f8e43423          	sd	a4,-120(s0)
    80000694:	45c1                	li	a1,16
    80000696:	6388                	ld	a0,0(a5)
    80000698:	dddff0ef          	jal	80000474 <printint>
      i += 1;
    8000069c:	002a049b          	addiw	s1,s4,2
    800006a0:	b5cd                	j	80000582 <printk+0x78>
      printint(va_arg(ap, uint64), 16, 0);
    800006a2:	f8843783          	ld	a5,-120(s0)
    800006a6:	00878713          	addi	a4,a5,8
    800006aa:	f8e43423          	sd	a4,-120(s0)
    800006ae:	4601                	li	a2,0
    800006b0:	45c1                	li	a1,16
    800006b2:	6388                	ld	a0,0(a5)
    800006b4:	dc1ff0ef          	jal	80000474 <printint>
      i += 2;
    800006b8:	003a049b          	addiw	s1,s4,3
    800006bc:	b5d9                	j	80000582 <printk+0x78>
    800006be:	f466                	sd	s9,40(sp)
      printptr(va_arg(ap, uint64));
    800006c0:	f8843783          	ld	a5,-120(s0)
    800006c4:	00878713          	addi	a4,a5,8
    800006c8:	f8e43423          	sd	a4,-120(s0)
    800006cc:	0007ba83          	ld	s5,0(a5)
  consputc('0');
    800006d0:	03000513          	li	a0,48
    800006d4:	bb7ff0ef          	jal	8000028a <consputc>
  consputc('x');
    800006d8:	07800513          	li	a0,120
    800006dc:	bafff0ef          	jal	8000028a <consputc>
    800006e0:	4a41                	li	s4,16
    consputc(digits[x >> (sizeof(uint64) * 8 - 4)]);
    800006e2:	00007c97          	auipc	s9,0x7
    800006e6:	066c8c93          	addi	s9,s9,102 # 80007748 <digits>
    800006ea:	03cad793          	srli	a5,s5,0x3c
    800006ee:	97e6                	add	a5,a5,s9
    800006f0:	0007c503          	lbu	a0,0(a5)
    800006f4:	b97ff0ef          	jal	8000028a <consputc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
    800006f8:	0a92                	slli	s5,s5,0x4
    800006fa:	3a7d                	addiw	s4,s4,-1
    800006fc:	fe0a17e3          	bnez	s4,800006ea <printk+0x1e0>
    80000700:	7ca2                	ld	s9,40(sp)
    80000702:	b541                	j	80000582 <printk+0x78>
    } else if (c0 == 'c') {
      consputc(va_arg(ap, uint));
    80000704:	f8843783          	ld	a5,-120(s0)
    80000708:	00878713          	addi	a4,a5,8
    8000070c:	f8e43423          	sd	a4,-120(s0)
    80000710:	4388                	lw	a0,0(a5)
    80000712:	b79ff0ef          	jal	8000028a <consputc>
    80000716:	b5b5                	j	80000582 <printk+0x78>
    } else if (c0 == 's') {
      if ((s = va_arg(ap, char *)) == 0)
    80000718:	f8843783          	ld	a5,-120(s0)
    8000071c:	00878713          	addi	a4,a5,8
    80000720:	f8e43423          	sd	a4,-120(s0)
    80000724:	0007ba03          	ld	s4,0(a5)
    80000728:	000a0d63          	beqz	s4,80000742 <printk+0x238>
        s = "(null)";
      for (; *s; s++)
    8000072c:	000a4503          	lbu	a0,0(s4)
    80000730:	e40509e3          	beqz	a0,80000582 <printk+0x78>
        consputc(*s);
    80000734:	b57ff0ef          	jal	8000028a <consputc>
      for (; *s; s++)
    80000738:	0a05                	addi	s4,s4,1
    8000073a:	000a4503          	lbu	a0,0(s4)
    8000073e:	f97d                	bnez	a0,80000734 <printk+0x22a>
    80000740:	b589                	j	80000582 <printk+0x78>
        s = "(null)";
    80000742:	00007a17          	auipc	s4,0x7
    80000746:	8c6a0a13          	addi	s4,s4,-1850 # 80007008 <etext+0x8>
      for (; *s; s++)
    8000074a:	02800513          	li	a0,40
    8000074e:	b7dd                	j	80000734 <printk+0x22a>
    } else if (c0 == '%') {
      consputc('%');
    80000750:	8556                	mv	a0,s5
    80000752:	b39ff0ef          	jal	8000028a <consputc>
    80000756:	b535                	j	80000582 <printk+0x78>
    80000758:	74a6                	ld	s1,104(sp)
    8000075a:	69e6                	ld	s3,88(sp)
    8000075c:	6a46                	ld	s4,80(sp)
    8000075e:	6aa6                	ld	s5,72(sp)
    80000760:	6b06                	ld	s6,64(sp)
    80000762:	7be2                	ld	s7,56(sp)
    80000764:	7c42                	ld	s8,48(sp)
    80000766:	7d02                	ld	s10,32(sp)
    80000768:	6de2                	ld	s11,24(sp)
      consputc(c0);
    }
  }
  va_end(ap);

  if (panicking == 0)
    8000076a:	0000a797          	auipc	a5,0xa
    8000076e:	b9a7a783          	lw	a5,-1126(a5) # 8000a304 <panicking>
    80000772:	c38d                	beqz	a5,80000794 <printk+0x28a>
    release(&pr.lock);

  return 0;
}
    80000774:	4501                	li	a0,0
    80000776:	70e6                	ld	ra,120(sp)
    80000778:	7446                	ld	s0,112(sp)
    8000077a:	7906                	ld	s2,96(sp)
    8000077c:	6129                	addi	sp,sp,192
    8000077e:	8082                	ret
    80000780:	74a6                	ld	s1,104(sp)
    80000782:	69e6                	ld	s3,88(sp)
    80000784:	6a46                	ld	s4,80(sp)
    80000786:	6aa6                	ld	s5,72(sp)
    80000788:	6b06                	ld	s6,64(sp)
    8000078a:	7be2                	ld	s7,56(sp)
    8000078c:	7c42                	ld	s8,48(sp)
    8000078e:	7d02                	ld	s10,32(sp)
    80000790:	6de2                	ld	s11,24(sp)
    80000792:	bfe1                	j	8000076a <printk+0x260>
    release(&pr.lock);
    80000794:	00012517          	auipc	a0,0x12
    80000798:	c4450513          	addi	a0,a0,-956 # 800123d8 <pr>
    8000079c:	4d4000ef          	jal	80000c70 <release>
  return 0;
    800007a0:	bfd1                	j	80000774 <printk+0x26a>
    if (c0 == 'd') {
    800007a2:	e37a8ee3          	beq	s5,s7,800005de <printk+0xd4>
    } else if (c0 == 'l' && c1 == 'd') {
    800007a6:	f94a8713          	addi	a4,s5,-108
    800007aa:	00173713          	seqz	a4,a4
    800007ae:	8636                	mv	a2,a3
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
    800007b0:	4781                	li	a5,0
    800007b2:	a00d                	j	800007d4 <printk+0x2ca>
    } else if (c0 == 'l' && c1 == 'd') {
    800007b4:	f94a8713          	addi	a4,s5,-108
    800007b8:	00173713          	seqz	a4,a4
    c1 = c2 = 0;
    800007bc:	8656                	mv	a2,s5
    800007be:	86d6                	mv	a3,s5
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
    800007c0:	f9460793          	addi	a5,a2,-108
    800007c4:	0017b793          	seqz	a5,a5
    800007c8:	8ff9                	and	a5,a5,a4
    800007ca:	f9c68593          	addi	a1,a3,-100
    800007ce:	e199                	bnez	a1,800007d4 <printk+0x2ca>
    800007d0:	e20798e3          	bnez	a5,80000600 <printk+0xf6>
    } else if (c0 == 'u') {
    800007d4:	e58a84e3          	beq	s5,s8,8000061c <printk+0x112>
    } else if (c0 == 'l' && c1 == 'u') {
    800007d8:	f8b60593          	addi	a1,a2,-117
    800007dc:	e199                	bnez	a1,800007e2 <printk+0x2d8>
    800007de:	e4071ce3          	bnez	a4,80000636 <printk+0x12c>
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'u') {
    800007e2:	f8b68593          	addi	a1,a3,-117
    800007e6:	e199                	bnez	a1,800007ec <printk+0x2e2>
    800007e8:	e60795e3          	bnez	a5,80000652 <printk+0x148>
    } else if (c0 == 'x') {
    800007ec:	e9aa81e3          	beq	s5,s10,8000066e <printk+0x164>
    } else if (c0 == 'l' && c1 == 'x') {
    800007f0:	f8860613          	addi	a2,a2,-120
    800007f4:	e219                	bnez	a2,800007fa <printk+0x2f0>
    800007f6:	e80719e3          	bnez	a4,80000688 <printk+0x17e>
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'x') {
    800007fa:	f8868693          	addi	a3,a3,-120
    800007fe:	e299                	bnez	a3,80000804 <printk+0x2fa>
    80000800:	ea0791e3          	bnez	a5,800006a2 <printk+0x198>
    } else if (c0 == 'p') {
    80000804:	ebba8de3          	beq	s5,s11,800006be <printk+0x1b4>
    } else if (c0 == 'c') {
    80000808:	06300793          	li	a5,99
    8000080c:	eefa8ce3          	beq	s5,a5,80000704 <printk+0x1fa>
    } else if (c0 == 's') {
    80000810:	07300793          	li	a5,115
    80000814:	f0fa82e3          	beq	s5,a5,80000718 <printk+0x20e>
    } else if (c0 == '%') {
    80000818:	02500793          	li	a5,37
    8000081c:	f2fa8ae3          	beq	s5,a5,80000750 <printk+0x246>
    } else if (c0 == 0) {
    80000820:	f60a80e3          	beqz	s5,80000780 <printk+0x276>
      consputc('%');
    80000824:	02500513          	li	a0,37
    80000828:	a63ff0ef          	jal	8000028a <consputc>
      consputc(c0);
    8000082c:	8556                	mv	a0,s5
    8000082e:	a5dff0ef          	jal	8000028a <consputc>
    80000832:	bb81                	j	80000582 <printk+0x78>

0000000080000834 <panic>:

void
panic(char *s)
{
    80000834:	1101                	addi	sp,sp,-32
    80000836:	ec06                	sd	ra,24(sp)
    80000838:	e822                	sd	s0,16(sp)
    8000083a:	e426                	sd	s1,8(sp)
    8000083c:	e04a                	sd	s2,0(sp)
    8000083e:	1000                	addi	s0,sp,32
    80000840:	892a                	mv	s2,a0
  panicking = 1;
    80000842:	4485                	li	s1,1
    80000844:	0000a797          	auipc	a5,0xa
    80000848:	ac97a023          	sw	s1,-1344(a5) # 8000a304 <panicking>
  printk("panic: ");
    8000084c:	00006517          	auipc	a0,0x6
    80000850:	7cc50513          	addi	a0,a0,1996 # 80007018 <etext+0x18>
    80000854:	cb7ff0ef          	jal	8000050a <printk>
  printk("%s\n", s);
    80000858:	85ca                	mv	a1,s2
    8000085a:	00006517          	auipc	a0,0x6
    8000085e:	7c650513          	addi	a0,a0,1990 # 80007020 <etext+0x20>
    80000862:	ca9ff0ef          	jal	8000050a <printk>
  panicked = 1; // freeze uart output from other CPUs
    80000866:	0000a797          	auipc	a5,0xa
    8000086a:	a897ad23          	sw	s1,-1382(a5) # 8000a300 <panicked>
  for (;;)
    8000086e:	a001                	j	8000086e <panic+0x3a>

0000000080000870 <printkinit>:
    ;
}

void
printkinit(void)
{
    80000870:	1141                	addi	sp,sp,-16
    80000872:	e406                	sd	ra,8(sp)
    80000874:	e022                	sd	s0,0(sp)
    80000876:	0800                	addi	s0,sp,16
  initlock(&pr.lock, "pr");
    80000878:	00006597          	auipc	a1,0x6
    8000087c:	7b058593          	addi	a1,a1,1968 # 80007028 <etext+0x28>
    80000880:	00012517          	auipc	a0,0x12
    80000884:	b5850513          	addi	a0,a0,-1192 # 800123d8 <pr>
    80000888:	2e0000ef          	jal	80000b68 <initlock>
}
    8000088c:	60a2                	ld	ra,8(sp)
    8000088e:	6402                	ld	s0,0(sp)
    80000890:	0141                	addi	sp,sp,16
    80000892:	8082                	ret

0000000080000894 <uartinit>:
extern volatile int panicking; // from printk.c
extern volatile int panicked;  // from printk.c

void
uartinit(void)
{
    80000894:	1141                	addi	sp,sp,-16
    80000896:	e406                	sd	ra,8(sp)
    80000898:	e022                	sd	s0,0(sp)
    8000089a:	0800                	addi	s0,sp,16
  // disable interrupts.
  WriteReg(IER, 0x00);
    8000089c:	100007b7          	lui	a5,0x10000
    800008a0:	000780a3          	sb	zero,1(a5) # 10000001 <_entry-0x6fffffff>

  // special mode to set baud rate.
  WriteReg(LCR, LCR_BAUD_LATCH);
    800008a4:	10000737          	lui	a4,0x10000
    800008a8:	f8000693          	li	a3,-128
    800008ac:	00d701a3          	sb	a3,3(a4) # 10000003 <_entry-0x6ffffffd>

  // LSB for baud rate of 38.4K.
  WriteReg(0, 0x03);
    800008b0:	468d                	li	a3,3
    800008b2:	10000637          	lui	a2,0x10000
    800008b6:	00d60023          	sb	a3,0(a2) # 10000000 <_entry-0x70000000>

  // MSB for baud rate of 38.4K.
  WriteReg(1, 0x00);
    800008ba:	000780a3          	sb	zero,1(a5)

  // leave set-baud mode,
  // and set word length to 8 bits, no parity.
  WriteReg(LCR, LCR_EIGHT_BITS);
    800008be:	00d701a3          	sb	a3,3(a4)

  // reset and enable FIFOs.
  WriteReg(FCR, FCR_FIFO_ENABLE | FCR_FIFO_CLEAR);
    800008c2:	8732                	mv	a4,a2
    800008c4:	461d                	li	a2,7
    800008c6:	00c70123          	sb	a2,2(a4)

  // enable transmit and receive interrupts.
  WriteReg(IER, IER_TX_ENABLE | IER_RX_ENABLE);
    800008ca:	00d780a3          	sb	a3,1(a5)

  initsleeplock(&tx_lock, "uart");
    800008ce:	00006597          	auipc	a1,0x6
    800008d2:	76258593          	addi	a1,a1,1890 # 80007030 <etext+0x30>
    800008d6:	00012517          	auipc	a0,0x12
    800008da:	b1a50513          	addi	a0,a0,-1254 # 800123f0 <tx_lock>
    800008de:	714030ef          	jal	80003ff2 <initsleeplock>
}
    800008e2:	60a2                	ld	ra,8(sp)
    800008e4:	6402                	ld	s0,0(sp)
    800008e6:	0141                	addi	sp,sp,16
    800008e8:	8082                	ret

00000000800008ea <uartwrite>:
// transmit buf[] to the uart. it blocks if the
// uart is busy, so it cannot be called from
// interrupts, only from write() system calls.
void
uartwrite(char buf[], int n)
{
    800008ea:	7139                	addi	sp,sp,-64
    800008ec:	fc06                	sd	ra,56(sp)
    800008ee:	f822                	sd	s0,48(sp)
    800008f0:	f04a                	sd	s2,32(sp)
    800008f2:	e456                	sd	s5,8(sp)
    800008f4:	0080                	addi	s0,sp,64
    800008f6:	8aaa                	mv	s5,a0
    800008f8:	892e                	mv	s2,a1
  acquiresleep(&tx_lock);
    800008fa:	00012517          	auipc	a0,0x12
    800008fe:	af650513          	addi	a0,a0,-1290 # 800123f0 <tx_lock>
    80000902:	726030ef          	jal	80004028 <acquiresleep>

  int i = 0;
  while (i < n) {
    80000906:	05205963          	blez	s2,80000958 <uartwrite+0x6e>
    8000090a:	f426                	sd	s1,40(sp)
    8000090c:	ec4e                	sd	s3,24(sp)
    8000090e:	e852                	sd	s4,16(sp)
    80000910:	e05a                	sd	s6,0(sp)
  int i = 0;
    80000912:	4481                	li	s1,0
    sleep_prepare(&tx_chan);
    80000914:	0000aa17          	auipc	s4,0xa
    80000918:	9f4a0a13          	addi	s4,s4,-1548 # 8000a308 <tx_chan>
    if (ReadReg(LSR) & LSR_TX_IDLE) {
    8000091c:	100009b7          	lui	s3,0x10000
    80000920:	0995                	addi	s3,s3,5 # 10000005 <_entry-0x6ffffffb>
      WriteReg(THR, buf[i]);
    80000922:	10000b37          	lui	s6,0x10000
    80000926:	a029                	j	80000930 <uartwrite+0x46>
      i += 1;
    } else {
      sleep();
    80000928:	626010ef          	jal	80001f4e <sleep>
  while (i < n) {
    8000092c:	0324d263          	bge	s1,s2,80000950 <uartwrite+0x66>
    sleep_prepare(&tx_chan);
    80000930:	8552                	mv	a0,s4
    80000932:	5e0010ef          	jal	80001f12 <sleep_prepare>
    if (ReadReg(LSR) & LSR_TX_IDLE) {
    80000936:	0009c783          	lbu	a5,0(s3)
    8000093a:	0207f793          	andi	a5,a5,32
    8000093e:	d7ed                	beqz	a5,80000928 <uartwrite+0x3e>
      WriteReg(THR, buf[i]);
    80000940:	009a87b3          	add	a5,s5,s1
    80000944:	0007c783          	lbu	a5,0(a5)
    80000948:	00fb0023          	sb	a5,0(s6) # 10000000 <_entry-0x70000000>
      i += 1;
    8000094c:	2485                	addiw	s1,s1,1
    8000094e:	bff9                	j	8000092c <uartwrite+0x42>
    80000950:	74a2                	ld	s1,40(sp)
    80000952:	69e2                	ld	s3,24(sp)
    80000954:	6a42                	ld	s4,16(sp)
    80000956:	6b02                	ld	s6,0(sp)
    }
  }

  releasesleep(&tx_lock);
    80000958:	00012517          	auipc	a0,0x12
    8000095c:	a9850513          	addi	a0,a0,-1384 # 800123f0 <tx_lock>
    80000960:	71c030ef          	jal	8000407c <releasesleep>
}
    80000964:	70e2                	ld	ra,56(sp)
    80000966:	7442                	ld	s0,48(sp)
    80000968:	7902                	ld	s2,32(sp)
    8000096a:	6aa2                	ld	s5,8(sp)
    8000096c:	6121                	addi	sp,sp,64
    8000096e:	8082                	ret

0000000080000970 <uartputc_sync>:
// interrupts, for use by kernel printk() and
// to echo characters. it spins waiting for the uart's
// output register to be empty.
void
uartputc_sync(int c)
{
    80000970:	1101                	addi	sp,sp,-32
    80000972:	ec06                	sd	ra,24(sp)
    80000974:	e822                	sd	s0,16(sp)
    80000976:	e426                	sd	s1,8(sp)
    80000978:	1000                	addi	s0,sp,32
    8000097a:	84aa                	mv	s1,a0
  if (panicking == 0)
    8000097c:	0000a797          	auipc	a5,0xa
    80000980:	9887a783          	lw	a5,-1656(a5) # 8000a304 <panicking>
    80000984:	cf95                	beqz	a5,800009c0 <uartputc_sync+0x50>
    push_off();

  if (panicked) {
    80000986:	0000a797          	auipc	a5,0xa
    8000098a:	97a7a783          	lw	a5,-1670(a5) # 8000a300 <panicked>
    8000098e:	ef85                	bnez	a5,800009c6 <uartputc_sync+0x56>
    for (;;)
      ;
  }

  // wait for UART to set Transmit Holding Empty in LSR.
  while ((ReadReg(LSR) & LSR_TX_IDLE) == 0)
    80000990:	10000737          	lui	a4,0x10000
    80000994:	0715                	addi	a4,a4,5 # 10000005 <_entry-0x6ffffffb>
    80000996:	00074783          	lbu	a5,0(a4)
    8000099a:	0207f793          	andi	a5,a5,32
    8000099e:	dfe5                	beqz	a5,80000996 <uartputc_sync+0x26>
    ;
  WriteReg(THR, c);
    800009a0:	0ff4f513          	zext.b	a0,s1
    800009a4:	100007b7          	lui	a5,0x10000
    800009a8:	00a78023          	sb	a0,0(a5) # 10000000 <_entry-0x70000000>

  if (panicking == 0)
    800009ac:	0000a797          	auipc	a5,0xa
    800009b0:	9587a783          	lw	a5,-1704(a5) # 8000a304 <panicking>
    800009b4:	cb91                	beqz	a5,800009c8 <uartputc_sync+0x58>
    pop_off();
}
    800009b6:	60e2                	ld	ra,24(sp)
    800009b8:	6442                	ld	s0,16(sp)
    800009ba:	64a2                	ld	s1,8(sp)
    800009bc:	6105                	addi	sp,sp,32
    800009be:	8082                	ret
    push_off();
    800009c0:	1ee000ef          	jal	80000bae <push_off>
    800009c4:	b7c9                	j	80000986 <uartputc_sync+0x16>
    for (;;)
    800009c6:	a001                	j	800009c6 <uartputc_sync+0x56>
    pop_off();
    800009c8:	260000ef          	jal	80000c28 <pop_off>
}
    800009cc:	b7ed                	j	800009b6 <uartputc_sync+0x46>

00000000800009ce <uartintr>:
// handle a uart interrupt, raised because input has
// arrived, or the uart is ready for more output, or
// both. called from devintr().
void
uartintr(void)
{
    800009ce:	1101                	addi	sp,sp,-32
    800009d0:	ec06                	sd	ra,24(sp)
    800009d2:	e822                	sd	s0,16(sp)
    800009d4:	e426                	sd	s1,8(sp)
    800009d6:	e04a                	sd	s2,0(sp)
    800009d8:	1000                	addi	s0,sp,32
  ReadReg(ISR); // acknowledge the interrupt
    800009da:	100007b7          	lui	a5,0x10000
    800009de:	0027c783          	lbu	a5,2(a5) # 10000002 <_entry-0x6ffffffe>

  if (ReadReg(LSR) & LSR_TX_IDLE) {
    800009e2:	100007b7          	lui	a5,0x10000
    800009e6:	0057c783          	lbu	a5,5(a5) # 10000005 <_entry-0x6ffffffb>
    800009ea:	0207f793          	andi	a5,a5,32
    800009ee:	ef99                	bnez	a5,80000a0c <uartintr+0x3e>
  if (ReadReg(LSR) & LSR_RX_READY) {
    800009f0:	100004b7          	lui	s1,0x10000
    800009f4:	0495                	addi	s1,s1,5 # 10000005 <_entry-0x6ffffffb>
    return ReadReg(RHR);
    800009f6:	10000937          	lui	s2,0x10000
  if (ReadReg(LSR) & LSR_RX_READY) {
    800009fa:	0004c783          	lbu	a5,0(s1)
    800009fe:	8b85                	andi	a5,a5,1
    80000a00:	cf89                	beqz	a5,80000a1a <uartintr+0x4c>
    return ReadReg(RHR);
    80000a02:	00094503          	lbu	a0,0(s2) # 10000000 <_entry-0x70000000>
  // read and process incoming characters, if any.
  while (1) {
    int c = uartgetc();
    if (c == -1)
      break;
    consoleintr(c);
    80000a06:	8b7ff0ef          	jal	800002bc <consoleintr>
  while (1) {
    80000a0a:	bfc5                	j	800009fa <uartintr+0x2c>
    wakeup(&tx_chan);
    80000a0c:	0000a517          	auipc	a0,0xa
    80000a10:	8fc50513          	addi	a0,a0,-1796 # 8000a308 <tx_chan>
    80000a14:	56a010ef          	jal	80001f7e <wakeup>
    80000a18:	bfe1                	j	800009f0 <uartintr+0x22>
  }
}
    80000a1a:	60e2                	ld	ra,24(sp)
    80000a1c:	6442                	ld	s0,16(sp)
    80000a1e:	64a2                	ld	s1,8(sp)
    80000a20:	6902                	ld	s2,0(sp)
    80000a22:	6105                	addi	sp,sp,32
    80000a24:	8082                	ret

0000000080000a26 <kfree>:
// which normally should have been returned by a
// call to kalloc().  (The exception is when
// initializing the allocator; see kinit above.)
void
kfree(void *pa)
{
    80000a26:	1101                	addi	sp,sp,-32
    80000a28:	ec06                	sd	ra,24(sp)
    80000a2a:	e822                	sd	s0,16(sp)
    80000a2c:	e426                	sd	s1,8(sp)
    80000a2e:	e04a                	sd	s2,0(sp)
    80000a30:	1000                	addi	s0,sp,32
  struct run *r;

  if (((uint64)pa % PGSIZE) != 0 || (char *)pa < end || (uint64)pa >= PHYSTOP)
    80000a32:	00023797          	auipc	a5,0x23
    80000a36:	c1e78793          	addi	a5,a5,-994 # 80023650 <end>
    80000a3a:	00f53733          	sltu	a4,a0,a5
    80000a3e:	47c5                	li	a5,17
    80000a40:	07ee                	slli	a5,a5,0x1b
    80000a42:	17fd                	addi	a5,a5,-1
    80000a44:	00a7b7b3          	sltu	a5,a5,a0
    80000a48:	8fd9                	or	a5,a5,a4
    80000a4a:	ef95                	bnez	a5,80000a86 <kfree+0x60>
    80000a4c:	84aa                	mv	s1,a0
    80000a4e:	03451793          	slli	a5,a0,0x34
    80000a52:	eb95                	bnez	a5,80000a86 <kfree+0x60>
    panic("kfree");

  // Fill with junk to catch dangling refs.
  memset(pa, 1, PGSIZE);
    80000a54:	6605                	lui	a2,0x1
    80000a56:	4585                	li	a1,1
    80000a58:	250000ef          	jal	80000ca8 <memset>

  r = (struct run *)pa;

  acquire(&kmem.lock);
    80000a5c:	00012917          	auipc	s2,0x12
    80000a60:	9c490913          	addi	s2,s2,-1596 # 80012420 <kmem>
    80000a64:	854a                	mv	a0,s2
    80000a66:	182000ef          	jal	80000be8 <acquire>
  r->next = kmem.freelist;
    80000a6a:	01893783          	ld	a5,24(s2)
    80000a6e:	e09c                	sd	a5,0(s1)
  kmem.freelist = r;
    80000a70:	00993c23          	sd	s1,24(s2)
  release(&kmem.lock);
    80000a74:	854a                	mv	a0,s2
    80000a76:	1fa000ef          	jal	80000c70 <release>
}
    80000a7a:	60e2                	ld	ra,24(sp)
    80000a7c:	6442                	ld	s0,16(sp)
    80000a7e:	64a2                	ld	s1,8(sp)
    80000a80:	6902                	ld	s2,0(sp)
    80000a82:	6105                	addi	sp,sp,32
    80000a84:	8082                	ret
    panic("kfree");
    80000a86:	00006517          	auipc	a0,0x6
    80000a8a:	5b250513          	addi	a0,a0,1458 # 80007038 <etext+0x38>
    80000a8e:	da7ff0ef          	jal	80000834 <panic>

0000000080000a92 <freerange>:
{
    80000a92:	7179                	addi	sp,sp,-48
    80000a94:	f406                	sd	ra,40(sp)
    80000a96:	f022                	sd	s0,32(sp)
    80000a98:	ec26                	sd	s1,24(sp)
    80000a9a:	1800                	addi	s0,sp,48
  p = (char *)PGROUNDUP((uint64)pa_start);
    80000a9c:	6785                	lui	a5,0x1
    80000a9e:	fff78713          	addi	a4,a5,-1 # fff <_entry-0x7ffff001>
    80000aa2:	00e504b3          	add	s1,a0,a4
    80000aa6:	777d                	lui	a4,0xfffff
    80000aa8:	8cf9                	and	s1,s1,a4
  for (; p + PGSIZE <= (char *)pa_end; p += PGSIZE)
    80000aaa:	94be                	add	s1,s1,a5
    80000aac:	0295e263          	bltu	a1,s1,80000ad0 <freerange+0x3e>
    80000ab0:	e84a                	sd	s2,16(sp)
    80000ab2:	e44e                	sd	s3,8(sp)
    80000ab4:	e052                	sd	s4,0(sp)
    80000ab6:	892e                	mv	s2,a1
    kfree(p);
    80000ab8:	8a3a                	mv	s4,a4
  for (; p + PGSIZE <= (char *)pa_end; p += PGSIZE)
    80000aba:	89be                	mv	s3,a5
    kfree(p);
    80000abc:	01448533          	add	a0,s1,s4
    80000ac0:	f67ff0ef          	jal	80000a26 <kfree>
  for (; p + PGSIZE <= (char *)pa_end; p += PGSIZE)
    80000ac4:	94ce                	add	s1,s1,s3
    80000ac6:	fe997be3          	bgeu	s2,s1,80000abc <freerange+0x2a>
    80000aca:	6942                	ld	s2,16(sp)
    80000acc:	69a2                	ld	s3,8(sp)
    80000ace:	6a02                	ld	s4,0(sp)
}
    80000ad0:	70a2                	ld	ra,40(sp)
    80000ad2:	7402                	ld	s0,32(sp)
    80000ad4:	64e2                	ld	s1,24(sp)
    80000ad6:	6145                	addi	sp,sp,48
    80000ad8:	8082                	ret

0000000080000ada <kinit>:
{
    80000ada:	1141                	addi	sp,sp,-16
    80000adc:	e406                	sd	ra,8(sp)
    80000ade:	e022                	sd	s0,0(sp)
    80000ae0:	0800                	addi	s0,sp,16
  initlock(&kmem.lock, "kmem");
    80000ae2:	00006597          	auipc	a1,0x6
    80000ae6:	55e58593          	addi	a1,a1,1374 # 80007040 <etext+0x40>
    80000aea:	00012517          	auipc	a0,0x12
    80000aee:	93650513          	addi	a0,a0,-1738 # 80012420 <kmem>
    80000af2:	076000ef          	jal	80000b68 <initlock>
  freerange(end, (void *)PHYSTOP);
    80000af6:	45c5                	li	a1,17
    80000af8:	05ee                	slli	a1,a1,0x1b
    80000afa:	00023517          	auipc	a0,0x23
    80000afe:	b5650513          	addi	a0,a0,-1194 # 80023650 <end>
    80000b02:	f91ff0ef          	jal	80000a92 <freerange>
}
    80000b06:	60a2                	ld	ra,8(sp)
    80000b08:	6402                	ld	s0,0(sp)
    80000b0a:	0141                	addi	sp,sp,16
    80000b0c:	8082                	ret

0000000080000b0e <kalloc>:
// Allocate one 4096-byte page of physical memory.
// Returns a pointer that the kernel can use.
// Returns 0 if the memory cannot be allocated.
void *
kalloc(void)
{
    80000b0e:	1101                	addi	sp,sp,-32
    80000b10:	ec06                	sd	ra,24(sp)
    80000b12:	e822                	sd	s0,16(sp)
    80000b14:	e426                	sd	s1,8(sp)
    80000b16:	1000                	addi	s0,sp,32
  struct run *r;

  acquire(&kmem.lock);
    80000b18:	00012517          	auipc	a0,0x12
    80000b1c:	90850513          	addi	a0,a0,-1784 # 80012420 <kmem>
    80000b20:	0c8000ef          	jal	80000be8 <acquire>
  r = kmem.freelist;
    80000b24:	00012497          	auipc	s1,0x12
    80000b28:	9144b483          	ld	s1,-1772(s1) # 80012438 <kmem+0x18>
  if (r)
    80000b2c:	c49d                	beqz	s1,80000b5a <kalloc+0x4c>
    kmem.freelist = r->next;
    80000b2e:	609c                	ld	a5,0(s1)
    80000b30:	00012717          	auipc	a4,0x12
    80000b34:	90f73423          	sd	a5,-1784(a4) # 80012438 <kmem+0x18>
  release(&kmem.lock);
    80000b38:	00012517          	auipc	a0,0x12
    80000b3c:	8e850513          	addi	a0,a0,-1816 # 80012420 <kmem>
    80000b40:	130000ef          	jal	80000c70 <release>

  if (r)
    memset((char *)r, 5, PGSIZE); // fill with junk
    80000b44:	6605                	lui	a2,0x1
    80000b46:	4595                	li	a1,5
    80000b48:	8526                	mv	a0,s1
    80000b4a:	15e000ef          	jal	80000ca8 <memset>
  return (void *)r;
}
    80000b4e:	8526                	mv	a0,s1
    80000b50:	60e2                	ld	ra,24(sp)
    80000b52:	6442                	ld	s0,16(sp)
    80000b54:	64a2                	ld	s1,8(sp)
    80000b56:	6105                	addi	sp,sp,32
    80000b58:	8082                	ret
  release(&kmem.lock);
    80000b5a:	00012517          	auipc	a0,0x12
    80000b5e:	8c650513          	addi	a0,a0,-1850 # 80012420 <kmem>
    80000b62:	10e000ef          	jal	80000c70 <release>
  if (r)
    80000b66:	b7e5                	j	80000b4e <kalloc+0x40>

0000000080000b68 <initlock>:
#include "proc.h"
#include "defs.h"

void
initlock(struct spinlock *lk, char *name)
{
    80000b68:	1141                	addi	sp,sp,-16
    80000b6a:	e406                	sd	ra,8(sp)
    80000b6c:	e022                	sd	s0,0(sp)
    80000b6e:	0800                	addi	s0,sp,16
  lk->name = name;
    80000b70:	e50c                	sd	a1,8(a0)
  lk->locked = 0;
    80000b72:	00052023          	sw	zero,0(a0)
  lk->cpu = 0;
    80000b76:	00053823          	sd	zero,16(a0)
}
    80000b7a:	60a2                	ld	ra,8(sp)
    80000b7c:	6402                	ld	s0,0(sp)
    80000b7e:	0141                	addi	sp,sp,16
    80000b80:	8082                	ret

0000000080000b82 <holding>:
// Interrupts must be off.
int
holding(struct spinlock *lk)
{
  int r;
  r = (lk->locked && lk->cpu == mycpu());
    80000b82:	411c                	lw	a5,0(a0)
    80000b84:	e399                	bnez	a5,80000b8a <holding+0x8>
    80000b86:	4501                	li	a0,0
  return r;
}
    80000b88:	8082                	ret
{
    80000b8a:	1101                	addi	sp,sp,-32
    80000b8c:	ec06                	sd	ra,24(sp)
    80000b8e:	e822                	sd	s0,16(sp)
    80000b90:	e426                	sd	s1,8(sp)
    80000b92:	1000                	addi	s0,sp,32
  r = (lk->locked && lk->cpu == mycpu());
    80000b94:	691c                	ld	a5,16(a0)
    80000b96:	84be                	mv	s1,a5
    80000b98:	551000ef          	jal	800018e8 <mycpu>
    80000b9c:	40a48533          	sub	a0,s1,a0
    80000ba0:	00153513          	seqz	a0,a0
}
    80000ba4:	60e2                	ld	ra,24(sp)
    80000ba6:	6442                	ld	s0,16(sp)
    80000ba8:	64a2                	ld	s1,8(sp)
    80000baa:	6105                	addi	sp,sp,32
    80000bac:	8082                	ret

0000000080000bae <push_off>:
// it takes two pop_off()s to undo two push_off()s.  Also, if interrupts
// are initially off, then push_off, pop_off leaves them off.

void
push_off(void)
{
    80000bae:	1101                	addi	sp,sp,-32
    80000bb0:	ec06                	sd	ra,24(sp)
    80000bb2:	e822                	sd	s0,16(sp)
    80000bb4:	e426                	sd	s1,8(sp)
    80000bb6:	1000                	addi	s0,sp,32
  __asm__ __volatile__("csrrc %0, sstatus, %1" : "=r"(x) : "rK"(x) : "memory");
    80000bb8:	100177f3          	csrrci	a5,sstatus,2
    80000bbc:	84be                	mv	s1,a5
  // disable interrupts to prevent an involuntary context
  // switch while using mycpu().
  uint64 flags = rc_sstatus(SSTATUS_SIE);
  int old = !!(flags & SSTATUS_SIE);

  if (mycpu()->noff == 0)
    80000bbe:	52b000ef          	jal	800018e8 <mycpu>
    80000bc2:	5d3c                	lw	a5,120(a0)
    80000bc4:	cb99                	beqz	a5,80000bda <push_off+0x2c>
    mycpu()->intena = old;
  mycpu()->noff += 1;
    80000bc6:	523000ef          	jal	800018e8 <mycpu>
    80000bca:	5d3c                	lw	a5,120(a0)
    80000bcc:	2785                	addiw	a5,a5,1
    80000bce:	dd3c                	sw	a5,120(a0)
}
    80000bd0:	60e2                	ld	ra,24(sp)
    80000bd2:	6442                	ld	s0,16(sp)
    80000bd4:	64a2                	ld	s1,8(sp)
    80000bd6:	6105                	addi	sp,sp,32
    80000bd8:	8082                	ret
    mycpu()->intena = old;
    80000bda:	50f000ef          	jal	800018e8 <mycpu>
  int old = !!(flags & SSTATUS_SIE);
    80000bde:	0014d793          	srli	a5,s1,0x1
    80000be2:	8b85                	andi	a5,a5,1
    mycpu()->intena = old;
    80000be4:	dd7c                	sw	a5,124(a0)
    80000be6:	b7c5                	j	80000bc6 <push_off+0x18>

0000000080000be8 <acquire>:
{
    80000be8:	1101                	addi	sp,sp,-32
    80000bea:	ec06                	sd	ra,24(sp)
    80000bec:	e822                	sd	s0,16(sp)
    80000bee:	e426                	sd	s1,8(sp)
    80000bf0:	1000                	addi	s0,sp,32
    80000bf2:	84aa                	mv	s1,a0
  push_off(); // disable interrupts to avoid deadlock.
    80000bf4:	fbbff0ef          	jal	80000bae <push_off>
  if (holding(lk))
    80000bf8:	8526                	mv	a0,s1
    80000bfa:	f89ff0ef          	jal	80000b82 <holding>
  while (__atomic_exchange_n(&lk->locked, 1, __ATOMIC_ACQUIRE) != 0)
    80000bfe:	4705                	li	a4,1
  if (holding(lk))
    80000c00:	ed11                	bnez	a0,80000c1c <acquire+0x34>
  while (__atomic_exchange_n(&lk->locked, 1, __ATOMIC_ACQUIRE) != 0)
    80000c02:	87ba                	mv	a5,a4
    80000c04:	0cf4a7af          	amoswap.w.aq	a5,a5,(s1)
    80000c08:	2781                	sext.w	a5,a5
    80000c0a:	ffe5                	bnez	a5,80000c02 <acquire+0x1a>
  lk->cpu = mycpu();
    80000c0c:	4dd000ef          	jal	800018e8 <mycpu>
    80000c10:	e888                	sd	a0,16(s1)
}
    80000c12:	60e2                	ld	ra,24(sp)
    80000c14:	6442                	ld	s0,16(sp)
    80000c16:	64a2                	ld	s1,8(sp)
    80000c18:	6105                	addi	sp,sp,32
    80000c1a:	8082                	ret
    panic("acquire");
    80000c1c:	00006517          	auipc	a0,0x6
    80000c20:	42c50513          	addi	a0,a0,1068 # 80007048 <etext+0x48>
    80000c24:	c11ff0ef          	jal	80000834 <panic>

0000000080000c28 <pop_off>:

void
pop_off(void)
{
    80000c28:	1141                	addi	sp,sp,-16
    80000c2a:	e406                	sd	ra,8(sp)
    80000c2c:	e022                	sd	s0,0(sp)
    80000c2e:	0800                	addi	s0,sp,16
  struct cpu *c = mycpu();
    80000c30:	4b9000ef          	jal	800018e8 <mycpu>
  asm volatile("csrr %0, sstatus" : "=r"(x));
    80000c34:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80000c38:	8b89                	andi	a5,a5,2
  if (intr_get())
    80000c3a:	ef99                	bnez	a5,80000c58 <pop_off+0x30>
    panic("pop_off - interruptible");
  if (c->noff < 1)
    80000c3c:	5d3c                	lw	a5,120(a0)
    80000c3e:	02f05363          	blez	a5,80000c64 <pop_off+0x3c>
    panic("pop_off");
  c->noff -= 1;
    80000c42:	37fd                	addiw	a5,a5,-1
    80000c44:	dd3c                	sw	a5,120(a0)
  if (c->noff == 0 && c->intena)
    80000c46:	e789                	bnez	a5,80000c50 <pop_off+0x28>
    80000c48:	5d7c                	lw	a5,124(a0)
    80000c4a:	c399                	beqz	a5,80000c50 <pop_off+0x28>
  __asm__ __volatile__("csrs sstatus, %0" ::"rK"(x) : "memory");
    80000c4c:	10016073          	csrsi	sstatus,2
    intr_on();
}
    80000c50:	60a2                	ld	ra,8(sp)
    80000c52:	6402                	ld	s0,0(sp)
    80000c54:	0141                	addi	sp,sp,16
    80000c56:	8082                	ret
    panic("pop_off - interruptible");
    80000c58:	00006517          	auipc	a0,0x6
    80000c5c:	3f850513          	addi	a0,a0,1016 # 80007050 <etext+0x50>
    80000c60:	bd5ff0ef          	jal	80000834 <panic>
    panic("pop_off");
    80000c64:	00006517          	auipc	a0,0x6
    80000c68:	40450513          	addi	a0,a0,1028 # 80007068 <etext+0x68>
    80000c6c:	bc9ff0ef          	jal	80000834 <panic>

0000000080000c70 <release>:
{
    80000c70:	1101                	addi	sp,sp,-32
    80000c72:	ec06                	sd	ra,24(sp)
    80000c74:	e822                	sd	s0,16(sp)
    80000c76:	e426                	sd	s1,8(sp)
    80000c78:	1000                	addi	s0,sp,32
    80000c7a:	84aa                	mv	s1,a0
  if (!holding(lk))
    80000c7c:	f07ff0ef          	jal	80000b82 <holding>
    80000c80:	cd11                	beqz	a0,80000c9c <release+0x2c>
  lk->cpu = 0;
    80000c82:	0004b823          	sd	zero,16(s1)
  __atomic_store_n(&lk->locked, 0, __ATOMIC_RELEASE);
    80000c86:	0310000f          	fence	rw,w
    80000c8a:	0004a023          	sw	zero,0(s1)
  pop_off();
    80000c8e:	f9bff0ef          	jal	80000c28 <pop_off>
}
    80000c92:	60e2                	ld	ra,24(sp)
    80000c94:	6442                	ld	s0,16(sp)
    80000c96:	64a2                	ld	s1,8(sp)
    80000c98:	6105                	addi	sp,sp,32
    80000c9a:	8082                	ret
    panic("release");
    80000c9c:	00006517          	auipc	a0,0x6
    80000ca0:	3d450513          	addi	a0,a0,980 # 80007070 <etext+0x70>
    80000ca4:	b91ff0ef          	jal	80000834 <panic>

0000000080000ca8 <memset>:
#include "types.h"

void *
memset(void *dst, int c, uint n)
{
    80000ca8:	1141                	addi	sp,sp,-16
    80000caa:	e406                	sd	ra,8(sp)
    80000cac:	e022                	sd	s0,0(sp)
    80000cae:	0800                	addi	s0,sp,16
  char *cdst = (char *)dst;
  int i;
  for (i = 0; i < n; i++) {
    80000cb0:	ca19                	beqz	a2,80000cc6 <memset+0x1e>
    80000cb2:	87aa                	mv	a5,a0
    80000cb4:	1602                	slli	a2,a2,0x20
    80000cb6:	9201                	srli	a2,a2,0x20
    80000cb8:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
    80000cbc:	00b78023          	sb	a1,0(a5)
  for (i = 0; i < n; i++) {
    80000cc0:	0785                	addi	a5,a5,1
    80000cc2:	fee79de3          	bne	a5,a4,80000cbc <memset+0x14>
  }
  return dst;
}
    80000cc6:	60a2                	ld	ra,8(sp)
    80000cc8:	6402                	ld	s0,0(sp)
    80000cca:	0141                	addi	sp,sp,16
    80000ccc:	8082                	ret

0000000080000cce <memcmp>:

int
memcmp(const void *v1, const void *v2, uint n)
{
    80000cce:	1141                	addi	sp,sp,-16
    80000cd0:	e406                	sd	ra,8(sp)
    80000cd2:	e022                	sd	s0,0(sp)
    80000cd4:	0800                	addi	s0,sp,16
  const uchar *s1, *s2;

  s1 = v1;
  s2 = v2;
  while (n-- > 0) {
    80000cd6:	c61d                	beqz	a2,80000d04 <memcmp+0x36>
    80000cd8:	1602                	slli	a2,a2,0x20
    80000cda:	9201                	srli	a2,a2,0x20
    80000cdc:	00c506b3          	add	a3,a0,a2
    if (*s1 != *s2)
    80000ce0:	00054783          	lbu	a5,0(a0)
    80000ce4:	0005c703          	lbu	a4,0(a1)
    80000ce8:	00e79863          	bne	a5,a4,80000cf8 <memcmp+0x2a>
      return *s1 - *s2;
    s1++, s2++;
    80000cec:	0505                	addi	a0,a0,1
    80000cee:	0585                	addi	a1,a1,1
  while (n-- > 0) {
    80000cf0:	fed518e3          	bne	a0,a3,80000ce0 <memcmp+0x12>
  }

  return 0;
    80000cf4:	4501                	li	a0,0
    80000cf6:	a019                	j	80000cfc <memcmp+0x2e>
      return *s1 - *s2;
    80000cf8:	40e7853b          	subw	a0,a5,a4
}
    80000cfc:	60a2                	ld	ra,8(sp)
    80000cfe:	6402                	ld	s0,0(sp)
    80000d00:	0141                	addi	sp,sp,16
    80000d02:	8082                	ret
  return 0;
    80000d04:	4501                	li	a0,0
    80000d06:	bfdd                	j	80000cfc <memcmp+0x2e>

0000000080000d08 <memmove>:

void *
memmove(void *dst, const void *src, uint n)
{
    80000d08:	1141                	addi	sp,sp,-16
    80000d0a:	e406                	sd	ra,8(sp)
    80000d0c:	e022                	sd	s0,0(sp)
    80000d0e:	0800                	addi	s0,sp,16
  const char *s;
  char *d;

  if (n == 0)
    80000d10:	c205                	beqz	a2,80000d30 <memmove+0x28>
    return dst;

  s = src;
  d = dst;
  if (s < d && s + n > d) {
    80000d12:	02a5e363          	bltu	a1,a0,80000d38 <memmove+0x30>
    s += n;
    d += n;
    while (n-- > 0)
      *--d = *--s;
  } else
    while (n-- > 0)
    80000d16:	1602                	slli	a2,a2,0x20
    80000d18:	9201                	srli	a2,a2,0x20
    80000d1a:	00c587b3          	add	a5,a1,a2
{
    80000d1e:	872a                	mv	a4,a0
      *d++ = *s++;
    80000d20:	0585                	addi	a1,a1,1
    80000d22:	0705                	addi	a4,a4,1
    80000d24:	fff5c683          	lbu	a3,-1(a1)
    80000d28:	fed70fa3          	sb	a3,-1(a4)
    while (n-- > 0)
    80000d2c:	feb79ae3          	bne	a5,a1,80000d20 <memmove+0x18>

  return dst;
}
    80000d30:	60a2                	ld	ra,8(sp)
    80000d32:	6402                	ld	s0,0(sp)
    80000d34:	0141                	addi	sp,sp,16
    80000d36:	8082                	ret
  if (s < d && s + n > d) {
    80000d38:	02061693          	slli	a3,a2,0x20
    80000d3c:	9281                	srli	a3,a3,0x20
    80000d3e:	00d58733          	add	a4,a1,a3
    80000d42:	fce57ae3          	bgeu	a0,a4,80000d16 <memmove+0xe>
    d += n;
    80000d46:	96aa                	add	a3,a3,a0
    while (n-- > 0)
    80000d48:	fff6079b          	addiw	a5,a2,-1 # fff <_entry-0x7ffff001>
    80000d4c:	1782                	slli	a5,a5,0x20
    80000d4e:	9381                	srli	a5,a5,0x20
    80000d50:	fff7c793          	not	a5,a5
    80000d54:	97ba                	add	a5,a5,a4
      *--d = *--s;
    80000d56:	177d                	addi	a4,a4,-1
    80000d58:	16fd                	addi	a3,a3,-1
    80000d5a:	00074603          	lbu	a2,0(a4)
    80000d5e:	00c68023          	sb	a2,0(a3)
    while (n-- > 0)
    80000d62:	fee79ae3          	bne	a5,a4,80000d56 <memmove+0x4e>
    80000d66:	b7e9                	j	80000d30 <memmove+0x28>

0000000080000d68 <memcpy>:

// memcpy exists to placate GCC.  Use memmove.
void *
memcpy(void *dst, const void *src, uint n)
{
    80000d68:	1141                	addi	sp,sp,-16
    80000d6a:	e406                	sd	ra,8(sp)
    80000d6c:	e022                	sd	s0,0(sp)
    80000d6e:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
    80000d70:	f99ff0ef          	jal	80000d08 <memmove>
}
    80000d74:	60a2                	ld	ra,8(sp)
    80000d76:	6402                	ld	s0,0(sp)
    80000d78:	0141                	addi	sp,sp,16
    80000d7a:	8082                	ret

0000000080000d7c <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
    80000d7c:	1141                	addi	sp,sp,-16
    80000d7e:	e406                	sd	ra,8(sp)
    80000d80:	e022                	sd	s0,0(sp)
    80000d82:	0800                	addi	s0,sp,16
  while (n > 0 && *p && *p == *q)
    80000d84:	ce11                	beqz	a2,80000da0 <strncmp+0x24>
    80000d86:	00054783          	lbu	a5,0(a0)
    80000d8a:	cf89                	beqz	a5,80000da4 <strncmp+0x28>
    80000d8c:	0005c703          	lbu	a4,0(a1)
    80000d90:	00f71a63          	bne	a4,a5,80000da4 <strncmp+0x28>
    n--, p++, q++;
    80000d94:	367d                	addiw	a2,a2,-1
    80000d96:	0505                	addi	a0,a0,1
    80000d98:	0585                	addi	a1,a1,1
  while (n > 0 && *p && *p == *q)
    80000d9a:	f675                	bnez	a2,80000d86 <strncmp+0xa>
  if (n == 0)
    return 0;
    80000d9c:	4501                	li	a0,0
    80000d9e:	a801                	j	80000dae <strncmp+0x32>
    80000da0:	4501                	li	a0,0
    80000da2:	a031                	j	80000dae <strncmp+0x32>
  return (uchar)*p - (uchar)*q;
    80000da4:	00054503          	lbu	a0,0(a0)
    80000da8:	0005c783          	lbu	a5,0(a1)
    80000dac:	9d1d                	subw	a0,a0,a5
}
    80000dae:	60a2                	ld	ra,8(sp)
    80000db0:	6402                	ld	s0,0(sp)
    80000db2:	0141                	addi	sp,sp,16
    80000db4:	8082                	ret

0000000080000db6 <strncpy>:

char *
strncpy(char *s, const char *t, int n)
{
    80000db6:	1141                	addi	sp,sp,-16
    80000db8:	e406                	sd	ra,8(sp)
    80000dba:	e022                	sd	s0,0(sp)
    80000dbc:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while (n-- > 0 && (*s++ = *t++) != 0)
    80000dbe:	87aa                	mv	a5,a0
    80000dc0:	a011                	j	80000dc4 <strncpy+0xe>
    80000dc2:	8636                	mv	a2,a3
    80000dc4:	02c05863          	blez	a2,80000df4 <strncpy+0x3e>
    80000dc8:	fff6069b          	addiw	a3,a2,-1
    80000dcc:	8836                	mv	a6,a3
    80000dce:	0785                	addi	a5,a5,1
    80000dd0:	0005c703          	lbu	a4,0(a1)
    80000dd4:	fee78fa3          	sb	a4,-1(a5)
    80000dd8:	0585                	addi	a1,a1,1
    80000dda:	f765                	bnez	a4,80000dc2 <strncpy+0xc>
    ;
  while (n-- > 0)
    80000ddc:	873e                	mv	a4,a5
    80000dde:	01005b63          	blez	a6,80000df4 <strncpy+0x3e>
    80000de2:	9fb1                	addw	a5,a5,a2
    80000de4:	37fd                	addiw	a5,a5,-1
    *s++ = 0;
    80000de6:	0705                	addi	a4,a4,1
    80000de8:	fe070fa3          	sb	zero,-1(a4)
  while (n-- > 0)
    80000dec:	40e786bb          	subw	a3,a5,a4
    80000df0:	fed04be3          	bgtz	a3,80000de6 <strncpy+0x30>
  return os;
}
    80000df4:	60a2                	ld	ra,8(sp)
    80000df6:	6402                	ld	s0,0(sp)
    80000df8:	0141                	addi	sp,sp,16
    80000dfa:	8082                	ret

0000000080000dfc <safestrcpy>:

// Like strncpy but guaranteed to NUL-terminate.
char *
safestrcpy(char *s, const char *t, int n)
{
    80000dfc:	1141                	addi	sp,sp,-16
    80000dfe:	e406                	sd	ra,8(sp)
    80000e00:	e022                	sd	s0,0(sp)
    80000e02:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  if (n <= 0)
    80000e04:	02c05363          	blez	a2,80000e2a <safestrcpy+0x2e>
    80000e08:	fff6069b          	addiw	a3,a2,-1
    80000e0c:	1682                	slli	a3,a3,0x20
    80000e0e:	9281                	srli	a3,a3,0x20
    80000e10:	96ae                	add	a3,a3,a1
    80000e12:	87aa                	mv	a5,a0
    return os;
  while (--n > 0 && (*s++ = *t++) != 0)
    80000e14:	00d58963          	beq	a1,a3,80000e26 <safestrcpy+0x2a>
    80000e18:	0585                	addi	a1,a1,1
    80000e1a:	0785                	addi	a5,a5,1
    80000e1c:	fff5c703          	lbu	a4,-1(a1)
    80000e20:	fee78fa3          	sb	a4,-1(a5)
    80000e24:	fb65                	bnez	a4,80000e14 <safestrcpy+0x18>
    ;
  *s = 0;
    80000e26:	00078023          	sb	zero,0(a5)
  return os;
}
    80000e2a:	60a2                	ld	ra,8(sp)
    80000e2c:	6402                	ld	s0,0(sp)
    80000e2e:	0141                	addi	sp,sp,16
    80000e30:	8082                	ret

0000000080000e32 <strlen>:

int
strlen(const char *s)
{
    80000e32:	1141                	addi	sp,sp,-16
    80000e34:	e406                	sd	ra,8(sp)
    80000e36:	e022                	sd	s0,0(sp)
    80000e38:	0800                	addi	s0,sp,16
  int n;

  for (n = 0; s[n]; n++)
    80000e3a:	00054783          	lbu	a5,0(a0)
    80000e3e:	cf91                	beqz	a5,80000e5a <strlen+0x28>
    80000e40:	00150793          	addi	a5,a0,1
    80000e44:	86be                	mv	a3,a5
    80000e46:	0785                	addi	a5,a5,1
    80000e48:	fff7c703          	lbu	a4,-1(a5)
    80000e4c:	ff65                	bnez	a4,80000e44 <strlen+0x12>
    80000e4e:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
    80000e52:	60a2                	ld	ra,8(sp)
    80000e54:	6402                	ld	s0,0(sp)
    80000e56:	0141                	addi	sp,sp,16
    80000e58:	8082                	ret
  for (n = 0; s[n]; n++)
    80000e5a:	4501                	li	a0,0
    80000e5c:	bfdd                	j	80000e52 <strlen+0x20>

0000000080000e5e <main>:
volatile static int started = 0;

// start() jumps here in supervisor mode on all CPUs.
void
main()
{
    80000e5e:	1141                	addi	sp,sp,-16
    80000e60:	e406                	sd	ra,8(sp)
    80000e62:	e022                	sd	s0,0(sp)
    80000e64:	0800                	addi	s0,sp,16
  if (cpuid() == 0) {
    80000e66:	26f000ef          	jal	800018d4 <cpuid>
    virtio_disk_init(); // emulated hard disk
    userinit();         // first user process

    __atomic_store_n(&started, 1, __ATOMIC_RELEASE);
  } else {
    while (__atomic_load_n(&started, __ATOMIC_ACQUIRE) == 0)
    80000e6a:	00009717          	auipc	a4,0x9
    80000e6e:	4a270713          	addi	a4,a4,1186 # 8000a30c <started>
  if (cpuid() == 0) {
    80000e72:	c51d                	beqz	a0,80000ea0 <main+0x42>
    while (__atomic_load_n(&started, __ATOMIC_ACQUIRE) == 0)
    80000e74:	431c                	lw	a5,0(a4)
    80000e76:	0230000f          	fence	r,rw
    80000e7a:	2781                	sext.w	a5,a5
    80000e7c:	dfe5                	beqz	a5,80000e74 <main+0x16>
      ;

    printk("hart %d starting\n", cpuid());
    80000e7e:	257000ef          	jal	800018d4 <cpuid>
    80000e82:	85aa                	mv	a1,a0
    80000e84:	00006517          	auipc	a0,0x6
    80000e88:	21450513          	addi	a0,a0,532 # 80007098 <etext+0x98>
    80000e8c:	e7eff0ef          	jal	8000050a <printk>
    kvminithart();  // turn on paging
    80000e90:	082000ef          	jal	80000f12 <kvminithart>
    trapinithart(); // install kernel trap vector
    80000e94:	5da010ef          	jal	8000246e <trapinithart>
    plicinithart(); // ask PLIC for device interrupts
    80000e98:	011040ef          	jal	800056a8 <plicinithart>
  }

  scheduler();
    80000e9c:	6db000ef          	jal	80001d76 <scheduler>
    consoleinit();
    80000ea0:	d90ff0ef          	jal	80000430 <consoleinit>
    printkinit();
    80000ea4:	9cdff0ef          	jal	80000870 <printkinit>
    printk("\n");
    80000ea8:	00006517          	auipc	a0,0x6
    80000eac:	1d050513          	addi	a0,a0,464 # 80007078 <etext+0x78>
    80000eb0:	e5aff0ef          	jal	8000050a <printk>
    printk("xv6 kernel is booting\n");
    80000eb4:	00006517          	auipc	a0,0x6
    80000eb8:	1cc50513          	addi	a0,a0,460 # 80007080 <etext+0x80>
    80000ebc:	e4eff0ef          	jal	8000050a <printk>
    printk("\n");
    80000ec0:	00006517          	auipc	a0,0x6
    80000ec4:	1b850513          	addi	a0,a0,440 # 80007078 <etext+0x78>
    80000ec8:	e42ff0ef          	jal	8000050a <printk>
    kinit();            // physical page allocator
    80000ecc:	c0fff0ef          	jal	80000ada <kinit>
    kvminit();          // create kernel page table
    80000ed0:	2ce000ef          	jal	8000119e <kvminit>
    kvminithart();      // turn on paging
    80000ed4:	03e000ef          	jal	80000f12 <kvminithart>
    procinit();         // process table
    80000ed8:	147000ef          	jal	8000181e <procinit>
    trapinit();         // trap vectors
    80000edc:	56e010ef          	jal	8000244a <trapinit>
    trapinithart();     // install kernel trap vector
    80000ee0:	58e010ef          	jal	8000246e <trapinithart>
    plicinit();         // set up interrupt controller
    80000ee4:	7aa040ef          	jal	8000568e <plicinit>
    plicinithart();     // ask PLIC for device interrupts
    80000ee8:	7c0040ef          	jal	800056a8 <plicinithart>
    binit();            // buffer cache
    80000eec:	48b010ef          	jal	80002b76 <binit>
    iinit();            // inode table
    80000ef0:	1dc020ef          	jal	800030cc <iinit>
    fileinit();         // file table
    80000ef4:	20a030ef          	jal	800040fe <fileinit>
    virtio_disk_init(); // emulated hard disk
    80000ef8:	0a7040ef          	jal	8000579e <virtio_disk_init>
    userinit();         // first user process
    80000efc:	4cf000ef          	jal	80001bca <userinit>
    __atomic_store_n(&started, 1, __ATOMIC_RELEASE);
    80000f00:	00009797          	auipc	a5,0x9
    80000f04:	40c78793          	addi	a5,a5,1036 # 8000a30c <started>
    80000f08:	4705                	li	a4,1
    80000f0a:	0310000f          	fence	rw,w
    80000f0e:	c398                	sw	a4,0(a5)
    80000f10:	b771                	j	80000e9c <main+0x3e>

0000000080000f12 <kvminithart>:

// Switch the current CPU's h/w page table register to
// the kernel's page table, and enable paging.
void
kvminithart()
{
    80000f12:	1141                	addi	sp,sp,-16
    80000f14:	e406                	sd	ra,8(sp)
    80000f16:	e022                	sd	s0,0(sp)
    80000f18:	0800                	addi	s0,sp,16
// flush the TLB.
static inline void
sfence_vma()
{
  // the zero, zero means flush all TLB entries.
  asm volatile("sfence.vma zero, zero" ::: "memory");
    80000f1a:	12000073          	sfence.vma
  // wait for any previous writes to the page table memory to finish.
  sfence_vma();

  w_satp(MAKE_SATP(kernel_pagetable));
    80000f1e:	00009797          	auipc	a5,0x9
    80000f22:	3f27b783          	ld	a5,1010(a5) # 8000a310 <kernel_pagetable>
    80000f26:	83b1                	srli	a5,a5,0xc
    80000f28:	577d                	li	a4,-1
    80000f2a:	177e                	slli	a4,a4,0x3f
    80000f2c:	8fd9                	or	a5,a5,a4
  asm volatile("csrw satp, %0" : : "r"(x));
    80000f2e:	18079073          	csrw	satp,a5
  asm volatile("sfence.vma zero, zero" ::: "memory");
    80000f32:	12000073          	sfence.vma

  // flush stale entries from the TLB.
  sfence_vma();
}
    80000f36:	60a2                	ld	ra,8(sp)
    80000f38:	6402                	ld	s0,0(sp)
    80000f3a:	0141                	addi	sp,sp,16
    80000f3c:	8082                	ret

0000000080000f3e <walk>:
//   21..29 -- 9 bits of level-1 index.
//   12..20 -- 9 bits of level-0 index.
//    0..11 -- 12 bits of byte offset within the page.
pte_t *
walk(pagetable_t pagetable, uint64 va, int alloc)
{
    80000f3e:	7139                	addi	sp,sp,-64
    80000f40:	fc06                	sd	ra,56(sp)
    80000f42:	f822                	sd	s0,48(sp)
    80000f44:	f426                	sd	s1,40(sp)
    80000f46:	f04a                	sd	s2,32(sp)
    80000f48:	ec4e                	sd	s3,24(sp)
    80000f4a:	e852                	sd	s4,16(sp)
    80000f4c:	e456                	sd	s5,8(sp)
    80000f4e:	e05a                	sd	s6,0(sp)
    80000f50:	0080                	addi	s0,sp,64
    80000f52:	84aa                	mv	s1,a0
    80000f54:	89ae                	mv	s3,a1
    80000f56:	8b32                	mv	s6,a2
  if (va >= MAXVA)
    80000f58:	57fd                	li	a5,-1
    80000f5a:	83e9                	srli	a5,a5,0x1a
    80000f5c:	4a79                	li	s4,30
    panic("walk");

  for (int level = 2; level > 0; level--) {
    80000f5e:	4ab1                	li	s5,12
  if (va >= MAXVA)
    80000f60:	04b7e263          	bltu	a5,a1,80000fa4 <walk+0x66>
    pte_t *pte = &pagetable[PX(level, va)];
    80000f64:	0149d933          	srl	s2,s3,s4
    80000f68:	1ff97913          	andi	s2,s2,511
    80000f6c:	090e                	slli	s2,s2,0x3
    80000f6e:	9926                	add	s2,s2,s1
    if (*pte & PTE_V) {
    80000f70:	00093483          	ld	s1,0(s2)
    80000f74:	0014f793          	andi	a5,s1,1
    80000f78:	cf85                	beqz	a5,80000fb0 <walk+0x72>
      pagetable = (pagetable_t)PTE2PA(*pte);
    80000f7a:	80a9                	srli	s1,s1,0xa
    80000f7c:	04b2                	slli	s1,s1,0xc
  for (int level = 2; level > 0; level--) {
    80000f7e:	3a5d                	addiw	s4,s4,-9
    80000f80:	ff5a12e3          	bne	s4,s5,80000f64 <walk+0x26>
        return 0;
      memset(pagetable, 0, PGSIZE);
      *pte = PA2PTE(pagetable) | PTE_V;
    }
  }
  return &pagetable[PX(0, va)];
    80000f84:	00c9d513          	srli	a0,s3,0xc
    80000f88:	1ff57513          	andi	a0,a0,511
    80000f8c:	050e                	slli	a0,a0,0x3
    80000f8e:	9526                	add	a0,a0,s1
}
    80000f90:	70e2                	ld	ra,56(sp)
    80000f92:	7442                	ld	s0,48(sp)
    80000f94:	74a2                	ld	s1,40(sp)
    80000f96:	7902                	ld	s2,32(sp)
    80000f98:	69e2                	ld	s3,24(sp)
    80000f9a:	6a42                	ld	s4,16(sp)
    80000f9c:	6aa2                	ld	s5,8(sp)
    80000f9e:	6b02                	ld	s6,0(sp)
    80000fa0:	6121                	addi	sp,sp,64
    80000fa2:	8082                	ret
    panic("walk");
    80000fa4:	00006517          	auipc	a0,0x6
    80000fa8:	10c50513          	addi	a0,a0,268 # 800070b0 <etext+0xb0>
    80000fac:	889ff0ef          	jal	80000834 <panic>
      if (!alloc || (pagetable = (pde_t *)kalloc()) == 0)
    80000fb0:	020b0263          	beqz	s6,80000fd4 <walk+0x96>
    80000fb4:	b5bff0ef          	jal	80000b0e <kalloc>
    80000fb8:	84aa                	mv	s1,a0
    80000fba:	d979                	beqz	a0,80000f90 <walk+0x52>
      memset(pagetable, 0, PGSIZE);
    80000fbc:	6605                	lui	a2,0x1
    80000fbe:	4581                	li	a1,0
    80000fc0:	ce9ff0ef          	jal	80000ca8 <memset>
      *pte = PA2PTE(pagetable) | PTE_V;
    80000fc4:	00c4d793          	srli	a5,s1,0xc
    80000fc8:	07aa                	slli	a5,a5,0xa
    80000fca:	0017e793          	ori	a5,a5,1
    80000fce:	00f93023          	sd	a5,0(s2)
    80000fd2:	b775                	j	80000f7e <walk+0x40>
        return 0;
    80000fd4:	4501                	li	a0,0
    80000fd6:	bf6d                	j	80000f90 <walk+0x52>

0000000080000fd8 <walkaddr>:
walkaddr(pagetable_t pagetable, uint64 va)
{
  pte_t *pte;
  uint64 pa;

  if (va >= MAXVA)
    80000fd8:	57fd                	li	a5,-1
    80000fda:	83e9                	srli	a5,a5,0x1a
    80000fdc:	00b7f463          	bgeu	a5,a1,80000fe4 <walkaddr+0xc>
    return 0;
    80000fe0:	4501                	li	a0,0
    return 0;
  if ((*pte & PTE_U) == 0)
    return 0;
  pa = PTE2PA(*pte);
  return pa;
}
    80000fe2:	8082                	ret
{
    80000fe4:	1141                	addi	sp,sp,-16
    80000fe6:	e406                	sd	ra,8(sp)
    80000fe8:	e022                	sd	s0,0(sp)
    80000fea:	0800                	addi	s0,sp,16
  pte = walk(pagetable, va, 0);
    80000fec:	4601                	li	a2,0
    80000fee:	f51ff0ef          	jal	80000f3e <walk>
  if (pte == 0)
    80000ff2:	c901                	beqz	a0,80001002 <walkaddr+0x2a>
  if ((*pte & PTE_V) == 0)
    80000ff4:	611c                	ld	a5,0(a0)
  if ((*pte & PTE_U) == 0)
    80000ff6:	0117f693          	andi	a3,a5,17
    80000ffa:	4745                	li	a4,17
    return 0;
    80000ffc:	4501                	li	a0,0
  if ((*pte & PTE_U) == 0)
    80000ffe:	00e68663          	beq	a3,a4,8000100a <walkaddr+0x32>
}
    80001002:	60a2                	ld	ra,8(sp)
    80001004:	6402                	ld	s0,0(sp)
    80001006:	0141                	addi	sp,sp,16
    80001008:	8082                	ret
  pa = PTE2PA(*pte);
    8000100a:	83a9                	srli	a5,a5,0xa
    8000100c:	00c79513          	slli	a0,a5,0xc
  return pa;
    80001010:	bfcd                	j	80001002 <walkaddr+0x2a>

0000000080001012 <mappages>:
// va and size MUST be page-aligned.
// Returns 0 on success, -1 if walk() couldn't
// allocate a needed page-table page.
int
mappages(pagetable_t pagetable, uint64 va, uint64 size, uint64 pa, int perm)
{
    80001012:	715d                	addi	sp,sp,-80
    80001014:	e486                	sd	ra,72(sp)
    80001016:	e0a2                	sd	s0,64(sp)
    80001018:	fc26                	sd	s1,56(sp)
    8000101a:	f84a                	sd	s2,48(sp)
    8000101c:	f44e                	sd	s3,40(sp)
    8000101e:	f052                	sd	s4,32(sp)
    80001020:	ec56                	sd	s5,24(sp)
    80001022:	e85a                	sd	s6,16(sp)
    80001024:	e45e                	sd	s7,8(sp)
    80001026:	0880                	addi	s0,sp,80
  uint64 a, last;
  pte_t *pte;

  if ((va % PGSIZE) != 0)
    80001028:	03459793          	slli	a5,a1,0x34
    8000102c:	eba1                	bnez	a5,8000107c <mappages+0x6a>
    8000102e:	8a2a                	mv	s4,a0
    80001030:	8aba                	mv	s5,a4
    panic("mappages: va not aligned");

  if ((size % PGSIZE) != 0)
    80001032:	03461793          	slli	a5,a2,0x34
    80001036:	eba9                	bnez	a5,80001088 <mappages+0x76>
    panic("mappages: size not aligned");

  if (size == 0)
    80001038:	ce31                	beqz	a2,80001094 <mappages+0x82>
    panic("mappages: size");

  a = va;
  last = va + size - PGSIZE;
    8000103a:	80060613          	addi	a2,a2,-2048 # 800 <_entry-0x7ffff800>
    8000103e:	80060613          	addi	a2,a2,-2048
    80001042:	00b60933          	add	s2,a2,a1
  a = va;
    80001046:	84ae                	mv	s1,a1
  for (;;) {
    if ((pte = walk(pagetable, a, 1)) == 0)
    80001048:	4b05                	li	s6,1
    8000104a:	40b689b3          	sub	s3,a3,a1
    if (*pte & PTE_V)
      panic("mappages: remap");
    *pte = PA2PTE(pa) | perm | PTE_V;
    if (a == last)
      break;
    a += PGSIZE;
    8000104e:	6b85                	lui	s7,0x1
    if ((pte = walk(pagetable, a, 1)) == 0)
    80001050:	865a                	mv	a2,s6
    80001052:	85a6                	mv	a1,s1
    80001054:	8552                	mv	a0,s4
    80001056:	ee9ff0ef          	jal	80000f3e <walk>
    8000105a:	c929                	beqz	a0,800010ac <mappages+0x9a>
    if (*pte & PTE_V)
    8000105c:	611c                	ld	a5,0(a0)
    8000105e:	8b85                	andi	a5,a5,1
    80001060:	e3a1                	bnez	a5,800010a0 <mappages+0x8e>
    *pte = PA2PTE(pa) | perm | PTE_V;
    80001062:	013487b3          	add	a5,s1,s3
    80001066:	83b1                	srli	a5,a5,0xc
    80001068:	07aa                	slli	a5,a5,0xa
    8000106a:	0157e7b3          	or	a5,a5,s5
    8000106e:	0017e793          	ori	a5,a5,1
    80001072:	e11c                	sd	a5,0(a0)
    if (a == last)
    80001074:	05248863          	beq	s1,s2,800010c4 <mappages+0xb2>
    a += PGSIZE;
    80001078:	94de                	add	s1,s1,s7
    if ((pte = walk(pagetable, a, 1)) == 0)
    8000107a:	bfd9                	j	80001050 <mappages+0x3e>
    panic("mappages: va not aligned");
    8000107c:	00006517          	auipc	a0,0x6
    80001080:	03c50513          	addi	a0,a0,60 # 800070b8 <etext+0xb8>
    80001084:	fb0ff0ef          	jal	80000834 <panic>
    panic("mappages: size not aligned");
    80001088:	00006517          	auipc	a0,0x6
    8000108c:	05050513          	addi	a0,a0,80 # 800070d8 <etext+0xd8>
    80001090:	fa4ff0ef          	jal	80000834 <panic>
    panic("mappages: size");
    80001094:	00006517          	auipc	a0,0x6
    80001098:	06450513          	addi	a0,a0,100 # 800070f8 <etext+0xf8>
    8000109c:	f98ff0ef          	jal	80000834 <panic>
      panic("mappages: remap");
    800010a0:	00006517          	auipc	a0,0x6
    800010a4:	06850513          	addi	a0,a0,104 # 80007108 <etext+0x108>
    800010a8:	f8cff0ef          	jal	80000834 <panic>
      return -1;
    800010ac:	557d                	li	a0,-1
    pa += PGSIZE;
  }
  return 0;
}
    800010ae:	60a6                	ld	ra,72(sp)
    800010b0:	6406                	ld	s0,64(sp)
    800010b2:	74e2                	ld	s1,56(sp)
    800010b4:	7942                	ld	s2,48(sp)
    800010b6:	79a2                	ld	s3,40(sp)
    800010b8:	7a02                	ld	s4,32(sp)
    800010ba:	6ae2                	ld	s5,24(sp)
    800010bc:	6b42                	ld	s6,16(sp)
    800010be:	6ba2                	ld	s7,8(sp)
    800010c0:	6161                	addi	sp,sp,80
    800010c2:	8082                	ret
  return 0;
    800010c4:	4501                	li	a0,0
    800010c6:	b7e5                	j	800010ae <mappages+0x9c>

00000000800010c8 <kvmmap>:
{
    800010c8:	1141                	addi	sp,sp,-16
    800010ca:	e406                	sd	ra,8(sp)
    800010cc:	e022                	sd	s0,0(sp)
    800010ce:	0800                	addi	s0,sp,16
    800010d0:	87b6                	mv	a5,a3
  if (mappages(kpgtbl, va, sz, pa, perm) != 0)
    800010d2:	86b2                	mv	a3,a2
    800010d4:	863e                	mv	a2,a5
    800010d6:	f3dff0ef          	jal	80001012 <mappages>
    800010da:	e509                	bnez	a0,800010e4 <kvmmap+0x1c>
}
    800010dc:	60a2                	ld	ra,8(sp)
    800010de:	6402                	ld	s0,0(sp)
    800010e0:	0141                	addi	sp,sp,16
    800010e2:	8082                	ret
    panic("kvmmap");
    800010e4:	00006517          	auipc	a0,0x6
    800010e8:	03450513          	addi	a0,a0,52 # 80007118 <etext+0x118>
    800010ec:	f48ff0ef          	jal	80000834 <panic>

00000000800010f0 <kvmmake>:
{
    800010f0:	1101                	addi	sp,sp,-32
    800010f2:	ec06                	sd	ra,24(sp)
    800010f4:	e822                	sd	s0,16(sp)
    800010f6:	e426                	sd	s1,8(sp)
    800010f8:	1000                	addi	s0,sp,32
  kpgtbl = (pagetable_t)kalloc();
    800010fa:	a15ff0ef          	jal	80000b0e <kalloc>
    800010fe:	84aa                	mv	s1,a0
  memset(kpgtbl, 0, PGSIZE);
    80001100:	6605                	lui	a2,0x1
    80001102:	4581                	li	a1,0
    80001104:	ba5ff0ef          	jal	80000ca8 <memset>
  kvmmap(kpgtbl, UART0, UART0, PGSIZE, PTE_R | PTE_W);
    80001108:	4719                	li	a4,6
    8000110a:	6685                	lui	a3,0x1
    8000110c:	10000637          	lui	a2,0x10000
    80001110:	85b2                	mv	a1,a2
    80001112:	8526                	mv	a0,s1
    80001114:	fb5ff0ef          	jal	800010c8 <kvmmap>
  kvmmap(kpgtbl, VIRTIO0, VIRTIO0, PGSIZE, PTE_R | PTE_W);
    80001118:	4719                	li	a4,6
    8000111a:	6685                	lui	a3,0x1
    8000111c:	10001637          	lui	a2,0x10001
    80001120:	85b2                	mv	a1,a2
    80001122:	8526                	mv	a0,s1
    80001124:	fa5ff0ef          	jal	800010c8 <kvmmap>
  kvmmap(kpgtbl, PLIC, PLIC, 0x4000000, PTE_R | PTE_W);
    80001128:	4719                	li	a4,6
    8000112a:	040006b7          	lui	a3,0x4000
    8000112e:	0c000637          	lui	a2,0xc000
    80001132:	85b2                	mv	a1,a2
    80001134:	8526                	mv	a0,s1
    80001136:	f93ff0ef          	jal	800010c8 <kvmmap>
  kvmmap(kpgtbl, KERNBASE, KERNBASE, (uint64)etext - KERNBASE, PTE_R | PTE_X);
    8000113a:	4729                	li	a4,10
    8000113c:	80006697          	auipc	a3,0x80006
    80001140:	ec468693          	addi	a3,a3,-316 # 7000 <_entry-0x7fff9000>
    80001144:	4605                	li	a2,1
    80001146:	067e                	slli	a2,a2,0x1f
    80001148:	85b2                	mv	a1,a2
    8000114a:	8526                	mv	a0,s1
    8000114c:	f7dff0ef          	jal	800010c8 <kvmmap>
  kvmmap(kpgtbl, (uint64)etext, (uint64)etext, PHYSTOP - (uint64)etext,
    80001150:	4719                	li	a4,6
    80001152:	00006697          	auipc	a3,0x6
    80001156:	eae68693          	addi	a3,a3,-338 # 80007000 <etext>
    8000115a:	47c5                	li	a5,17
    8000115c:	07ee                	slli	a5,a5,0x1b
    8000115e:	40d786b3          	sub	a3,a5,a3
    80001162:	00006617          	auipc	a2,0x6
    80001166:	e9e60613          	addi	a2,a2,-354 # 80007000 <etext>
    8000116a:	85b2                	mv	a1,a2
    8000116c:	8526                	mv	a0,s1
    8000116e:	f5bff0ef          	jal	800010c8 <kvmmap>
  kvmmap(kpgtbl, TRAMPOLINE, (uint64)trampoline, PGSIZE, PTE_R | PTE_X);
    80001172:	4729                	li	a4,10
    80001174:	6685                	lui	a3,0x1
    80001176:	00005617          	auipc	a2,0x5
    8000117a:	e8a60613          	addi	a2,a2,-374 # 80006000 <_trampoline>
    8000117e:	040005b7          	lui	a1,0x4000
    80001182:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001184:	05b2                	slli	a1,a1,0xc
    80001186:	8526                	mv	a0,s1
    80001188:	f41ff0ef          	jal	800010c8 <kvmmap>
  proc_mapstacks(kpgtbl);
    8000118c:	8526                	mv	a0,s1
    8000118e:	5ec000ef          	jal	8000177a <proc_mapstacks>
}
    80001192:	8526                	mv	a0,s1
    80001194:	60e2                	ld	ra,24(sp)
    80001196:	6442                	ld	s0,16(sp)
    80001198:	64a2                	ld	s1,8(sp)
    8000119a:	6105                	addi	sp,sp,32
    8000119c:	8082                	ret

000000008000119e <kvminit>:
{
    8000119e:	1141                	addi	sp,sp,-16
    800011a0:	e406                	sd	ra,8(sp)
    800011a2:	e022                	sd	s0,0(sp)
    800011a4:	0800                	addi	s0,sp,16
  kernel_pagetable = kvmmake();
    800011a6:	f4bff0ef          	jal	800010f0 <kvmmake>
    800011aa:	00009797          	auipc	a5,0x9
    800011ae:	16a7b323          	sd	a0,358(a5) # 8000a310 <kernel_pagetable>
}
    800011b2:	60a2                	ld	ra,8(sp)
    800011b4:	6402                	ld	s0,0(sp)
    800011b6:	0141                	addi	sp,sp,16
    800011b8:	8082                	ret

00000000800011ba <uvmcreate>:

// create an empty user page table.
// returns 0 if out of memory.
pagetable_t
uvmcreate()
{
    800011ba:	1101                	addi	sp,sp,-32
    800011bc:	ec06                	sd	ra,24(sp)
    800011be:	e822                	sd	s0,16(sp)
    800011c0:	e426                	sd	s1,8(sp)
    800011c2:	1000                	addi	s0,sp,32
  pagetable_t pagetable;
  pagetable = (pagetable_t)kalloc();
    800011c4:	94bff0ef          	jal	80000b0e <kalloc>
    800011c8:	84aa                	mv	s1,a0
  if (pagetable == 0)
    800011ca:	c509                	beqz	a0,800011d4 <uvmcreate+0x1a>
    return 0;
  memset(pagetable, 0, PGSIZE);
    800011cc:	6605                	lui	a2,0x1
    800011ce:	4581                	li	a1,0
    800011d0:	ad9ff0ef          	jal	80000ca8 <memset>
  return pagetable;
}
    800011d4:	8526                	mv	a0,s1
    800011d6:	60e2                	ld	ra,24(sp)
    800011d8:	6442                	ld	s0,16(sp)
    800011da:	64a2                	ld	s1,8(sp)
    800011dc:	6105                	addi	sp,sp,32
    800011de:	8082                	ret

00000000800011e0 <uvmunmap>:
// Remove npages of mappings starting from va. va must be
// page-aligned. It's OK if the mappings don't exist.
// Optionally free the physical memory.
void
uvmunmap(pagetable_t pagetable, uint64 va, uint64 npages, int do_free)
{
    800011e0:	7139                	addi	sp,sp,-64
    800011e2:	fc06                	sd	ra,56(sp)
    800011e4:	f822                	sd	s0,48(sp)
    800011e6:	0080                	addi	s0,sp,64
  uint64 a;
  pte_t *pte;

  if ((va % PGSIZE) != 0)
    800011e8:	03459793          	slli	a5,a1,0x34
    800011ec:	e38d                	bnez	a5,8000120e <uvmunmap+0x2e>
    800011ee:	f04a                	sd	s2,32(sp)
    800011f0:	ec4e                	sd	s3,24(sp)
    800011f2:	e852                	sd	s4,16(sp)
    800011f4:	e456                	sd	s5,8(sp)
    800011f6:	e05a                	sd	s6,0(sp)
    800011f8:	8a2a                	mv	s4,a0
    800011fa:	892e                	mv	s2,a1
    800011fc:	8ab6                	mv	s5,a3
    panic("uvmunmap: not aligned");

  for (a = va; a < va + npages * PGSIZE; a += PGSIZE) {
    800011fe:	0632                	slli	a2,a2,0xc
    80001200:	00b609b3          	add	s3,a2,a1
    80001204:	6b05                	lui	s6,0x1
    80001206:	0535f963          	bgeu	a1,s3,80001258 <uvmunmap+0x78>
    8000120a:	f426                	sd	s1,40(sp)
    8000120c:	a015                	j	80001230 <uvmunmap+0x50>
    8000120e:	f426                	sd	s1,40(sp)
    80001210:	f04a                	sd	s2,32(sp)
    80001212:	ec4e                	sd	s3,24(sp)
    80001214:	e852                	sd	s4,16(sp)
    80001216:	e456                	sd	s5,8(sp)
    80001218:	e05a                	sd	s6,0(sp)
    panic("uvmunmap: not aligned");
    8000121a:	00006517          	auipc	a0,0x6
    8000121e:	f0650513          	addi	a0,a0,-250 # 80007120 <etext+0x120>
    80001222:	e12ff0ef          	jal	80000834 <panic>
      continue;
    if (do_free) {
      uint64 pa = PTE2PA(*pte);
      kfree((void *)pa);
    }
    *pte = 0;
    80001226:	0004b023          	sd	zero,0(s1)
  for (a = va; a < va + npages * PGSIZE; a += PGSIZE) {
    8000122a:	995a                	add	s2,s2,s6
    8000122c:	03397563          	bgeu	s2,s3,80001256 <uvmunmap+0x76>
    if ((pte = walk(pagetable, a, 0)) == 0) // leaf page table entry allocated?
    80001230:	4601                	li	a2,0
    80001232:	85ca                	mv	a1,s2
    80001234:	8552                	mv	a0,s4
    80001236:	d09ff0ef          	jal	80000f3e <walk>
    8000123a:	84aa                	mv	s1,a0
    8000123c:	d57d                	beqz	a0,8000122a <uvmunmap+0x4a>
    if ((*pte & PTE_V) == 0) // has physical page been allocated?
    8000123e:	611c                	ld	a5,0(a0)
    80001240:	0017f713          	andi	a4,a5,1
    80001244:	d37d                	beqz	a4,8000122a <uvmunmap+0x4a>
    if (do_free) {
    80001246:	fe0a80e3          	beqz	s5,80001226 <uvmunmap+0x46>
      uint64 pa = PTE2PA(*pte);
    8000124a:	83a9                	srli	a5,a5,0xa
      kfree((void *)pa);
    8000124c:	00c79513          	slli	a0,a5,0xc
    80001250:	fd6ff0ef          	jal	80000a26 <kfree>
    80001254:	bfc9                	j	80001226 <uvmunmap+0x46>
    80001256:	74a2                	ld	s1,40(sp)
    80001258:	7902                	ld	s2,32(sp)
    8000125a:	69e2                	ld	s3,24(sp)
    8000125c:	6a42                	ld	s4,16(sp)
    8000125e:	6aa2                	ld	s5,8(sp)
    80001260:	6b02                	ld	s6,0(sp)
  }
}
    80001262:	70e2                	ld	ra,56(sp)
    80001264:	7442                	ld	s0,48(sp)
    80001266:	6121                	addi	sp,sp,64
    80001268:	8082                	ret

000000008000126a <uvmdealloc>:
// newsz.  oldsz and newsz need not be page-aligned, nor does newsz
// need to be less than oldsz.  oldsz can be larger than the actual
// process size.  Returns the new process size.
uint64
uvmdealloc(pagetable_t pagetable, uint64 oldsz, uint64 newsz)
{
    8000126a:	1101                	addi	sp,sp,-32
    8000126c:	ec06                	sd	ra,24(sp)
    8000126e:	e822                	sd	s0,16(sp)
    80001270:	e426                	sd	s1,8(sp)
    80001272:	1000                	addi	s0,sp,32
  if (newsz >= oldsz)
    return oldsz;
    80001274:	84ae                	mv	s1,a1
  if (newsz >= oldsz)
    80001276:	00b67d63          	bgeu	a2,a1,80001290 <uvmdealloc+0x26>
    8000127a:	84b2                	mv	s1,a2

  if (PGROUNDUP(newsz) < PGROUNDUP(oldsz)) {
    8000127c:	6785                	lui	a5,0x1
    8000127e:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    80001280:	00f60733          	add	a4,a2,a5
    80001284:	76fd                	lui	a3,0xfffff
    80001286:	8f75                	and	a4,a4,a3
    80001288:	97ae                	add	a5,a5,a1
    8000128a:	8ff5                	and	a5,a5,a3
    8000128c:	00f76863          	bltu	a4,a5,8000129c <uvmdealloc+0x32>
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
  }

  return newsz;
}
    80001290:	8526                	mv	a0,s1
    80001292:	60e2                	ld	ra,24(sp)
    80001294:	6442                	ld	s0,16(sp)
    80001296:	64a2                	ld	s1,8(sp)
    80001298:	6105                	addi	sp,sp,32
    8000129a:	8082                	ret
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    8000129c:	8f99                	sub	a5,a5,a4
    8000129e:	83b1                	srli	a5,a5,0xc
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
    800012a0:	4685                	li	a3,1
    800012a2:	0007861b          	sext.w	a2,a5
    800012a6:	85ba                	mv	a1,a4
    800012a8:	f39ff0ef          	jal	800011e0 <uvmunmap>
    800012ac:	b7d5                	j	80001290 <uvmdealloc+0x26>

00000000800012ae <uvmalloc>:
  if (newsz < oldsz)
    800012ae:	0ab66163          	bltu	a2,a1,80001350 <uvmalloc+0xa2>
{
    800012b2:	715d                	addi	sp,sp,-80
    800012b4:	e486                	sd	ra,72(sp)
    800012b6:	e0a2                	sd	s0,64(sp)
    800012b8:	f84a                	sd	s2,48(sp)
    800012ba:	f052                	sd	s4,32(sp)
    800012bc:	ec56                	sd	s5,24(sp)
    800012be:	e45e                	sd	s7,8(sp)
    800012c0:	0880                	addi	s0,sp,80
    800012c2:	8aaa                	mv	s5,a0
    800012c4:	8a32                	mv	s4,a2
  oldsz = PGROUNDUP(oldsz);
    800012c6:	6785                	lui	a5,0x1
    800012c8:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    800012ca:	95be                	add	a1,a1,a5
    800012cc:	77fd                	lui	a5,0xfffff
    800012ce:	00f5f933          	and	s2,a1,a5
    800012d2:	8bca                	mv	s7,s2
  for (a = oldsz; a < newsz; a += PGSIZE) {
    800012d4:	08c97063          	bgeu	s2,a2,80001354 <uvmalloc+0xa6>
    800012d8:	fc26                	sd	s1,56(sp)
    800012da:	f44e                	sd	s3,40(sp)
    800012dc:	e85a                	sd	s6,16(sp)
    memset(mem, 0, PGSIZE);
    800012de:	6985                	lui	s3,0x1
    if (mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R | PTE_U | xperm) !=
    800012e0:	0126eb13          	ori	s6,a3,18
    mem = kalloc();
    800012e4:	82bff0ef          	jal	80000b0e <kalloc>
    800012e8:	84aa                	mv	s1,a0
    if (mem == 0) {
    800012ea:	c50d                	beqz	a0,80001314 <uvmalloc+0x66>
    memset(mem, 0, PGSIZE);
    800012ec:	864e                	mv	a2,s3
    800012ee:	4581                	li	a1,0
    800012f0:	9b9ff0ef          	jal	80000ca8 <memset>
    if (mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R | PTE_U | xperm) !=
    800012f4:	875a                	mv	a4,s6
    800012f6:	86a6                	mv	a3,s1
    800012f8:	864e                	mv	a2,s3
    800012fa:	85ca                	mv	a1,s2
    800012fc:	8556                	mv	a0,s5
    800012fe:	d15ff0ef          	jal	80001012 <mappages>
    80001302:	e915                	bnez	a0,80001336 <uvmalloc+0x88>
  for (a = oldsz; a < newsz; a += PGSIZE) {
    80001304:	994e                	add	s2,s2,s3
    80001306:	fd496fe3          	bltu	s2,s4,800012e4 <uvmalloc+0x36>
  return newsz;
    8000130a:	8552                	mv	a0,s4
    8000130c:	74e2                	ld	s1,56(sp)
    8000130e:	79a2                	ld	s3,40(sp)
    80001310:	6b42                	ld	s6,16(sp)
    80001312:	a811                	j	80001326 <uvmalloc+0x78>
      uvmdealloc(pagetable, a, oldsz);
    80001314:	865e                	mv	a2,s7
    80001316:	85ca                	mv	a1,s2
    80001318:	8556                	mv	a0,s5
    8000131a:	f51ff0ef          	jal	8000126a <uvmdealloc>
      return 0;
    8000131e:	4501                	li	a0,0
    80001320:	74e2                	ld	s1,56(sp)
    80001322:	79a2                	ld	s3,40(sp)
    80001324:	6b42                	ld	s6,16(sp)
}
    80001326:	60a6                	ld	ra,72(sp)
    80001328:	6406                	ld	s0,64(sp)
    8000132a:	7942                	ld	s2,48(sp)
    8000132c:	7a02                	ld	s4,32(sp)
    8000132e:	6ae2                	ld	s5,24(sp)
    80001330:	6ba2                	ld	s7,8(sp)
    80001332:	6161                	addi	sp,sp,80
    80001334:	8082                	ret
      kfree(mem);
    80001336:	8526                	mv	a0,s1
    80001338:	eeeff0ef          	jal	80000a26 <kfree>
      uvmdealloc(pagetable, a, oldsz);
    8000133c:	865e                	mv	a2,s7
    8000133e:	85ca                	mv	a1,s2
    80001340:	8556                	mv	a0,s5
    80001342:	f29ff0ef          	jal	8000126a <uvmdealloc>
      return 0;
    80001346:	4501                	li	a0,0
    80001348:	74e2                	ld	s1,56(sp)
    8000134a:	79a2                	ld	s3,40(sp)
    8000134c:	6b42                	ld	s6,16(sp)
    8000134e:	bfe1                	j	80001326 <uvmalloc+0x78>
    return oldsz;
    80001350:	852e                	mv	a0,a1
}
    80001352:	8082                	ret
  return newsz;
    80001354:	8532                	mv	a0,a2
    80001356:	bfc1                	j	80001326 <uvmalloc+0x78>

0000000080001358 <freewalk>:

// Recursively free page-table pages.
// All leaf mappings must already have been removed.
void
freewalk(pagetable_t pagetable)
{
    80001358:	7179                	addi	sp,sp,-48
    8000135a:	f406                	sd	ra,40(sp)
    8000135c:	f022                	sd	s0,32(sp)
    8000135e:	ec26                	sd	s1,24(sp)
    80001360:	e84a                	sd	s2,16(sp)
    80001362:	e44e                	sd	s3,8(sp)
    80001364:	1800                	addi	s0,sp,48
    80001366:	89aa                	mv	s3,a0
  // there are 2^9 = 512 PTEs in a page table.
  for (int i = 0; i < 512; i++) {
    80001368:	84aa                	mv	s1,a0
    8000136a:	6905                	lui	s2,0x1
    8000136c:	992a                	add	s2,s2,a0
    8000136e:	a811                	j	80001382 <freewalk+0x2a>
      // this PTE points to a lower-level page table.
      uint64 child = PTE2PA(pte);
      freewalk((pagetable_t)child);
      pagetable[i] = 0;
    } else if (pte & PTE_V) {
      panic("freewalk: leaf");
    80001370:	00006517          	auipc	a0,0x6
    80001374:	dc850513          	addi	a0,a0,-568 # 80007138 <etext+0x138>
    80001378:	cbcff0ef          	jal	80000834 <panic>
  for (int i = 0; i < 512; i++) {
    8000137c:	04a1                	addi	s1,s1,8
    8000137e:	03248163          	beq	s1,s2,800013a0 <freewalk+0x48>
    pte_t pte = pagetable[i];
    80001382:	609c                	ld	a5,0(s1)
    if ((pte & PTE_V) && (pte & (PTE_R | PTE_W | PTE_X)) == 0) {
    80001384:	0017f713          	andi	a4,a5,1
    80001388:	db75                	beqz	a4,8000137c <freewalk+0x24>
    8000138a:	00e7f713          	andi	a4,a5,14
    8000138e:	f36d                	bnez	a4,80001370 <freewalk+0x18>
      uint64 child = PTE2PA(pte);
    80001390:	83a9                	srli	a5,a5,0xa
      freewalk((pagetable_t)child);
    80001392:	00c79513          	slli	a0,a5,0xc
    80001396:	fc3ff0ef          	jal	80001358 <freewalk>
      pagetable[i] = 0;
    8000139a:	0004b023          	sd	zero,0(s1)
    if ((pte & PTE_V) && (pte & (PTE_R | PTE_W | PTE_X)) == 0) {
    8000139e:	bff9                	j	8000137c <freewalk+0x24>
    }
  }
  kfree((void *)pagetable);
    800013a0:	854e                	mv	a0,s3
    800013a2:	e84ff0ef          	jal	80000a26 <kfree>
}
    800013a6:	70a2                	ld	ra,40(sp)
    800013a8:	7402                	ld	s0,32(sp)
    800013aa:	64e2                	ld	s1,24(sp)
    800013ac:	6942                	ld	s2,16(sp)
    800013ae:	69a2                	ld	s3,8(sp)
    800013b0:	6145                	addi	sp,sp,48
    800013b2:	8082                	ret

00000000800013b4 <uvmfree>:

// Free user memory pages,
// then free page-table pages.
void
uvmfree(pagetable_t pagetable, uint64 sz)
{
    800013b4:	1101                	addi	sp,sp,-32
    800013b6:	ec06                	sd	ra,24(sp)
    800013b8:	e822                	sd	s0,16(sp)
    800013ba:	e426                	sd	s1,8(sp)
    800013bc:	1000                	addi	s0,sp,32
    800013be:	84aa                	mv	s1,a0
  if (sz > 0)
    800013c0:	e989                	bnez	a1,800013d2 <uvmfree+0x1e>
    uvmunmap(pagetable, 0, PGROUNDUP(sz) / PGSIZE, 1);
  freewalk(pagetable);
    800013c2:	8526                	mv	a0,s1
    800013c4:	f95ff0ef          	jal	80001358 <freewalk>
}
    800013c8:	60e2                	ld	ra,24(sp)
    800013ca:	6442                	ld	s0,16(sp)
    800013cc:	64a2                	ld	s1,8(sp)
    800013ce:	6105                	addi	sp,sp,32
    800013d0:	8082                	ret
    uvmunmap(pagetable, 0, PGROUNDUP(sz) / PGSIZE, 1);
    800013d2:	6785                	lui	a5,0x1
    800013d4:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    800013d6:	95be                	add	a1,a1,a5
    800013d8:	4685                	li	a3,1
    800013da:	00c5d613          	srli	a2,a1,0xc
    800013de:	4581                	li	a1,0
    800013e0:	e01ff0ef          	jal	800011e0 <uvmunmap>
    800013e4:	bff9                	j	800013c2 <uvmfree+0xe>

00000000800013e6 <uvmcopy>:
  pte_t *pte;
  uint64 pa, i;
  uint flags;
  char *mem;

  for (i = 0; i < sz; i += PGSIZE) {
    800013e6:	ca59                	beqz	a2,8000147c <uvmcopy+0x96>
{
    800013e8:	715d                	addi	sp,sp,-80
    800013ea:	e486                	sd	ra,72(sp)
    800013ec:	e0a2                	sd	s0,64(sp)
    800013ee:	fc26                	sd	s1,56(sp)
    800013f0:	f84a                	sd	s2,48(sp)
    800013f2:	f44e                	sd	s3,40(sp)
    800013f4:	f052                	sd	s4,32(sp)
    800013f6:	ec56                	sd	s5,24(sp)
    800013f8:	e85a                	sd	s6,16(sp)
    800013fa:	e45e                	sd	s7,8(sp)
    800013fc:	0880                	addi	s0,sp,80
    800013fe:	8b2a                	mv	s6,a0
    80001400:	8bae                	mv	s7,a1
    80001402:	8ab2                	mv	s5,a2
  for (i = 0; i < sz; i += PGSIZE) {
    80001404:	4481                	li	s1,0
      continue; // physical page hasn't been allocated
    pa = PTE2PA(*pte);
    flags = PTE_FLAGS(*pte);
    if ((mem = kalloc()) == 0)
      goto err;
    memmove(mem, (char *)pa, PGSIZE);
    80001406:	6a05                	lui	s4,0x1
    80001408:	a021                	j	80001410 <uvmcopy+0x2a>
  for (i = 0; i < sz; i += PGSIZE) {
    8000140a:	94d2                	add	s1,s1,s4
    8000140c:	0554fc63          	bgeu	s1,s5,80001464 <uvmcopy+0x7e>
    if ((pte = walk(old, i, 0)) == 0)
    80001410:	4601                	li	a2,0
    80001412:	85a6                	mv	a1,s1
    80001414:	855a                	mv	a0,s6
    80001416:	b29ff0ef          	jal	80000f3e <walk>
    8000141a:	d965                	beqz	a0,8000140a <uvmcopy+0x24>
    if ((*pte & PTE_V) == 0)
    8000141c:	00053983          	ld	s3,0(a0)
    80001420:	0019f793          	andi	a5,s3,1
    80001424:	d3fd                	beqz	a5,8000140a <uvmcopy+0x24>
    if ((mem = kalloc()) == 0)
    80001426:	ee8ff0ef          	jal	80000b0e <kalloc>
    8000142a:	892a                	mv	s2,a0
    8000142c:	c11d                	beqz	a0,80001452 <uvmcopy+0x6c>
    pa = PTE2PA(*pte);
    8000142e:	00a9d593          	srli	a1,s3,0xa
    memmove(mem, (char *)pa, PGSIZE);
    80001432:	8652                	mv	a2,s4
    80001434:	05b2                	slli	a1,a1,0xc
    80001436:	8d3ff0ef          	jal	80000d08 <memmove>
    if (mappages(new, i, PGSIZE, (uint64)mem, flags) != 0) {
    8000143a:	3ff9f713          	andi	a4,s3,1023
    8000143e:	86ca                	mv	a3,s2
    80001440:	8652                	mv	a2,s4
    80001442:	85a6                	mv	a1,s1
    80001444:	855e                	mv	a0,s7
    80001446:	bcdff0ef          	jal	80001012 <mappages>
    8000144a:	d161                	beqz	a0,8000140a <uvmcopy+0x24>
      kfree(mem);
    8000144c:	854a                	mv	a0,s2
    8000144e:	dd8ff0ef          	jal	80000a26 <kfree>
    }
  }
  return 0;

err:
  uvmunmap(new, 0, i / PGSIZE, 1);
    80001452:	4685                	li	a3,1
    80001454:	00c4d613          	srli	a2,s1,0xc
    80001458:	4581                	li	a1,0
    8000145a:	855e                	mv	a0,s7
    8000145c:	d85ff0ef          	jal	800011e0 <uvmunmap>
  return -1;
    80001460:	557d                	li	a0,-1
    80001462:	a011                	j	80001466 <uvmcopy+0x80>
  return 0;
    80001464:	4501                	li	a0,0
}
    80001466:	60a6                	ld	ra,72(sp)
    80001468:	6406                	ld	s0,64(sp)
    8000146a:	74e2                	ld	s1,56(sp)
    8000146c:	7942                	ld	s2,48(sp)
    8000146e:	79a2                	ld	s3,40(sp)
    80001470:	7a02                	ld	s4,32(sp)
    80001472:	6ae2                	ld	s5,24(sp)
    80001474:	6b42                	ld	s6,16(sp)
    80001476:	6ba2                	ld	s7,8(sp)
    80001478:	6161                	addi	sp,sp,80
    8000147a:	8082                	ret
  return 0;
    8000147c:	4501                	li	a0,0
}
    8000147e:	8082                	ret

0000000080001480 <uvmclear>:

// mark a PTE invalid for user access.
// used by exec for the user stack guard page.
void
uvmclear(pagetable_t pagetable, uint64 va)
{
    80001480:	1141                	addi	sp,sp,-16
    80001482:	e406                	sd	ra,8(sp)
    80001484:	e022                	sd	s0,0(sp)
    80001486:	0800                	addi	s0,sp,16
  pte_t *pte;

  pte = walk(pagetable, va, 0);
    80001488:	4601                	li	a2,0
    8000148a:	ab5ff0ef          	jal	80000f3e <walk>
  if (pte == 0)
    8000148e:	c901                	beqz	a0,8000149e <uvmclear+0x1e>
    panic("uvmclear");
  *pte &= ~PTE_U;
    80001490:	611c                	ld	a5,0(a0)
    80001492:	9bbd                	andi	a5,a5,-17
    80001494:	e11c                	sd	a5,0(a0)
}
    80001496:	60a2                	ld	ra,8(sp)
    80001498:	6402                	ld	s0,0(sp)
    8000149a:	0141                	addi	sp,sp,16
    8000149c:	8082                	ret
    panic("uvmclear");
    8000149e:	00006517          	auipc	a0,0x6
    800014a2:	caa50513          	addi	a0,a0,-854 # 80007148 <etext+0x148>
    800014a6:	b8eff0ef          	jal	80000834 <panic>

00000000800014aa <ismapped>:
  return mem;
}

int
ismapped(pagetable_t pagetable, uint64 va)
{
    800014aa:	1141                	addi	sp,sp,-16
    800014ac:	e406                	sd	ra,8(sp)
    800014ae:	e022                	sd	s0,0(sp)
    800014b0:	0800                	addi	s0,sp,16
  pte_t *pte = walk(pagetable, va, 0);
    800014b2:	4601                	li	a2,0
    800014b4:	a8bff0ef          	jal	80000f3e <walk>
  if (pte == 0) {
    800014b8:	c119                	beqz	a0,800014be <ismapped+0x14>
    return 0;
  }
  if (*pte & PTE_V) {
    800014ba:	6108                	ld	a0,0(a0)
    800014bc:	8905                	andi	a0,a0,1
    return 1;
  }
  return 0;
}
    800014be:	60a2                	ld	ra,8(sp)
    800014c0:	6402                	ld	s0,0(sp)
    800014c2:	0141                	addi	sp,sp,16
    800014c4:	8082                	ret

00000000800014c6 <vmfault>:
{
    800014c6:	7179                	addi	sp,sp,-48
    800014c8:	f406                	sd	ra,40(sp)
    800014ca:	f022                	sd	s0,32(sp)
    800014cc:	e052                	sd	s4,0(sp)
    800014ce:	1800                	addi	s0,sp,48
    return 0;
    800014d0:	4a01                	li	s4,0
  if (va >= psz)
    800014d2:	00b66863          	bltu	a2,a1,800014e2 <vmfault+0x1c>
}
    800014d6:	8552                	mv	a0,s4
    800014d8:	70a2                	ld	ra,40(sp)
    800014da:	7402                	ld	s0,32(sp)
    800014dc:	6a02                	ld	s4,0(sp)
    800014de:	6145                	addi	sp,sp,48
    800014e0:	8082                	ret
    800014e2:	ec26                	sd	s1,24(sp)
    800014e4:	e44e                	sd	s3,8(sp)
    800014e6:	84aa                	mv	s1,a0
  va = PGROUNDDOWN(va);
    800014e8:	77fd                	lui	a5,0xfffff
    800014ea:	00f679b3          	and	s3,a2,a5
  if (ismapped(pagetable, va)) {
    800014ee:	85ce                	mv	a1,s3
    800014f0:	fbbff0ef          	jal	800014aa <ismapped>
    return 0;
    800014f4:	4a01                	li	s4,0
  if (ismapped(pagetable, va)) {
    800014f6:	c501                	beqz	a0,800014fe <vmfault+0x38>
    800014f8:	64e2                	ld	s1,24(sp)
    800014fa:	69a2                	ld	s3,8(sp)
    800014fc:	bfe9                	j	800014d6 <vmfault+0x10>
    800014fe:	e84a                	sd	s2,16(sp)
  mem = (uint64)kalloc();
    80001500:	e0eff0ef          	jal	80000b0e <kalloc>
    80001504:	892a                	mv	s2,a0
  if (mem == 0)
    80001506:	c915                	beqz	a0,8000153a <vmfault+0x74>
  mem = (uint64)kalloc();
    80001508:	8a2a                	mv	s4,a0
  memset((void *)mem, 0, PGSIZE);
    8000150a:	6605                	lui	a2,0x1
    8000150c:	4581                	li	a1,0
    8000150e:	f9aff0ef          	jal	80000ca8 <memset>
  if (mappages(pagetable, va, PGSIZE, mem, PTE_W | PTE_U | PTE_R) != 0) {
    80001512:	4759                	li	a4,22
    80001514:	86ca                	mv	a3,s2
    80001516:	6605                	lui	a2,0x1
    80001518:	85ce                	mv	a1,s3
    8000151a:	8526                	mv	a0,s1
    8000151c:	af7ff0ef          	jal	80001012 <mappages>
    80001520:	e509                	bnez	a0,8000152a <vmfault+0x64>
    80001522:	64e2                	ld	s1,24(sp)
    80001524:	6942                	ld	s2,16(sp)
    80001526:	69a2                	ld	s3,8(sp)
    80001528:	b77d                	j	800014d6 <vmfault+0x10>
    kfree((void *)mem);
    8000152a:	854a                	mv	a0,s2
    8000152c:	cfaff0ef          	jal	80000a26 <kfree>
    return 0;
    80001530:	4a01                	li	s4,0
    80001532:	64e2                	ld	s1,24(sp)
    80001534:	6942                	ld	s2,16(sp)
    80001536:	69a2                	ld	s3,8(sp)
    80001538:	bf79                	j	800014d6 <vmfault+0x10>
    8000153a:	64e2                	ld	s1,24(sp)
    8000153c:	6942                	ld	s2,16(sp)
    8000153e:	69a2                	ld	s3,8(sp)
    80001540:	bf59                	j	800014d6 <vmfault+0x10>

0000000080001542 <copyout>:
  while (len > 0) {
    80001542:	cf49                	beqz	a4,800015dc <copyout+0x9a>
{
    80001544:	7159                	addi	sp,sp,-112
    80001546:	f486                	sd	ra,104(sp)
    80001548:	f0a2                	sd	s0,96(sp)
    8000154a:	eca6                	sd	s1,88(sp)
    8000154c:	e8ca                	sd	s2,80(sp)
    8000154e:	e4ce                	sd	s3,72(sp)
    80001550:	e0d2                	sd	s4,64(sp)
    80001552:	fc56                	sd	s5,56(sp)
    80001554:	f85a                	sd	s6,48(sp)
    80001556:	f45e                	sd	s7,40(sp)
    80001558:	f062                	sd	s8,32(sp)
    8000155a:	ec66                	sd	s9,24(sp)
    8000155c:	e86a                	sd	s10,16(sp)
    8000155e:	e46e                	sd	s11,8(sp)
    80001560:	1880                	addi	s0,sp,112
    80001562:	8baa                	mv	s7,a0
    80001564:	8dae                	mv	s11,a1
    80001566:	8a32                	mv	s4,a2
    80001568:	8b36                	mv	s6,a3
    8000156a:	8aba                	mv	s5,a4
    va0 = PGROUNDDOWN(dstva);
    8000156c:	7d7d                	lui	s10,0xfffff
    if (va0 >= MAXVA)
    8000156e:	5cfd                	li	s9,-1
    80001570:	01acdc93          	srli	s9,s9,0x1a
    n = PGSIZE - (dstva - va0);
    80001574:	6c05                	lui	s8,0x1
    80001576:	a005                	j	80001596 <copyout+0x54>
    memmove((void *)(pa0 + (dstva - va0)), src, n);
    80001578:	409a0533          	sub	a0,s4,s1
    8000157c:	0009061b          	sext.w	a2,s2
    80001580:	85da                	mv	a1,s6
    80001582:	954e                	add	a0,a0,s3
    80001584:	f84ff0ef          	jal	80000d08 <memmove>
    len -= n;
    80001588:	412a8ab3          	sub	s5,s5,s2
    src += n;
    8000158c:	9b4a                	add	s6,s6,s2
    dstva = va0 + PGSIZE;
    8000158e:	01848a33          	add	s4,s1,s8
  while (len > 0) {
    80001592:	040a8363          	beqz	s5,800015d8 <copyout+0x96>
    va0 = PGROUNDDOWN(dstva);
    80001596:	01aa74b3          	and	s1,s4,s10
    if (va0 >= MAXVA)
    8000159a:	049ce363          	bltu	s9,s1,800015e0 <copyout+0x9e>
    pa0 = walkaddr(pagetable, va0);
    8000159e:	85a6                	mv	a1,s1
    800015a0:	855e                	mv	a0,s7
    800015a2:	a37ff0ef          	jal	80000fd8 <walkaddr>
    800015a6:	89aa                	mv	s3,a0
    if (pa0 == 0) {
    800015a8:	e909                	bnez	a0,800015ba <copyout+0x78>
      if ((pa0 = vmfault(pagetable, psz, va0, 0)) == 0) {
    800015aa:	4681                	li	a3,0
    800015ac:	8626                	mv	a2,s1
    800015ae:	85ee                	mv	a1,s11
    800015b0:	855e                	mv	a0,s7
    800015b2:	f15ff0ef          	jal	800014c6 <vmfault>
    800015b6:	89aa                	mv	s3,a0
    800015b8:	c521                	beqz	a0,80001600 <copyout+0xbe>
    pte = walk(pagetable, va0, 0);
    800015ba:	4601                	li	a2,0
    800015bc:	85a6                	mv	a1,s1
    800015be:	855e                	mv	a0,s7
    800015c0:	97fff0ef          	jal	80000f3e <walk>
    if ((*pte & PTE_W) == 0)
    800015c4:	611c                	ld	a5,0(a0)
    800015c6:	8b91                	andi	a5,a5,4
    800015c8:	cf95                	beqz	a5,80001604 <copyout+0xc2>
    n = PGSIZE - (dstva - va0);
    800015ca:	41448933          	sub	s2,s1,s4
    800015ce:	9962                	add	s2,s2,s8
    if (n > len)
    800015d0:	fb2af4e3          	bgeu	s5,s2,80001578 <copyout+0x36>
    800015d4:	8956                	mv	s2,s5
    800015d6:	b74d                	j	80001578 <copyout+0x36>
  return 0;
    800015d8:	4501                	li	a0,0
    800015da:	a021                	j	800015e2 <copyout+0xa0>
    800015dc:	4501                	li	a0,0
}
    800015de:	8082                	ret
      return -1;
    800015e0:	557d                	li	a0,-1
}
    800015e2:	70a6                	ld	ra,104(sp)
    800015e4:	7406                	ld	s0,96(sp)
    800015e6:	64e6                	ld	s1,88(sp)
    800015e8:	6946                	ld	s2,80(sp)
    800015ea:	69a6                	ld	s3,72(sp)
    800015ec:	6a06                	ld	s4,64(sp)
    800015ee:	7ae2                	ld	s5,56(sp)
    800015f0:	7b42                	ld	s6,48(sp)
    800015f2:	7ba2                	ld	s7,40(sp)
    800015f4:	7c02                	ld	s8,32(sp)
    800015f6:	6ce2                	ld	s9,24(sp)
    800015f8:	6d42                	ld	s10,16(sp)
    800015fa:	6da2                	ld	s11,8(sp)
    800015fc:	6165                	addi	sp,sp,112
    800015fe:	8082                	ret
        return -1;
    80001600:	557d                	li	a0,-1
    80001602:	b7c5                	j	800015e2 <copyout+0xa0>
      return -1;
    80001604:	557d                	li	a0,-1
    80001606:	bff1                	j	800015e2 <copyout+0xa0>

0000000080001608 <copyin>:
  while (len > 0) {
    80001608:	cf41                	beqz	a4,800016a0 <copyin+0x98>
{
    8000160a:	711d                	addi	sp,sp,-96
    8000160c:	ec86                	sd	ra,88(sp)
    8000160e:	e8a2                	sd	s0,80(sp)
    80001610:	e4a6                	sd	s1,72(sp)
    80001612:	e0ca                	sd	s2,64(sp)
    80001614:	fc4e                	sd	s3,56(sp)
    80001616:	f852                	sd	s4,48(sp)
    80001618:	f456                	sd	s5,40(sp)
    8000161a:	f05a                	sd	s6,32(sp)
    8000161c:	ec5e                	sd	s7,24(sp)
    8000161e:	e862                	sd	s8,16(sp)
    80001620:	e466                	sd	s9,8(sp)
    80001622:	e06a                	sd	s10,0(sp)
    80001624:	1080                	addi	s0,sp,96
    80001626:	8baa                	mv	s7,a0
    80001628:	8cae                	mv	s9,a1
    8000162a:	8ab2                	mv	s5,a2
    8000162c:	8936                	mv	s2,a3
    8000162e:	8a3a                	mv	s4,a4
    va0 = PGROUNDDOWN(srcva);
    80001630:	7c7d                	lui	s8,0xfffff
      if ((pa0 = vmfault(pagetable, psz, va0, 1)) == 0) {
    80001632:	4d05                	li	s10,1
    n = PGSIZE - (srcva - va0);
    80001634:	6b05                	lui	s6,0x1
    80001636:	a035                	j	80001662 <copyin+0x5a>
    80001638:	412984b3          	sub	s1,s3,s2
    8000163c:	94da                	add	s1,s1,s6
    if (n > len)
    8000163e:	009a7363          	bgeu	s4,s1,80001644 <copyin+0x3c>
    80001642:	84d2                	mv	s1,s4
    memmove(dst, (void *)(pa0 + (srcva - va0)), n);
    80001644:	413905b3          	sub	a1,s2,s3
    80001648:	0004861b          	sext.w	a2,s1
    8000164c:	95aa                	add	a1,a1,a0
    8000164e:	8556                	mv	a0,s5
    80001650:	eb8ff0ef          	jal	80000d08 <memmove>
    len -= n;
    80001654:	409a0a33          	sub	s4,s4,s1
    dst += n;
    80001658:	9aa6                	add	s5,s5,s1
    srcva = va0 + PGSIZE;
    8000165a:	01698933          	add	s2,s3,s6
  while (len > 0) {
    8000165e:	020a0263          	beqz	s4,80001682 <copyin+0x7a>
    va0 = PGROUNDDOWN(srcva);
    80001662:	018979b3          	and	s3,s2,s8
    pa0 = walkaddr(pagetable, va0);
    80001666:	85ce                	mv	a1,s3
    80001668:	855e                	mv	a0,s7
    8000166a:	96fff0ef          	jal	80000fd8 <walkaddr>
    if (pa0 == 0) {
    8000166e:	f569                	bnez	a0,80001638 <copyin+0x30>
      if ((pa0 = vmfault(pagetable, psz, va0, 1)) == 0) {
    80001670:	86ea                	mv	a3,s10
    80001672:	864e                	mv	a2,s3
    80001674:	85e6                	mv	a1,s9
    80001676:	855e                	mv	a0,s7
    80001678:	e4fff0ef          	jal	800014c6 <vmfault>
    8000167c:	fd55                	bnez	a0,80001638 <copyin+0x30>
        return -1;
    8000167e:	557d                	li	a0,-1
    80001680:	a011                	j	80001684 <copyin+0x7c>
  return 0;
    80001682:	4501                	li	a0,0
}
    80001684:	60e6                	ld	ra,88(sp)
    80001686:	6446                	ld	s0,80(sp)
    80001688:	64a6                	ld	s1,72(sp)
    8000168a:	6906                	ld	s2,64(sp)
    8000168c:	79e2                	ld	s3,56(sp)
    8000168e:	7a42                	ld	s4,48(sp)
    80001690:	7aa2                	ld	s5,40(sp)
    80001692:	7b02                	ld	s6,32(sp)
    80001694:	6be2                	ld	s7,24(sp)
    80001696:	6c42                	ld	s8,16(sp)
    80001698:	6ca2                	ld	s9,8(sp)
    8000169a:	6d02                	ld	s10,0(sp)
    8000169c:	6125                	addi	sp,sp,96
    8000169e:	8082                	ret
  return 0;
    800016a0:	4501                	li	a0,0
}
    800016a2:	8082                	ret

00000000800016a4 <copyinstr>:
  while (got_null == 0 && max > 0) {
    800016a4:	c769                	beqz	a4,8000176e <copyinstr+0xca>
{
    800016a6:	711d                	addi	sp,sp,-96
    800016a8:	ec86                	sd	ra,88(sp)
    800016aa:	e8a2                	sd	s0,80(sp)
    800016ac:	e4a6                	sd	s1,72(sp)
    800016ae:	e0ca                	sd	s2,64(sp)
    800016b0:	fc4e                	sd	s3,56(sp)
    800016b2:	f852                	sd	s4,48(sp)
    800016b4:	f456                	sd	s5,40(sp)
    800016b6:	f05a                	sd	s6,32(sp)
    800016b8:	ec5e                	sd	s7,24(sp)
    800016ba:	e862                	sd	s8,16(sp)
    800016bc:	e466                	sd	s9,8(sp)
    800016be:	1080                	addi	s0,sp,96
    800016c0:	8b2a                	mv	s6,a0
    800016c2:	8c2e                	mv	s8,a1
    800016c4:	89b2                	mv	s3,a2
    800016c6:	84b6                	mv	s1,a3
    800016c8:	8a3a                	mv	s4,a4
    va0 = PGROUNDDOWN(srcva);
    800016ca:	7bfd                	lui	s7,0xfffff
      if ((pa0 = vmfault(pagetable, psz, va0, 1)) == 0) {
    800016cc:	4c85                	li	s9,1
    n = PGSIZE - (srcva - va0);
    800016ce:	6a85                	lui	s5,0x1
    800016d0:	a881                	j	80001720 <copyinstr+0x7c>
      if ((pa0 = vmfault(pagetable, psz, va0, 1)) == 0) {
    800016d2:	86e6                	mv	a3,s9
    800016d4:	864a                	mv	a2,s2
    800016d6:	85e2                	mv	a1,s8
    800016d8:	855a                	mv	a0,s6
    800016da:	dedff0ef          	jal	800014c6 <vmfault>
    800016de:	e921                	bnez	a0,8000172e <copyinstr+0x8a>
        return -1;
    800016e0:	557d                	li	a0,-1
    800016e2:	a801                	j	800016f2 <copyinstr+0x4e>
        *dst = '\0';
    800016e4:	00078023          	sb	zero,0(a5) # fffffffffffff000 <end+0xffffffff7ffdb9b0>
        got_null = 1;
    800016e8:	4785                	li	a5,1
  if (got_null) {
    800016ea:	0017c793          	xori	a5,a5,1
    800016ee:	40f0053b          	negw	a0,a5
}
    800016f2:	60e6                	ld	ra,88(sp)
    800016f4:	6446                	ld	s0,80(sp)
    800016f6:	64a6                	ld	s1,72(sp)
    800016f8:	6906                	ld	s2,64(sp)
    800016fa:	79e2                	ld	s3,56(sp)
    800016fc:	7a42                	ld	s4,48(sp)
    800016fe:	7aa2                	ld	s5,40(sp)
    80001700:	7b02                	ld	s6,32(sp)
    80001702:	6be2                	ld	s7,24(sp)
    80001704:	6c42                	ld	s8,16(sp)
    80001706:	6ca2                	ld	s9,8(sp)
    80001708:	6125                	addi	sp,sp,96
    8000170a:	8082                	ret
    8000170c:	fffa0713          	addi	a4,s4,-1 # fff <_entry-0x7ffff001>
    80001710:	974e                	add	a4,a4,s3
      --max;
    80001712:	40b70a33          	sub	s4,a4,a1
    srcva = va0 + PGSIZE;
    80001716:	015904b3          	add	s1,s2,s5
  while (got_null == 0 && max > 0) {
    8000171a:	04e58463          	beq	a1,a4,80001762 <copyinstr+0xbe>
{
    8000171e:	89be                	mv	s3,a5
    va0 = PGROUNDDOWN(srcva);
    80001720:	0174f933          	and	s2,s1,s7
    pa0 = walkaddr(pagetable, va0);
    80001724:	85ca                	mv	a1,s2
    80001726:	855a                	mv	a0,s6
    80001728:	8b1ff0ef          	jal	80000fd8 <walkaddr>
    if (pa0 == 0) {
    8000172c:	d15d                	beqz	a0,800016d2 <copyinstr+0x2e>
    n = PGSIZE - (srcva - va0);
    8000172e:	40990633          	sub	a2,s2,s1
    80001732:	9656                	add	a2,a2,s5
    if (n > max)
    80001734:	00ca7363          	bgeu	s4,a2,8000173a <copyinstr+0x96>
    80001738:	8652                	mv	a2,s4
    while (n > 0) {
    8000173a:	c615                	beqz	a2,80001766 <copyinstr+0xc2>
    char *p = (char *)(pa0 + (srcva - va0));
    8000173c:	412484b3          	sub	s1,s1,s2
    80001740:	94aa                	add	s1,s1,a0
    80001742:	87ce                	mv	a5,s3
      if (*p == '\0') {
    80001744:	413484b3          	sub	s1,s1,s3
    while (n > 0) {
    80001748:	964e                	add	a2,a2,s3
    8000174a:	85be                	mv	a1,a5
      if (*p == '\0') {
    8000174c:	00f48733          	add	a4,s1,a5
    80001750:	00074683          	lbu	a3,0(a4)
    80001754:	dac1                	beqz	a3,800016e4 <copyinstr+0x40>
        *dst = *p;
    80001756:	00d78023          	sb	a3,0(a5)
      dst++;
    8000175a:	0785                	addi	a5,a5,1
    while (n > 0) {
    8000175c:	fec797e3          	bne	a5,a2,8000174a <copyinstr+0xa6>
    80001760:	b775                	j	8000170c <copyinstr+0x68>
    80001762:	4781                	li	a5,0
    80001764:	b759                	j	800016ea <copyinstr+0x46>
    srcva = va0 + PGSIZE;
    80001766:	6485                	lui	s1,0x1
    80001768:	94ca                	add	s1,s1,s2
    8000176a:	87ce                	mv	a5,s3
    8000176c:	bf4d                	j	8000171e <copyinstr+0x7a>
  int got_null = 0;
    8000176e:	4781                	li	a5,0
  if (got_null) {
    80001770:	0017c793          	xori	a5,a5,1
    80001774:	40f0053b          	negw	a0,a5
}
    80001778:	8082                	ret

000000008000177a <proc_mapstacks>:
// Allocate a page for each process's kernel stack.
// Map it high in memory, followed by an invalid
// guard page.
void
proc_mapstacks(pagetable_t kpgtbl)
{
    8000177a:	715d                	addi	sp,sp,-80
    8000177c:	e486                	sd	ra,72(sp)
    8000177e:	e0a2                	sd	s0,64(sp)
    80001780:	fc26                	sd	s1,56(sp)
    80001782:	f84a                	sd	s2,48(sp)
    80001784:	f44e                	sd	s3,40(sp)
    80001786:	f052                	sd	s4,32(sp)
    80001788:	ec56                	sd	s5,24(sp)
    8000178a:	e85a                	sd	s6,16(sp)
    8000178c:	e45e                	sd	s7,8(sp)
    8000178e:	e062                	sd	s8,0(sp)
    80001790:	0880                	addi	s0,sp,80
    80001792:	8a2a                	mv	s4,a0
  struct proc *p;

  for (p = proc; p < &proc[NPROC]; p++) {
    80001794:	00011497          	auipc	s1,0x11
    80001798:	0dc48493          	addi	s1,s1,220 # 80012870 <proc>
    char *pa = kalloc();
    if (pa == 0)
      panic("kalloc");
    uint64 va = KSTACK((int)(p - proc));
    8000179c:	8c26                	mv	s8,s1
    8000179e:	000a57b7          	lui	a5,0xa5
    800017a2:	fa578793          	addi	a5,a5,-91 # a4fa5 <_entry-0x7ff5b05b>
    800017a6:	07b2                	slli	a5,a5,0xc
    800017a8:	fa578793          	addi	a5,a5,-91
    800017ac:	4fa50937          	lui	s2,0x4fa50
    800017b0:	a4f90913          	addi	s2,s2,-1457 # 4fa4fa4f <_entry-0x305b05b1>
    800017b4:	1902                	slli	s2,s2,0x20
    800017b6:	993e                	add	s2,s2,a5
    800017b8:	040009b7          	lui	s3,0x4000
    800017bc:	19fd                	addi	s3,s3,-1 # 3ffffff <_entry-0x7c000001>
    800017be:	09b2                	slli	s3,s3,0xc
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    800017c0:	4b99                	li	s7,6
    800017c2:	6b05                	lui	s6,0x1
  for (p = proc; p < &proc[NPROC]; p++) {
    800017c4:	00017a97          	auipc	s5,0x17
    800017c8:	aaca8a93          	addi	s5,s5,-1364 # 80018270 <tickslock>
    char *pa = kalloc();
    800017cc:	b42ff0ef          	jal	80000b0e <kalloc>
    800017d0:	862a                	mv	a2,a0
    if (pa == 0)
    800017d2:	c121                	beqz	a0,80001812 <proc_mapstacks+0x98>
    uint64 va = KSTACK((int)(p - proc));
    800017d4:	418485b3          	sub	a1,s1,s8
    800017d8:	858d                	srai	a1,a1,0x3
    800017da:	032585b3          	mul	a1,a1,s2
    800017de:	05b6                	slli	a1,a1,0xd
    800017e0:	6789                	lui	a5,0x2
    800017e2:	9dbd                	addw	a1,a1,a5
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    800017e4:	875e                	mv	a4,s7
    800017e6:	86da                	mv	a3,s6
    800017e8:	40b985b3          	sub	a1,s3,a1
    800017ec:	8552                	mv	a0,s4
    800017ee:	8dbff0ef          	jal	800010c8 <kvmmap>
  for (p = proc; p < &proc[NPROC]; p++) {
    800017f2:	16848493          	addi	s1,s1,360
    800017f6:	fd549be3          	bne	s1,s5,800017cc <proc_mapstacks+0x52>
  }
}
    800017fa:	60a6                	ld	ra,72(sp)
    800017fc:	6406                	ld	s0,64(sp)
    800017fe:	74e2                	ld	s1,56(sp)
    80001800:	7942                	ld	s2,48(sp)
    80001802:	79a2                	ld	s3,40(sp)
    80001804:	7a02                	ld	s4,32(sp)
    80001806:	6ae2                	ld	s5,24(sp)
    80001808:	6b42                	ld	s6,16(sp)
    8000180a:	6ba2                	ld	s7,8(sp)
    8000180c:	6c02                	ld	s8,0(sp)
    8000180e:	6161                	addi	sp,sp,80
    80001810:	8082                	ret
      panic("kalloc");
    80001812:	00006517          	auipc	a0,0x6
    80001816:	94650513          	addi	a0,a0,-1722 # 80007158 <etext+0x158>
    8000181a:	81aff0ef          	jal	80000834 <panic>

000000008000181e <procinit>:

// initialize the proc table.
void
procinit(void)
{
    8000181e:	7139                	addi	sp,sp,-64
    80001820:	fc06                	sd	ra,56(sp)
    80001822:	f822                	sd	s0,48(sp)
    80001824:	f426                	sd	s1,40(sp)
    80001826:	f04a                	sd	s2,32(sp)
    80001828:	ec4e                	sd	s3,24(sp)
    8000182a:	e852                	sd	s4,16(sp)
    8000182c:	e456                	sd	s5,8(sp)
    8000182e:	e05a                	sd	s6,0(sp)
    80001830:	0080                	addi	s0,sp,64
  struct proc *p;

  initlock(&pid_lock, "nextpid");
    80001832:	00006597          	auipc	a1,0x6
    80001836:	92e58593          	addi	a1,a1,-1746 # 80007160 <etext+0x160>
    8000183a:	00011517          	auipc	a0,0x11
    8000183e:	c0650513          	addi	a0,a0,-1018 # 80012440 <pid_lock>
    80001842:	b26ff0ef          	jal	80000b68 <initlock>
  initlock(&wait_lock, "wait_lock");
    80001846:	00006597          	auipc	a1,0x6
    8000184a:	92258593          	addi	a1,a1,-1758 # 80007168 <etext+0x168>
    8000184e:	00011517          	auipc	a0,0x11
    80001852:	c0a50513          	addi	a0,a0,-1014 # 80012458 <wait_lock>
    80001856:	b12ff0ef          	jal	80000b68 <initlock>
  for (p = proc; p < &proc[NPROC]; p++) {
    8000185a:	00011497          	auipc	s1,0x11
    8000185e:	01648493          	addi	s1,s1,22 # 80012870 <proc>
    initlock(&p->lock, "proc");
    80001862:	00006b17          	auipc	s6,0x6
    80001866:	916b0b13          	addi	s6,s6,-1770 # 80007178 <etext+0x178>
    p->state = UNUSED;
    p->kstack = KSTACK((int)(p - proc));
    8000186a:	8aa6                	mv	s5,s1
    8000186c:	000a57b7          	lui	a5,0xa5
    80001870:	fa578793          	addi	a5,a5,-91 # a4fa5 <_entry-0x7ff5b05b>
    80001874:	07b2                	slli	a5,a5,0xc
    80001876:	fa578793          	addi	a5,a5,-91
    8000187a:	4fa50937          	lui	s2,0x4fa50
    8000187e:	a4f90913          	addi	s2,s2,-1457 # 4fa4fa4f <_entry-0x305b05b1>
    80001882:	1902                	slli	s2,s2,0x20
    80001884:	993e                	add	s2,s2,a5
    80001886:	040009b7          	lui	s3,0x4000
    8000188a:	19fd                	addi	s3,s3,-1 # 3ffffff <_entry-0x7c000001>
    8000188c:	09b2                	slli	s3,s3,0xc
  for (p = proc; p < &proc[NPROC]; p++) {
    8000188e:	00017a17          	auipc	s4,0x17
    80001892:	9e2a0a13          	addi	s4,s4,-1566 # 80018270 <tickslock>
    initlock(&p->lock, "proc");
    80001896:	85da                	mv	a1,s6
    80001898:	8526                	mv	a0,s1
    8000189a:	aceff0ef          	jal	80000b68 <initlock>
    p->state = UNUSED;
    8000189e:	0004ac23          	sw	zero,24(s1)
    p->kstack = KSTACK((int)(p - proc));
    800018a2:	415487b3          	sub	a5,s1,s5
    800018a6:	878d                	srai	a5,a5,0x3
    800018a8:	032787b3          	mul	a5,a5,s2
    800018ac:	07b6                	slli	a5,a5,0xd
    800018ae:	6709                	lui	a4,0x2
    800018b0:	9fb9                	addw	a5,a5,a4
    800018b2:	40f987b3          	sub	a5,s3,a5
    800018b6:	e0bc                	sd	a5,64(s1)
  for (p = proc; p < &proc[NPROC]; p++) {
    800018b8:	16848493          	addi	s1,s1,360
    800018bc:	fd449de3          	bne	s1,s4,80001896 <procinit+0x78>
  }
}
    800018c0:	70e2                	ld	ra,56(sp)
    800018c2:	7442                	ld	s0,48(sp)
    800018c4:	74a2                	ld	s1,40(sp)
    800018c6:	7902                	ld	s2,32(sp)
    800018c8:	69e2                	ld	s3,24(sp)
    800018ca:	6a42                	ld	s4,16(sp)
    800018cc:	6aa2                	ld	s5,8(sp)
    800018ce:	6b02                	ld	s6,0(sp)
    800018d0:	6121                	addi	sp,sp,64
    800018d2:	8082                	ret

00000000800018d4 <cpuid>:
// Must be called with interrupts disabled,
// to prevent race with process being moved
// to a different CPU.
int
cpuid()
{
    800018d4:	1141                	addi	sp,sp,-16
    800018d6:	e406                	sd	ra,8(sp)
    800018d8:	e022                	sd	s0,0(sp)
    800018da:	0800                	addi	s0,sp,16
  asm volatile("mv %0, tp" : "=r"(x));
    800018dc:	8512                	mv	a0,tp
  int id = r_tp();
  return id;
}
    800018de:	2501                	sext.w	a0,a0
    800018e0:	60a2                	ld	ra,8(sp)
    800018e2:	6402                	ld	s0,0(sp)
    800018e4:	0141                	addi	sp,sp,16
    800018e6:	8082                	ret

00000000800018e8 <mycpu>:

// Return this CPU's cpu struct.
// Interrupts must be disabled.
struct cpu *
mycpu(void)
{
    800018e8:	1141                	addi	sp,sp,-16
    800018ea:	e406                	sd	ra,8(sp)
    800018ec:	e022                	sd	s0,0(sp)
    800018ee:	0800                	addi	s0,sp,16
    800018f0:	8792                	mv	a5,tp
  int id = cpuid();
  struct cpu *c = &cpus[id];
    800018f2:	2781                	sext.w	a5,a5
    800018f4:	079e                	slli	a5,a5,0x7
  return c;
}
    800018f6:	00011517          	auipc	a0,0x11
    800018fa:	b7a50513          	addi	a0,a0,-1158 # 80012470 <cpus>
    800018fe:	953e                	add	a0,a0,a5
    80001900:	60a2                	ld	ra,8(sp)
    80001902:	6402                	ld	s0,0(sp)
    80001904:	0141                	addi	sp,sp,16
    80001906:	8082                	ret

0000000080001908 <myproc>:

// Return the current struct proc *, or zero if none.
struct proc *
myproc(void)
{
    80001908:	1101                	addi	sp,sp,-32
    8000190a:	ec06                	sd	ra,24(sp)
    8000190c:	e822                	sd	s0,16(sp)
    8000190e:	e426                	sd	s1,8(sp)
    80001910:	1000                	addi	s0,sp,32
  push_off();
    80001912:	a9cff0ef          	jal	80000bae <push_off>
    80001916:	8792                	mv	a5,tp
  struct cpu *c = mycpu();
  struct proc *p = c->proc;
    80001918:	2781                	sext.w	a5,a5
    8000191a:	079e                	slli	a5,a5,0x7
    8000191c:	00011717          	auipc	a4,0x11
    80001920:	b2470713          	addi	a4,a4,-1244 # 80012440 <pid_lock>
    80001924:	97ba                	add	a5,a5,a4
    80001926:	7b9c                	ld	a5,48(a5)
    80001928:	84be                	mv	s1,a5
  pop_off();
    8000192a:	afeff0ef          	jal	80000c28 <pop_off>
  return p;
}
    8000192e:	8526                	mv	a0,s1
    80001930:	60e2                	ld	ra,24(sp)
    80001932:	6442                	ld	s0,16(sp)
    80001934:	64a2                	ld	s1,8(sp)
    80001936:	6105                	addi	sp,sp,32
    80001938:	8082                	ret

000000008000193a <forkret>:

// A fork child's very first scheduling by scheduler()
// will swtch to forkret.
void
forkret(void)
{
    8000193a:	7179                	addi	sp,sp,-48
    8000193c:	f406                	sd	ra,40(sp)
    8000193e:	f022                	sd	s0,32(sp)
    80001940:	ec26                	sd	s1,24(sp)
    80001942:	1800                	addi	s0,sp,48
  extern char userret[];
  static int first = 1;
  struct proc *p = myproc();
    80001944:	fc5ff0ef          	jal	80001908 <myproc>
    80001948:	84aa                	mv	s1,a0

  // Still holding p->lock from scheduler.
  release(&p->lock);
    8000194a:	b26ff0ef          	jal	80000c70 <release>

  if (first) {
    8000194e:	00009797          	auipc	a5,0x9
    80001952:	9827a783          	lw	a5,-1662(a5) # 8000a2d0 <first.1>
    80001956:	cf85                	beqz	a5,8000198e <forkret+0x54>
    first = 0;
    80001958:	00009797          	auipc	a5,0x9
    8000195c:	9607ac23          	sw	zero,-1672(a5) # 8000a2d0 <first.1>

    // File system initialization must be run in the context of a
    // regular process (e.g., because it calls sleep), and thus cannot
    // be run from main().
    fsinit(ROOTDEV);
    80001960:	4505                	li	a0,1
    80001962:	46f010ef          	jal	800035d0 <fsinit>

    // We can invoke kexec() now that file system is initialized.
    // Put the return value (argc) of kexec into a0.
    p->trapframe->a0 = kexec("/init", (char *[]){"/init", 0});
    80001966:	00006797          	auipc	a5,0x6
    8000196a:	81a78793          	addi	a5,a5,-2022 # 80007180 <etext+0x180>
    8000196e:	fcf43823          	sd	a5,-48(s0)
    80001972:	fc043c23          	sd	zero,-40(s0)
    80001976:	fd040593          	addi	a1,s0,-48
    8000197a:	853e                	mv	a0,a5
    8000197c:	6e5020ef          	jal	80004860 <kexec>
    80001980:	6cbc                	ld	a5,88(s1)
    80001982:	fba8                	sd	a0,112(a5)
    if (p->trapframe->a0 == -1) {
    80001984:	6cbc                	ld	a5,88(s1)
    80001986:	7bb8                	ld	a4,112(a5)
    80001988:	57fd                	li	a5,-1
    8000198a:	02f70d63          	beq	a4,a5,800019c4 <forkret+0x8a>
      panic("exec");
    }
  }

  // return to user space, mimicing usertrap()'s return.
  prepare_return();
    8000198e:	2fd000ef          	jal	8000248a <prepare_return>
  uint64 satp = MAKE_SATP(p->pagetable);
    80001992:	68a8                	ld	a0,80(s1)
    80001994:	8131                	srli	a0,a0,0xc
  uint64 trampoline_userret = TRAMPOLINE + (userret - trampoline);
    80001996:	04000737          	lui	a4,0x4000
    8000199a:	177d                	addi	a4,a4,-1 # 3ffffff <_entry-0x7c000001>
    8000199c:	0732                	slli	a4,a4,0xc
    8000199e:	00004797          	auipc	a5,0x4
    800019a2:	6fe78793          	addi	a5,a5,1790 # 8000609c <userret>
    800019a6:	00004697          	auipc	a3,0x4
    800019aa:	65a68693          	addi	a3,a3,1626 # 80006000 <_trampoline>
    800019ae:	8f95                	sub	a5,a5,a3
    800019b0:	97ba                	add	a5,a5,a4
  ((void (*)(uint64))trampoline_userret)(satp);
    800019b2:	577d                	li	a4,-1
    800019b4:	177e                	slli	a4,a4,0x3f
    800019b6:	8d59                	or	a0,a0,a4
    800019b8:	9782                	jalr	a5
}
    800019ba:	70a2                	ld	ra,40(sp)
    800019bc:	7402                	ld	s0,32(sp)
    800019be:	64e2                	ld	s1,24(sp)
    800019c0:	6145                	addi	sp,sp,48
    800019c2:	8082                	ret
      panic("exec");
    800019c4:	00005517          	auipc	a0,0x5
    800019c8:	7c450513          	addi	a0,a0,1988 # 80007188 <etext+0x188>
    800019cc:	e69fe0ef          	jal	80000834 <panic>

00000000800019d0 <allocpid>:
{
    800019d0:	1101                	addi	sp,sp,-32
    800019d2:	ec06                	sd	ra,24(sp)
    800019d4:	e822                	sd	s0,16(sp)
    800019d6:	e426                	sd	s1,8(sp)
    800019d8:	1000                	addi	s0,sp,32
  acquire(&pid_lock);
    800019da:	00011517          	auipc	a0,0x11
    800019de:	a6650513          	addi	a0,a0,-1434 # 80012440 <pid_lock>
    800019e2:	a06ff0ef          	jal	80000be8 <acquire>
  pid = nextpid;
    800019e6:	00009797          	auipc	a5,0x9
    800019ea:	8ee78793          	addi	a5,a5,-1810 # 8000a2d4 <nextpid>
    800019ee:	4384                	lw	s1,0(a5)
  nextpid = nextpid + 1;
    800019f0:	0014871b          	addiw	a4,s1,1
    800019f4:	c398                	sw	a4,0(a5)
  release(&pid_lock);
    800019f6:	00011517          	auipc	a0,0x11
    800019fa:	a4a50513          	addi	a0,a0,-1462 # 80012440 <pid_lock>
    800019fe:	a72ff0ef          	jal	80000c70 <release>
}
    80001a02:	8526                	mv	a0,s1
    80001a04:	60e2                	ld	ra,24(sp)
    80001a06:	6442                	ld	s0,16(sp)
    80001a08:	64a2                	ld	s1,8(sp)
    80001a0a:	6105                	addi	sp,sp,32
    80001a0c:	8082                	ret

0000000080001a0e <proc_pagetable>:
{
    80001a0e:	1101                	addi	sp,sp,-32
    80001a10:	ec06                	sd	ra,24(sp)
    80001a12:	e822                	sd	s0,16(sp)
    80001a14:	e426                	sd	s1,8(sp)
    80001a16:	e04a                	sd	s2,0(sp)
    80001a18:	1000                	addi	s0,sp,32
    80001a1a:	892a                	mv	s2,a0
  pagetable = uvmcreate();
    80001a1c:	f9eff0ef          	jal	800011ba <uvmcreate>
    80001a20:	84aa                	mv	s1,a0
  if (pagetable == 0)
    80001a22:	cd05                	beqz	a0,80001a5a <proc_pagetable+0x4c>
  if (mappages(pagetable, TRAMPOLINE, PGSIZE, (uint64)trampoline,
    80001a24:	4729                	li	a4,10
    80001a26:	00004697          	auipc	a3,0x4
    80001a2a:	5da68693          	addi	a3,a3,1498 # 80006000 <_trampoline>
    80001a2e:	6605                	lui	a2,0x1
    80001a30:	040005b7          	lui	a1,0x4000
    80001a34:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001a36:	05b2                	slli	a1,a1,0xc
    80001a38:	ddaff0ef          	jal	80001012 <mappages>
    80001a3c:	02054663          	bltz	a0,80001a68 <proc_pagetable+0x5a>
  if (mappages(pagetable, TRAPFRAME, PGSIZE, (uint64)(p->trapframe),
    80001a40:	4719                	li	a4,6
    80001a42:	05893683          	ld	a3,88(s2)
    80001a46:	6605                	lui	a2,0x1
    80001a48:	020005b7          	lui	a1,0x2000
    80001a4c:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80001a4e:	05b6                	slli	a1,a1,0xd
    80001a50:	8526                	mv	a0,s1
    80001a52:	dc0ff0ef          	jal	80001012 <mappages>
    80001a56:	00054f63          	bltz	a0,80001a74 <proc_pagetable+0x66>
}
    80001a5a:	8526                	mv	a0,s1
    80001a5c:	60e2                	ld	ra,24(sp)
    80001a5e:	6442                	ld	s0,16(sp)
    80001a60:	64a2                	ld	s1,8(sp)
    80001a62:	6902                	ld	s2,0(sp)
    80001a64:	6105                	addi	sp,sp,32
    80001a66:	8082                	ret
    uvmfree(pagetable, 0);
    80001a68:	4581                	li	a1,0
    80001a6a:	8526                	mv	a0,s1
    80001a6c:	949ff0ef          	jal	800013b4 <uvmfree>
    return 0;
    80001a70:	4481                	li	s1,0
    80001a72:	b7e5                	j	80001a5a <proc_pagetable+0x4c>
    uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001a74:	4681                	li	a3,0
    80001a76:	4605                	li	a2,1
    80001a78:	040005b7          	lui	a1,0x4000
    80001a7c:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001a7e:	05b2                	slli	a1,a1,0xc
    80001a80:	8526                	mv	a0,s1
    80001a82:	f5eff0ef          	jal	800011e0 <uvmunmap>
    uvmfree(pagetable, 0);
    80001a86:	4581                	li	a1,0
    80001a88:	8526                	mv	a0,s1
    80001a8a:	92bff0ef          	jal	800013b4 <uvmfree>
    return 0;
    80001a8e:	4481                	li	s1,0
    80001a90:	b7e9                	j	80001a5a <proc_pagetable+0x4c>

0000000080001a92 <proc_freepagetable>:
{
    80001a92:	1101                	addi	sp,sp,-32
    80001a94:	ec06                	sd	ra,24(sp)
    80001a96:	e822                	sd	s0,16(sp)
    80001a98:	e426                	sd	s1,8(sp)
    80001a9a:	e04a                	sd	s2,0(sp)
    80001a9c:	1000                	addi	s0,sp,32
    80001a9e:	84aa                	mv	s1,a0
    80001aa0:	892e                	mv	s2,a1
  uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001aa2:	4681                	li	a3,0
    80001aa4:	4605                	li	a2,1
    80001aa6:	040005b7          	lui	a1,0x4000
    80001aaa:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001aac:	05b2                	slli	a1,a1,0xc
    80001aae:	f32ff0ef          	jal	800011e0 <uvmunmap>
  uvmunmap(pagetable, TRAPFRAME, 1, 0);
    80001ab2:	4681                	li	a3,0
    80001ab4:	4605                	li	a2,1
    80001ab6:	020005b7          	lui	a1,0x2000
    80001aba:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80001abc:	05b6                	slli	a1,a1,0xd
    80001abe:	8526                	mv	a0,s1
    80001ac0:	f20ff0ef          	jal	800011e0 <uvmunmap>
  uvmfree(pagetable, sz);
    80001ac4:	85ca                	mv	a1,s2
    80001ac6:	8526                	mv	a0,s1
    80001ac8:	8edff0ef          	jal	800013b4 <uvmfree>
}
    80001acc:	60e2                	ld	ra,24(sp)
    80001ace:	6442                	ld	s0,16(sp)
    80001ad0:	64a2                	ld	s1,8(sp)
    80001ad2:	6902                	ld	s2,0(sp)
    80001ad4:	6105                	addi	sp,sp,32
    80001ad6:	8082                	ret

0000000080001ad8 <freeproc>:
{
    80001ad8:	1101                	addi	sp,sp,-32
    80001ada:	ec06                	sd	ra,24(sp)
    80001adc:	e822                	sd	s0,16(sp)
    80001ade:	e426                	sd	s1,8(sp)
    80001ae0:	1000                	addi	s0,sp,32
    80001ae2:	84aa                	mv	s1,a0
  if (p->trapframe)
    80001ae4:	6d28                	ld	a0,88(a0)
    80001ae6:	c119                	beqz	a0,80001aec <freeproc+0x14>
    kfree((void *)p->trapframe);
    80001ae8:	f3ffe0ef          	jal	80000a26 <kfree>
  p->trapframe = 0;
    80001aec:	0404bc23          	sd	zero,88(s1)
  if (p->pagetable)
    80001af0:	68a8                	ld	a0,80(s1)
    80001af2:	c501                	beqz	a0,80001afa <freeproc+0x22>
    proc_freepagetable(p->pagetable, p->sz);
    80001af4:	64ac                	ld	a1,72(s1)
    80001af6:	f9dff0ef          	jal	80001a92 <proc_freepagetable>
  p->pagetable = 0;
    80001afa:	0404b823          	sd	zero,80(s1)
  p->sz = 0;
    80001afe:	0404b423          	sd	zero,72(s1)
  p->pid = 0;
    80001b02:	0204a823          	sw	zero,48(s1)
  p->name[0] = 0;
    80001b06:	14048c23          	sb	zero,344(s1)
  p->chan = 0;
    80001b0a:	0204b023          	sd	zero,32(s1)
  p->killed = 0;
    80001b0e:	0204a423          	sw	zero,40(s1)
  p->xstate = 0;
    80001b12:	0204a623          	sw	zero,44(s1)
  p->state = UNUSED;
    80001b16:	0004ac23          	sw	zero,24(s1)
}
    80001b1a:	60e2                	ld	ra,24(sp)
    80001b1c:	6442                	ld	s0,16(sp)
    80001b1e:	64a2                	ld	s1,8(sp)
    80001b20:	6105                	addi	sp,sp,32
    80001b22:	8082                	ret

0000000080001b24 <allocproc>:
{
    80001b24:	1101                	addi	sp,sp,-32
    80001b26:	ec06                	sd	ra,24(sp)
    80001b28:	e822                	sd	s0,16(sp)
    80001b2a:	e426                	sd	s1,8(sp)
    80001b2c:	e04a                	sd	s2,0(sp)
    80001b2e:	1000                	addi	s0,sp,32
  for (p = proc; p < &proc[NPROC]; p++) {
    80001b30:	00011497          	auipc	s1,0x11
    80001b34:	d4048493          	addi	s1,s1,-704 # 80012870 <proc>
    80001b38:	00016917          	auipc	s2,0x16
    80001b3c:	73890913          	addi	s2,s2,1848 # 80018270 <tickslock>
    acquire(&p->lock);
    80001b40:	8526                	mv	a0,s1
    80001b42:	8a6ff0ef          	jal	80000be8 <acquire>
    if (p->state == UNUSED) {
    80001b46:	4c9c                	lw	a5,24(s1)
    80001b48:	cb91                	beqz	a5,80001b5c <allocproc+0x38>
      release(&p->lock);
    80001b4a:	8526                	mv	a0,s1
    80001b4c:	924ff0ef          	jal	80000c70 <release>
  for (p = proc; p < &proc[NPROC]; p++) {
    80001b50:	16848493          	addi	s1,s1,360
    80001b54:	ff2496e3          	bne	s1,s2,80001b40 <allocproc+0x1c>
  return 0;
    80001b58:	4481                	li	s1,0
    80001b5a:	a089                	j	80001b9c <allocproc+0x78>
  p->pid = allocpid();
    80001b5c:	e75ff0ef          	jal	800019d0 <allocpid>
    80001b60:	d888                	sw	a0,48(s1)
  p->state = USED;
    80001b62:	4785                	li	a5,1
    80001b64:	cc9c                	sw	a5,24(s1)
  if ((p->trapframe = (struct trapframe *)kalloc()) == 0) {
    80001b66:	fa9fe0ef          	jal	80000b0e <kalloc>
    80001b6a:	892a                	mv	s2,a0
    80001b6c:	eca8                	sd	a0,88(s1)
    80001b6e:	cd15                	beqz	a0,80001baa <allocproc+0x86>
  p->pagetable = proc_pagetable(p);
    80001b70:	8526                	mv	a0,s1
    80001b72:	e9dff0ef          	jal	80001a0e <proc_pagetable>
    80001b76:	892a                	mv	s2,a0
    80001b78:	e8a8                	sd	a0,80(s1)
  if (p->pagetable == 0) {
    80001b7a:	c121                	beqz	a0,80001bba <allocproc+0x96>
  memset(&p->context, 0, sizeof(p->context));
    80001b7c:	07000613          	li	a2,112
    80001b80:	4581                	li	a1,0
    80001b82:	06048513          	addi	a0,s1,96
    80001b86:	922ff0ef          	jal	80000ca8 <memset>
  p->context.ra = (uint64)forkret;
    80001b8a:	00000797          	auipc	a5,0x0
    80001b8e:	db078793          	addi	a5,a5,-592 # 8000193a <forkret>
    80001b92:	f0bc                	sd	a5,96(s1)
  p->context.sp = p->kstack + PGSIZE;
    80001b94:	60bc                	ld	a5,64(s1)
    80001b96:	6705                	lui	a4,0x1
    80001b98:	97ba                	add	a5,a5,a4
    80001b9a:	f4bc                	sd	a5,104(s1)
}
    80001b9c:	8526                	mv	a0,s1
    80001b9e:	60e2                	ld	ra,24(sp)
    80001ba0:	6442                	ld	s0,16(sp)
    80001ba2:	64a2                	ld	s1,8(sp)
    80001ba4:	6902                	ld	s2,0(sp)
    80001ba6:	6105                	addi	sp,sp,32
    80001ba8:	8082                	ret
    freeproc(p);
    80001baa:	8526                	mv	a0,s1
    80001bac:	f2dff0ef          	jal	80001ad8 <freeproc>
    release(&p->lock);
    80001bb0:	8526                	mv	a0,s1
    80001bb2:	8beff0ef          	jal	80000c70 <release>
    return 0;
    80001bb6:	84ca                	mv	s1,s2
    80001bb8:	b7d5                	j	80001b9c <allocproc+0x78>
    freeproc(p);
    80001bba:	8526                	mv	a0,s1
    80001bbc:	f1dff0ef          	jal	80001ad8 <freeproc>
    release(&p->lock);
    80001bc0:	8526                	mv	a0,s1
    80001bc2:	8aeff0ef          	jal	80000c70 <release>
    return 0;
    80001bc6:	84ca                	mv	s1,s2
    80001bc8:	bfd1                	j	80001b9c <allocproc+0x78>

0000000080001bca <userinit>:
{
    80001bca:	1101                	addi	sp,sp,-32
    80001bcc:	ec06                	sd	ra,24(sp)
    80001bce:	e822                	sd	s0,16(sp)
    80001bd0:	e426                	sd	s1,8(sp)
    80001bd2:	1000                	addi	s0,sp,32
  p = allocproc();
    80001bd4:	f51ff0ef          	jal	80001b24 <allocproc>
    80001bd8:	84aa                	mv	s1,a0
  initproc = p;
    80001bda:	00008797          	auipc	a5,0x8
    80001bde:	72a7bf23          	sd	a0,1854(a5) # 8000a318 <initproc>
  p->cwd = namei("/");
    80001be2:	00005517          	auipc	a0,0x5
    80001be6:	5ae50513          	addi	a0,a0,1454 # 80007190 <etext+0x190>
    80001bea:	745010ef          	jal	80003b2e <namei>
    80001bee:	14a4b823          	sd	a0,336(s1)
  p->state = RUNNABLE;
    80001bf2:	478d                	li	a5,3
    80001bf4:	cc9c                	sw	a5,24(s1)
  release(&p->lock);
    80001bf6:	8526                	mv	a0,s1
    80001bf8:	878ff0ef          	jal	80000c70 <release>
}
    80001bfc:	60e2                	ld	ra,24(sp)
    80001bfe:	6442                	ld	s0,16(sp)
    80001c00:	64a2                	ld	s1,8(sp)
    80001c02:	6105                	addi	sp,sp,32
    80001c04:	8082                	ret

0000000080001c06 <growproc>:
{
    80001c06:	1101                	addi	sp,sp,-32
    80001c08:	ec06                	sd	ra,24(sp)
    80001c0a:	e822                	sd	s0,16(sp)
    80001c0c:	e426                	sd	s1,8(sp)
    80001c0e:	e04a                	sd	s2,0(sp)
    80001c10:	1000                	addi	s0,sp,32
    80001c12:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    80001c14:	cf5ff0ef          	jal	80001908 <myproc>
    80001c18:	892a                	mv	s2,a0
  sz = p->sz;
    80001c1a:	652c                	ld	a1,72(a0)
  if (n > 0) {
    80001c1c:	02905963          	blez	s1,80001c4e <growproc+0x48>
    if (sz + n > TRAPFRAME) {
    80001c20:	00b48633          	add	a2,s1,a1
    80001c24:	020007b7          	lui	a5,0x2000
    80001c28:	17fd                	addi	a5,a5,-1 # 1ffffff <_entry-0x7e000001>
    80001c2a:	07b6                	slli	a5,a5,0xd
    80001c2c:	02c7ea63          	bltu	a5,a2,80001c60 <growproc+0x5a>
    if ((sz = uvmalloc(p->pagetable, sz, sz + n, PTE_W)) == 0) {
    80001c30:	4691                	li	a3,4
    80001c32:	6928                	ld	a0,80(a0)
    80001c34:	e7aff0ef          	jal	800012ae <uvmalloc>
    80001c38:	85aa                	mv	a1,a0
    80001c3a:	c50d                	beqz	a0,80001c64 <growproc+0x5e>
  p->sz = sz;
    80001c3c:	04b93423          	sd	a1,72(s2)
  return 0;
    80001c40:	4501                	li	a0,0
}
    80001c42:	60e2                	ld	ra,24(sp)
    80001c44:	6442                	ld	s0,16(sp)
    80001c46:	64a2                	ld	s1,8(sp)
    80001c48:	6902                	ld	s2,0(sp)
    80001c4a:	6105                	addi	sp,sp,32
    80001c4c:	8082                	ret
  } else if (n < 0) {
    80001c4e:	fe04d7e3          	bgez	s1,80001c3c <growproc+0x36>
    sz = uvmdealloc(p->pagetable, sz, sz + n);
    80001c52:	00b48633          	add	a2,s1,a1
    80001c56:	6928                	ld	a0,80(a0)
    80001c58:	e12ff0ef          	jal	8000126a <uvmdealloc>
    80001c5c:	85aa                	mv	a1,a0
    80001c5e:	bff9                	j	80001c3c <growproc+0x36>
      return -1;
    80001c60:	557d                	li	a0,-1
    80001c62:	b7c5                	j	80001c42 <growproc+0x3c>
      return -1;
    80001c64:	557d                	li	a0,-1
    80001c66:	bff1                	j	80001c42 <growproc+0x3c>

0000000080001c68 <kfork>:
{
    80001c68:	7139                	addi	sp,sp,-64
    80001c6a:	fc06                	sd	ra,56(sp)
    80001c6c:	f822                	sd	s0,48(sp)
    80001c6e:	f426                	sd	s1,40(sp)
    80001c70:	e456                	sd	s5,8(sp)
    80001c72:	0080                	addi	s0,sp,64
  struct proc *p = myproc();
    80001c74:	c95ff0ef          	jal	80001908 <myproc>
    80001c78:	8aaa                	mv	s5,a0
  if ((np = allocproc()) == 0) {
    80001c7a:	eabff0ef          	jal	80001b24 <allocproc>
    80001c7e:	0e050a63          	beqz	a0,80001d72 <kfork+0x10a>
    80001c82:	e852                	sd	s4,16(sp)
    80001c84:	8a2a                	mv	s4,a0
  if (uvmcopy(p->pagetable, np->pagetable, p->sz) < 0) {
    80001c86:	048ab603          	ld	a2,72(s5)
    80001c8a:	692c                	ld	a1,80(a0)
    80001c8c:	050ab503          	ld	a0,80(s5)
    80001c90:	f56ff0ef          	jal	800013e6 <uvmcopy>
    80001c94:	04054863          	bltz	a0,80001ce4 <kfork+0x7c>
    80001c98:	f04a                	sd	s2,32(sp)
    80001c9a:	ec4e                	sd	s3,24(sp)
  np->sz = p->sz;
    80001c9c:	048ab783          	ld	a5,72(s5)
    80001ca0:	04fa3423          	sd	a5,72(s4)
  *(np->trapframe) = *(p->trapframe);
    80001ca4:	058ab683          	ld	a3,88(s5)
    80001ca8:	87b6                	mv	a5,a3
    80001caa:	058a3703          	ld	a4,88(s4)
    80001cae:	12068693          	addi	a3,a3,288
    80001cb2:	6388                	ld	a0,0(a5)
    80001cb4:	678c                	ld	a1,8(a5)
    80001cb6:	6b90                	ld	a2,16(a5)
    80001cb8:	e308                	sd	a0,0(a4)
    80001cba:	e70c                	sd	a1,8(a4)
    80001cbc:	eb10                	sd	a2,16(a4)
    80001cbe:	6f90                	ld	a2,24(a5)
    80001cc0:	ef10                	sd	a2,24(a4)
    80001cc2:	02078793          	addi	a5,a5,32
    80001cc6:	02070713          	addi	a4,a4,32 # 1020 <_entry-0x7fffefe0>
    80001cca:	fed794e3          	bne	a5,a3,80001cb2 <kfork+0x4a>
  np->trapframe->a0 = 0;
    80001cce:	058a3783          	ld	a5,88(s4)
    80001cd2:	0607b823          	sd	zero,112(a5)
  for (i = 0; i < NOFILE; i++)
    80001cd6:	0d0a8493          	addi	s1,s5,208
    80001cda:	0d0a0913          	addi	s2,s4,208
    80001cde:	150a8993          	addi	s3,s5,336
    80001ce2:	a831                	j	80001cfe <kfork+0x96>
    freeproc(np);
    80001ce4:	8552                	mv	a0,s4
    80001ce6:	df3ff0ef          	jal	80001ad8 <freeproc>
    release(&np->lock);
    80001cea:	8552                	mv	a0,s4
    80001cec:	f85fe0ef          	jal	80000c70 <release>
    return -1;
    80001cf0:	54fd                	li	s1,-1
    80001cf2:	6a42                	ld	s4,16(sp)
    80001cf4:	a885                	j	80001d64 <kfork+0xfc>
  for (i = 0; i < NOFILE; i++)
    80001cf6:	04a1                	addi	s1,s1,8
    80001cf8:	0921                	addi	s2,s2,8
    80001cfa:	01348963          	beq	s1,s3,80001d0c <kfork+0xa4>
    if (p->ofile[i])
    80001cfe:	6088                	ld	a0,0(s1)
    80001d00:	d97d                	beqz	a0,80001cf6 <kfork+0x8e>
      np->ofile[i] = filedup(p->ofile[i]);
    80001d02:	47e020ef          	jal	80004180 <filedup>
    80001d06:	00a93023          	sd	a0,0(s2)
    80001d0a:	b7f5                	j	80001cf6 <kfork+0x8e>
  np->cwd = idup(p->cwd);
    80001d0c:	150ab503          	ld	a0,336(s5)
    80001d10:	54e010ef          	jal	8000325e <idup>
    80001d14:	14aa3823          	sd	a0,336(s4)
  safestrcpy(np->name, p->name, sizeof(p->name));
    80001d18:	4641                	li	a2,16
    80001d1a:	158a8593          	addi	a1,s5,344
    80001d1e:	158a0513          	addi	a0,s4,344
    80001d22:	8daff0ef          	jal	80000dfc <safestrcpy>
  pid = np->pid;
    80001d26:	030a2483          	lw	s1,48(s4)
  release(&np->lock);
    80001d2a:	8552                	mv	a0,s4
    80001d2c:	f45fe0ef          	jal	80000c70 <release>
  acquire(&wait_lock);
    80001d30:	00010517          	auipc	a0,0x10
    80001d34:	72850513          	addi	a0,a0,1832 # 80012458 <wait_lock>
    80001d38:	eb1fe0ef          	jal	80000be8 <acquire>
  np->parent = p;
    80001d3c:	035a3c23          	sd	s5,56(s4)
  release(&wait_lock);
    80001d40:	00010517          	auipc	a0,0x10
    80001d44:	71850513          	addi	a0,a0,1816 # 80012458 <wait_lock>
    80001d48:	f29fe0ef          	jal	80000c70 <release>
  acquire(&np->lock);
    80001d4c:	8552                	mv	a0,s4
    80001d4e:	e9bfe0ef          	jal	80000be8 <acquire>
  np->state = RUNNABLE;
    80001d52:	478d                	li	a5,3
    80001d54:	00fa2c23          	sw	a5,24(s4)
  release(&np->lock);
    80001d58:	8552                	mv	a0,s4
    80001d5a:	f17fe0ef          	jal	80000c70 <release>
  return pid;
    80001d5e:	7902                	ld	s2,32(sp)
    80001d60:	69e2                	ld	s3,24(sp)
    80001d62:	6a42                	ld	s4,16(sp)
}
    80001d64:	8526                	mv	a0,s1
    80001d66:	70e2                	ld	ra,56(sp)
    80001d68:	7442                	ld	s0,48(sp)
    80001d6a:	74a2                	ld	s1,40(sp)
    80001d6c:	6aa2                	ld	s5,8(sp)
    80001d6e:	6121                	addi	sp,sp,64
    80001d70:	8082                	ret
    return -1;
    80001d72:	54fd                	li	s1,-1
    80001d74:	bfc5                	j	80001d64 <kfork+0xfc>

0000000080001d76 <scheduler>:
{
    80001d76:	711d                	addi	sp,sp,-96
    80001d78:	ec86                	sd	ra,88(sp)
    80001d7a:	e8a2                	sd	s0,80(sp)
    80001d7c:	e4a6                	sd	s1,72(sp)
    80001d7e:	e0ca                	sd	s2,64(sp)
    80001d80:	fc4e                	sd	s3,56(sp)
    80001d82:	f852                	sd	s4,48(sp)
    80001d84:	f456                	sd	s5,40(sp)
    80001d86:	f05a                	sd	s6,32(sp)
    80001d88:	ec5e                	sd	s7,24(sp)
    80001d8a:	e862                	sd	s8,16(sp)
    80001d8c:	e466                	sd	s9,8(sp)
    80001d8e:	1080                	addi	s0,sp,96
    80001d90:	8792                	mv	a5,tp
  int id = r_tp();
    80001d92:	2781                	sext.w	a5,a5
  c->proc = 0;
    80001d94:	00779a93          	slli	s5,a5,0x7
    80001d98:	00010717          	auipc	a4,0x10
    80001d9c:	6a870713          	addi	a4,a4,1704 # 80012440 <pid_lock>
    80001da0:	9756                	add	a4,a4,s5
    80001da2:	02073823          	sd	zero,48(a4)
        swtch(&c->context, &p->context);
    80001da6:	00010717          	auipc	a4,0x10
    80001daa:	6d270713          	addi	a4,a4,1746 # 80012478 <cpus+0x8>
    80001dae:	9aba                	add	s5,s5,a4
        p->state = RUNNING;
    80001db0:	4c11                	li	s8,4
        c->proc = p;
    80001db2:	00010b17          	auipc	s6,0x10
    80001db6:	68eb0b13          	addi	s6,s6,1678 # 80012440 <pid_lock>
    80001dba:	079e                	slli	a5,a5,0x7
    80001dbc:	00fb0a33          	add	s4,s6,a5
        found = 1;
    80001dc0:	4b85                	li	s7,1
    80001dc2:	a0a9                	j	80001e0c <scheduler+0x96>
      release(&p->lock);
    80001dc4:	8526                	mv	a0,s1
    80001dc6:	eabfe0ef          	jal	80000c70 <release>
    for (p = proc; p < &proc[NPROC]; p++) {
    80001dca:	16848493          	addi	s1,s1,360
    80001dce:	03248b63          	beq	s1,s2,80001e04 <scheduler+0x8e>
      acquire(&p->lock);
    80001dd2:	8526                	mv	a0,s1
    80001dd4:	e15fe0ef          	jal	80000be8 <acquire>
      if (p->state == RUNNABLE) {
    80001dd8:	4c9c                	lw	a5,24(s1)
    80001dda:	ff3795e3          	bne	a5,s3,80001dc4 <scheduler+0x4e>
        p->state = RUNNING;
    80001dde:	0184ac23          	sw	s8,24(s1)
        c->proc = p;
    80001de2:	029a3823          	sd	s1,48(s4)
        swtch(&c->context, &p->context);
    80001de6:	06048593          	addi	a1,s1,96
    80001dea:	8556                	mv	a0,s5
    80001dec:	5f4000ef          	jal	800023e0 <swtch>
    80001df0:	8792                	mv	a5,tp
        mycpu()->intena = 0;
    80001df2:	2781                	sext.w	a5,a5
    80001df4:	079e                	slli	a5,a5,0x7
    80001df6:	97da                	add	a5,a5,s6
    80001df8:	0a07a623          	sw	zero,172(a5)
        c->proc = 0;
    80001dfc:	020a3823          	sd	zero,48(s4)
        found = 1;
    80001e00:	8cde                	mv	s9,s7
    80001e02:	b7c9                	j	80001dc4 <scheduler+0x4e>
    if (found == 0) {
    80001e04:	000c9463          	bnez	s9,80001e0c <scheduler+0x96>
      asm volatile("wfi");
    80001e08:	10500073          	wfi
  __asm__ __volatile__("csrs sstatus, %0" ::"rK"(x) : "memory");
    80001e0c:	10016073          	csrsi	sstatus,2
  __asm__ __volatile__("csrc sstatus, %0" ::"rK"(x) : "memory");
    80001e10:	10017073          	csrci	sstatus,2
    int found = 0;
    80001e14:	4c81                	li	s9,0
    for (p = proc; p < &proc[NPROC]; p++) {
    80001e16:	00011497          	auipc	s1,0x11
    80001e1a:	a5a48493          	addi	s1,s1,-1446 # 80012870 <proc>
      if (p->state == RUNNABLE) {
    80001e1e:	498d                	li	s3,3
    for (p = proc; p < &proc[NPROC]; p++) {
    80001e20:	00016917          	auipc	s2,0x16
    80001e24:	45090913          	addi	s2,s2,1104 # 80018270 <tickslock>
    80001e28:	b76d                	j	80001dd2 <scheduler+0x5c>

0000000080001e2a <sched>:
{
    80001e2a:	7179                	addi	sp,sp,-48
    80001e2c:	f406                	sd	ra,40(sp)
    80001e2e:	f022                	sd	s0,32(sp)
    80001e30:	ec26                	sd	s1,24(sp)
    80001e32:	e84a                	sd	s2,16(sp)
    80001e34:	e44e                	sd	s3,8(sp)
    80001e36:	1800                	addi	s0,sp,48
  struct proc *p = myproc();
    80001e38:	ad1ff0ef          	jal	80001908 <myproc>
    80001e3c:	84aa                	mv	s1,a0
  if (!holding(&p->lock))
    80001e3e:	d45fe0ef          	jal	80000b82 <holding>
    80001e42:	c935                	beqz	a0,80001eb6 <sched+0x8c>
  asm volatile("mv %0, tp" : "=r"(x));
    80001e44:	8792                	mv	a5,tp
  if (mycpu()->noff != 1)
    80001e46:	2781                	sext.w	a5,a5
    80001e48:	079e                	slli	a5,a5,0x7
    80001e4a:	00010717          	auipc	a4,0x10
    80001e4e:	5f670713          	addi	a4,a4,1526 # 80012440 <pid_lock>
    80001e52:	97ba                	add	a5,a5,a4
    80001e54:	0a87a703          	lw	a4,168(a5)
    80001e58:	4785                	li	a5,1
    80001e5a:	06f71463          	bne	a4,a5,80001ec2 <sched+0x98>
  if (p->state == RUNNING)
    80001e5e:	4c98                	lw	a4,24(s1)
    80001e60:	4791                	li	a5,4
    80001e62:	06f70663          	beq	a4,a5,80001ece <sched+0xa4>
  asm volatile("csrr %0, sstatus" : "=r"(x));
    80001e66:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80001e6a:	8b89                	andi	a5,a5,2
  if (intr_get())
    80001e6c:	e7bd                	bnez	a5,80001eda <sched+0xb0>
  asm volatile("mv %0, tp" : "=r"(x));
    80001e6e:	8792                	mv	a5,tp
  intena = mycpu()->intena;
    80001e70:	00010917          	auipc	s2,0x10
    80001e74:	5d090913          	addi	s2,s2,1488 # 80012440 <pid_lock>
    80001e78:	2781                	sext.w	a5,a5
    80001e7a:	079e                	slli	a5,a5,0x7
    80001e7c:	97ca                	add	a5,a5,s2
    80001e7e:	0ac7a983          	lw	s3,172(a5)
    80001e82:	8792                	mv	a5,tp
  swtch(&p->context, &mycpu()->context);
    80001e84:	2781                	sext.w	a5,a5
    80001e86:	079e                	slli	a5,a5,0x7
    80001e88:	07a1                	addi	a5,a5,8
    80001e8a:	00010597          	auipc	a1,0x10
    80001e8e:	5e658593          	addi	a1,a1,1510 # 80012470 <cpus>
    80001e92:	95be                	add	a1,a1,a5
    80001e94:	06048513          	addi	a0,s1,96
    80001e98:	548000ef          	jal	800023e0 <swtch>
    80001e9c:	8792                	mv	a5,tp
  mycpu()->intena = intena;
    80001e9e:	2781                	sext.w	a5,a5
    80001ea0:	079e                	slli	a5,a5,0x7
    80001ea2:	993e                	add	s2,s2,a5
    80001ea4:	0b392623          	sw	s3,172(s2)
}
    80001ea8:	70a2                	ld	ra,40(sp)
    80001eaa:	7402                	ld	s0,32(sp)
    80001eac:	64e2                	ld	s1,24(sp)
    80001eae:	6942                	ld	s2,16(sp)
    80001eb0:	69a2                	ld	s3,8(sp)
    80001eb2:	6145                	addi	sp,sp,48
    80001eb4:	8082                	ret
    panic("sched p->lock");
    80001eb6:	00005517          	auipc	a0,0x5
    80001eba:	2e250513          	addi	a0,a0,738 # 80007198 <etext+0x198>
    80001ebe:	977fe0ef          	jal	80000834 <panic>
    panic("sched locks");
    80001ec2:	00005517          	auipc	a0,0x5
    80001ec6:	2e650513          	addi	a0,a0,742 # 800071a8 <etext+0x1a8>
    80001eca:	96bfe0ef          	jal	80000834 <panic>
    panic("sched RUNNING");
    80001ece:	00005517          	auipc	a0,0x5
    80001ed2:	2ea50513          	addi	a0,a0,746 # 800071b8 <etext+0x1b8>
    80001ed6:	95ffe0ef          	jal	80000834 <panic>
    panic("sched interruptible");
    80001eda:	00005517          	auipc	a0,0x5
    80001ede:	2ee50513          	addi	a0,a0,750 # 800071c8 <etext+0x1c8>
    80001ee2:	953fe0ef          	jal	80000834 <panic>

0000000080001ee6 <yield>:
{
    80001ee6:	1101                	addi	sp,sp,-32
    80001ee8:	ec06                	sd	ra,24(sp)
    80001eea:	e822                	sd	s0,16(sp)
    80001eec:	e426                	sd	s1,8(sp)
    80001eee:	1000                	addi	s0,sp,32
  struct proc *p = myproc();
    80001ef0:	a19ff0ef          	jal	80001908 <myproc>
    80001ef4:	84aa                	mv	s1,a0
  acquire(&p->lock);
    80001ef6:	cf3fe0ef          	jal	80000be8 <acquire>
  p->state = RUNNABLE;
    80001efa:	478d                	li	a5,3
    80001efc:	cc9c                	sw	a5,24(s1)
  sched();
    80001efe:	f2dff0ef          	jal	80001e2a <sched>
  release(&p->lock);
    80001f02:	8526                	mv	a0,s1
    80001f04:	d6dfe0ef          	jal	80000c70 <release>
}
    80001f08:	60e2                	ld	ra,24(sp)
    80001f0a:	6442                	ld	s0,16(sp)
    80001f0c:	64a2                	ld	s1,8(sp)
    80001f0e:	6105                	addi	sp,sp,32
    80001f10:	8082                	ret

0000000080001f12 <sleep_prepare>:

// Register current process as waiting for wakeups on chan.
void
sleep_prepare(void *chan)
{
    80001f12:	1101                	addi	sp,sp,-32
    80001f14:	ec06                	sd	ra,24(sp)
    80001f16:	e822                	sd	s0,16(sp)
    80001f18:	e426                	sd	s1,8(sp)
    80001f1a:	e04a                	sd	s2,0(sp)
    80001f1c:	1000                	addi	s0,sp,32
    80001f1e:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    80001f20:	9e9ff0ef          	jal	80001908 <myproc>
    80001f24:	892a                	mv	s2,a0

  acquire(&p->lock);
    80001f26:	cc3fe0ef          	jal	80000be8 <acquire>
  if (chan == 0)
    80001f2a:	cc81                	beqz	s1,80001f42 <sleep_prepare+0x30>
    panic("sleep_prepare: zero chan");
  p->chan = chan;
    80001f2c:	02993023          	sd	s1,32(s2)
  release(&p->lock);
    80001f30:	854a                	mv	a0,s2
    80001f32:	d3ffe0ef          	jal	80000c70 <release>
}
    80001f36:	60e2                	ld	ra,24(sp)
    80001f38:	6442                	ld	s0,16(sp)
    80001f3a:	64a2                	ld	s1,8(sp)
    80001f3c:	6902                	ld	s2,0(sp)
    80001f3e:	6105                	addi	sp,sp,32
    80001f40:	8082                	ret
    panic("sleep_prepare: zero chan");
    80001f42:	00005517          	auipc	a0,0x5
    80001f46:	29e50513          	addi	a0,a0,670 # 800071e0 <etext+0x1e0>
    80001f4a:	8ebfe0ef          	jal	80000834 <panic>

0000000080001f4e <sleep>:
// Put the thread to sleep.  Assumes sleep_prepare() was called before.
// If the channel registered by sleep_prepare() has been woken up in
// the meantime, do not go to sleep, and instead return immediately.
void
sleep(void)
{
    80001f4e:	1101                	addi	sp,sp,-32
    80001f50:	ec06                	sd	ra,24(sp)
    80001f52:	e822                	sd	s0,16(sp)
    80001f54:	e426                	sd	s1,8(sp)
    80001f56:	1000                	addi	s0,sp,32
  struct proc *p = myproc();
    80001f58:	9b1ff0ef          	jal	80001908 <myproc>
    80001f5c:	84aa                	mv	s1,a0

  acquire(&p->lock);
    80001f5e:	c8bfe0ef          	jal	80000be8 <acquire>
  if (p->chan != 0) {
    80001f62:	709c                	ld	a5,32(s1)
    80001f64:	c789                	beqz	a5,80001f6e <sleep+0x20>
    p->state = SLEEPING;
    80001f66:	4789                	li	a5,2
    80001f68:	cc9c                	sw	a5,24(s1)
    sched();
    80001f6a:	ec1ff0ef          	jal	80001e2a <sched>
  }
  release(&p->lock);
    80001f6e:	8526                	mv	a0,s1
    80001f70:	d01fe0ef          	jal	80000c70 <release>
}
    80001f74:	60e2                	ld	ra,24(sp)
    80001f76:	6442                	ld	s0,16(sp)
    80001f78:	64a2                	ld	s1,8(sp)
    80001f7a:	6105                	addi	sp,sp,32
    80001f7c:	8082                	ret

0000000080001f7e <wakeup>:

// Wake up all processes sleeping on channel chan.
void
wakeup(void *chan)
{
    80001f7e:	7139                	addi	sp,sp,-64
    80001f80:	fc06                	sd	ra,56(sp)
    80001f82:	f822                	sd	s0,48(sp)
    80001f84:	f426                	sd	s1,40(sp)
    80001f86:	f04a                	sd	s2,32(sp)
    80001f88:	ec4e                	sd	s3,24(sp)
    80001f8a:	e852                	sd	s4,16(sp)
    80001f8c:	e456                	sd	s5,8(sp)
    80001f8e:	0080                	addi	s0,sp,64
    80001f90:	892a                	mv	s2,a0
  struct proc *p;

  for (p = proc; p < &proc[NPROC]; p++) {
    80001f92:	00011497          	auipc	s1,0x11
    80001f96:	8de48493          	addi	s1,s1,-1826 # 80012870 <proc>
      // signal that the wakeup happened by clearing p->chan.
      p->chan = 0;

      // If this waiting process has gotten so far as to actually
      // go to sleep, also set it back to RUNNING.
      if (p->state == SLEEPING) {
    80001f9a:	4a09                	li	s4,2
        p->state = RUNNABLE;
    80001f9c:	4a8d                	li	s5,3
  for (p = proc; p < &proc[NPROC]; p++) {
    80001f9e:	00016997          	auipc	s3,0x16
    80001fa2:	2d298993          	addi	s3,s3,722 # 80018270 <tickslock>
    80001fa6:	a801                	j	80001fb6 <wakeup+0x38>
      }
    }
    release(&p->lock);
    80001fa8:	8526                	mv	a0,s1
    80001faa:	cc7fe0ef          	jal	80000c70 <release>
  for (p = proc; p < &proc[NPROC]; p++) {
    80001fae:	16848493          	addi	s1,s1,360
    80001fb2:	03348063          	beq	s1,s3,80001fd2 <wakeup+0x54>
    acquire(&p->lock);
    80001fb6:	8526                	mv	a0,s1
    80001fb8:	c31fe0ef          	jal	80000be8 <acquire>
    if (p->chan == chan) {
    80001fbc:	709c                	ld	a5,32(s1)
    80001fbe:	ff2795e3          	bne	a5,s2,80001fa8 <wakeup+0x2a>
      p->chan = 0;
    80001fc2:	0204b023          	sd	zero,32(s1)
      if (p->state == SLEEPING) {
    80001fc6:	4c9c                	lw	a5,24(s1)
    80001fc8:	ff4790e3          	bne	a5,s4,80001fa8 <wakeup+0x2a>
        p->state = RUNNABLE;
    80001fcc:	0154ac23          	sw	s5,24(s1)
    80001fd0:	bfe1                	j	80001fa8 <wakeup+0x2a>
  }
}
    80001fd2:	70e2                	ld	ra,56(sp)
    80001fd4:	7442                	ld	s0,48(sp)
    80001fd6:	74a2                	ld	s1,40(sp)
    80001fd8:	7902                	ld	s2,32(sp)
    80001fda:	69e2                	ld	s3,24(sp)
    80001fdc:	6a42                	ld	s4,16(sp)
    80001fde:	6aa2                	ld	s5,8(sp)
    80001fe0:	6121                	addi	sp,sp,64
    80001fe2:	8082                	ret

0000000080001fe4 <reparent>:
{
    80001fe4:	7179                	addi	sp,sp,-48
    80001fe6:	f406                	sd	ra,40(sp)
    80001fe8:	f022                	sd	s0,32(sp)
    80001fea:	ec26                	sd	s1,24(sp)
    80001fec:	e84a                	sd	s2,16(sp)
    80001fee:	e44e                	sd	s3,8(sp)
    80001ff0:	e052                	sd	s4,0(sp)
    80001ff2:	1800                	addi	s0,sp,48
    80001ff4:	892a                	mv	s2,a0
  for (pp = proc; pp < &proc[NPROC]; pp++) {
    80001ff6:	00011497          	auipc	s1,0x11
    80001ffa:	87a48493          	addi	s1,s1,-1926 # 80012870 <proc>
      pp->parent = initproc;
    80001ffe:	00008a17          	auipc	s4,0x8
    80002002:	31aa0a13          	addi	s4,s4,794 # 8000a318 <initproc>
  for (pp = proc; pp < &proc[NPROC]; pp++) {
    80002006:	00016997          	auipc	s3,0x16
    8000200a:	26a98993          	addi	s3,s3,618 # 80018270 <tickslock>
    8000200e:	a029                	j	80002018 <reparent+0x34>
    80002010:	16848493          	addi	s1,s1,360
    80002014:	01348b63          	beq	s1,s3,8000202a <reparent+0x46>
    if (pp->parent == p) {
    80002018:	7c9c                	ld	a5,56(s1)
    8000201a:	ff279be3          	bne	a5,s2,80002010 <reparent+0x2c>
      pp->parent = initproc;
    8000201e:	000a3503          	ld	a0,0(s4)
    80002022:	fc88                	sd	a0,56(s1)
      wakeup(initproc);
    80002024:	f5bff0ef          	jal	80001f7e <wakeup>
    80002028:	b7e5                	j	80002010 <reparent+0x2c>
}
    8000202a:	70a2                	ld	ra,40(sp)
    8000202c:	7402                	ld	s0,32(sp)
    8000202e:	64e2                	ld	s1,24(sp)
    80002030:	6942                	ld	s2,16(sp)
    80002032:	69a2                	ld	s3,8(sp)
    80002034:	6a02                	ld	s4,0(sp)
    80002036:	6145                	addi	sp,sp,48
    80002038:	8082                	ret

000000008000203a <kexit>:
{
    8000203a:	7179                	addi	sp,sp,-48
    8000203c:	f406                	sd	ra,40(sp)
    8000203e:	f022                	sd	s0,32(sp)
    80002040:	ec26                	sd	s1,24(sp)
    80002042:	e84a                	sd	s2,16(sp)
    80002044:	e44e                	sd	s3,8(sp)
    80002046:	e052                	sd	s4,0(sp)
    80002048:	1800                	addi	s0,sp,48
    8000204a:	8a2a                	mv	s4,a0
  struct proc *p = myproc();
    8000204c:	8bdff0ef          	jal	80001908 <myproc>
    80002050:	89aa                	mv	s3,a0
  if (p == initproc)
    80002052:	00008797          	auipc	a5,0x8
    80002056:	2c67b783          	ld	a5,710(a5) # 8000a318 <initproc>
    8000205a:	0d050493          	addi	s1,a0,208
    8000205e:	15050913          	addi	s2,a0,336
    80002062:	00a79b63          	bne	a5,a0,80002078 <kexit+0x3e>
    panic("init exiting");
    80002066:	00005517          	auipc	a0,0x5
    8000206a:	19a50513          	addi	a0,a0,410 # 80007200 <etext+0x200>
    8000206e:	fc6fe0ef          	jal	80000834 <panic>
  for (int fd = 0; fd < NOFILE; fd++) {
    80002072:	04a1                	addi	s1,s1,8
    80002074:	01248963          	beq	s1,s2,80002086 <kexit+0x4c>
    if (p->ofile[fd]) {
    80002078:	6088                	ld	a0,0(s1)
    8000207a:	dd65                	beqz	a0,80002072 <kexit+0x38>
      fileclose(f);
    8000207c:	14a020ef          	jal	800041c6 <fileclose>
      p->ofile[fd] = 0;
    80002080:	0004b023          	sd	zero,0(s1)
    80002084:	b7fd                	j	80002072 <kexit+0x38>
  begin_op();
    80002086:	487010ef          	jal	80003d0c <begin_op>
  iput(p->cwd);
    8000208a:	1509b503          	ld	a0,336(s3)
    8000208e:	388010ef          	jal	80003416 <iput>
  end_op();
    80002092:	507010ef          	jal	80003d98 <end_op>
  p->cwd = 0;
    80002096:	1409b823          	sd	zero,336(s3)
  acquire(&wait_lock);
    8000209a:	00010517          	auipc	a0,0x10
    8000209e:	3be50513          	addi	a0,a0,958 # 80012458 <wait_lock>
    800020a2:	b47fe0ef          	jal	80000be8 <acquire>
  reparent(p);
    800020a6:	854e                	mv	a0,s3
    800020a8:	f3dff0ef          	jal	80001fe4 <reparent>
  wakeup(p->parent);
    800020ac:	0389b503          	ld	a0,56(s3)
    800020b0:	ecfff0ef          	jal	80001f7e <wakeup>
  acquire(&p->lock);
    800020b4:	854e                	mv	a0,s3
    800020b6:	b33fe0ef          	jal	80000be8 <acquire>
  p->xstate = status;
    800020ba:	0349a623          	sw	s4,44(s3)
  p->state = ZOMBIE;
    800020be:	4795                	li	a5,5
    800020c0:	00f9ac23          	sw	a5,24(s3)
  release(&wait_lock);
    800020c4:	00010517          	auipc	a0,0x10
    800020c8:	39450513          	addi	a0,a0,916 # 80012458 <wait_lock>
    800020cc:	ba5fe0ef          	jal	80000c70 <release>
  sched();
    800020d0:	d5bff0ef          	jal	80001e2a <sched>
  panic("zombie exit");
    800020d4:	00005517          	auipc	a0,0x5
    800020d8:	13c50513          	addi	a0,a0,316 # 80007210 <etext+0x210>
    800020dc:	f58fe0ef          	jal	80000834 <panic>

00000000800020e0 <kkill>:
int
kkill(int pid)
{
  struct proc *p;

  if (pid == 0)
    800020e0:	c525                	beqz	a0,80002148 <kkill+0x68>
{
    800020e2:	7179                	addi	sp,sp,-48
    800020e4:	f406                	sd	ra,40(sp)
    800020e6:	f022                	sd	s0,32(sp)
    800020e8:	ec26                	sd	s1,24(sp)
    800020ea:	e84a                	sd	s2,16(sp)
    800020ec:	e44e                	sd	s3,8(sp)
    800020ee:	1800                	addi	s0,sp,48
    800020f0:	892a                	mv	s2,a0
    return -1;

  for (p = proc; p < &proc[NPROC]; p++) {
    800020f2:	00010497          	auipc	s1,0x10
    800020f6:	77e48493          	addi	s1,s1,1918 # 80012870 <proc>
    800020fa:	00016997          	auipc	s3,0x16
    800020fe:	17698993          	addi	s3,s3,374 # 80018270 <tickslock>
    acquire(&p->lock);
    80002102:	8526                	mv	a0,s1
    80002104:	ae5fe0ef          	jal	80000be8 <acquire>
    if (p->pid == pid) {
    80002108:	589c                	lw	a5,48(s1)
    8000210a:	01278b63          	beq	a5,s2,80002120 <kkill+0x40>
        p->state = RUNNABLE;
      }
      release(&p->lock);
      return 0;
    }
    release(&p->lock);
    8000210e:	8526                	mv	a0,s1
    80002110:	b61fe0ef          	jal	80000c70 <release>
  for (p = proc; p < &proc[NPROC]; p++) {
    80002114:	16848493          	addi	s1,s1,360
    80002118:	ff3495e3          	bne	s1,s3,80002102 <kkill+0x22>
  }
  return -1;
    8000211c:	557d                	li	a0,-1
    8000211e:	a819                	j	80002134 <kkill+0x54>
      p->killed = 1;
    80002120:	4785                	li	a5,1
    80002122:	d49c                	sw	a5,40(s1)
      if (p->state == SLEEPING) {
    80002124:	4c98                	lw	a4,24(s1)
    80002126:	4789                	li	a5,2
    80002128:	00f70d63          	beq	a4,a5,80002142 <kkill+0x62>
      release(&p->lock);
    8000212c:	8526                	mv	a0,s1
    8000212e:	b43fe0ef          	jal	80000c70 <release>
      return 0;
    80002132:	4501                	li	a0,0
}
    80002134:	70a2                	ld	ra,40(sp)
    80002136:	7402                	ld	s0,32(sp)
    80002138:	64e2                	ld	s1,24(sp)
    8000213a:	6942                	ld	s2,16(sp)
    8000213c:	69a2                	ld	s3,8(sp)
    8000213e:	6145                	addi	sp,sp,48
    80002140:	8082                	ret
        p->state = RUNNABLE;
    80002142:	478d                	li	a5,3
    80002144:	cc9c                	sw	a5,24(s1)
    80002146:	b7dd                	j	8000212c <kkill+0x4c>
    return -1;
    80002148:	557d                	li	a0,-1
}
    8000214a:	8082                	ret

000000008000214c <setkilled>:

void
setkilled(struct proc *p)
{
    8000214c:	1101                	addi	sp,sp,-32
    8000214e:	ec06                	sd	ra,24(sp)
    80002150:	e822                	sd	s0,16(sp)
    80002152:	e426                	sd	s1,8(sp)
    80002154:	1000                	addi	s0,sp,32
    80002156:	84aa                	mv	s1,a0
  acquire(&p->lock);
    80002158:	a91fe0ef          	jal	80000be8 <acquire>
  p->killed = 1;
    8000215c:	4785                	li	a5,1
    8000215e:	d49c                	sw	a5,40(s1)
  release(&p->lock);
    80002160:	8526                	mv	a0,s1
    80002162:	b0ffe0ef          	jal	80000c70 <release>
}
    80002166:	60e2                	ld	ra,24(sp)
    80002168:	6442                	ld	s0,16(sp)
    8000216a:	64a2                	ld	s1,8(sp)
    8000216c:	6105                	addi	sp,sp,32
    8000216e:	8082                	ret

0000000080002170 <killed>:

int
killed(struct proc *p)
{
    80002170:	1101                	addi	sp,sp,-32
    80002172:	ec06                	sd	ra,24(sp)
    80002174:	e822                	sd	s0,16(sp)
    80002176:	e426                	sd	s1,8(sp)
    80002178:	e04a                	sd	s2,0(sp)
    8000217a:	1000                	addi	s0,sp,32
    8000217c:	84aa                	mv	s1,a0
  int k;

  acquire(&p->lock);
    8000217e:	a6bfe0ef          	jal	80000be8 <acquire>
  k = p->killed;
    80002182:	549c                	lw	a5,40(s1)
    80002184:	893e                	mv	s2,a5
  release(&p->lock);
    80002186:	8526                	mv	a0,s1
    80002188:	ae9fe0ef          	jal	80000c70 <release>
  return k;
}
    8000218c:	854a                	mv	a0,s2
    8000218e:	60e2                	ld	ra,24(sp)
    80002190:	6442                	ld	s0,16(sp)
    80002192:	64a2                	ld	s1,8(sp)
    80002194:	6902                	ld	s2,0(sp)
    80002196:	6105                	addi	sp,sp,32
    80002198:	8082                	ret

000000008000219a <kwait>:
{
    8000219a:	715d                	addi	sp,sp,-80
    8000219c:	e486                	sd	ra,72(sp)
    8000219e:	e0a2                	sd	s0,64(sp)
    800021a0:	fc26                	sd	s1,56(sp)
    800021a2:	f84a                	sd	s2,48(sp)
    800021a4:	f44e                	sd	s3,40(sp)
    800021a6:	f052                	sd	s4,32(sp)
    800021a8:	ec56                	sd	s5,24(sp)
    800021aa:	e85a                	sd	s6,16(sp)
    800021ac:	e45e                	sd	s7,8(sp)
    800021ae:	0880                	addi	s0,sp,80
    800021b0:	8baa                	mv	s7,a0
  struct proc *p = myproc();
    800021b2:	f56ff0ef          	jal	80001908 <myproc>
    800021b6:	892a                	mv	s2,a0
  acquire(&wait_lock);
    800021b8:	00010517          	auipc	a0,0x10
    800021bc:	2a050513          	addi	a0,a0,672 # 80012458 <wait_lock>
    800021c0:	a29fe0ef          	jal	80000be8 <acquire>
        if (pp->state == ZOMBIE) {
    800021c4:	4a15                	li	s4,5
        havekids = 1;
    800021c6:	4a85                	li	s5,1
    for (pp = proc; pp < &proc[NPROC]; pp++) {
    800021c8:	00016997          	auipc	s3,0x16
    800021cc:	0a898993          	addi	s3,s3,168 # 80018270 <tickslock>
    release(&wait_lock);
    800021d0:	00010b17          	auipc	s6,0x10
    800021d4:	288b0b13          	addi	s6,s6,648 # 80012458 <wait_lock>
    800021d8:	a845                	j	80002288 <kwait+0xee>
          pid = pp->pid;
    800021da:	0304a983          	lw	s3,48(s1)
          if (addr != 0 &&
    800021de:	000b8e63          	beqz	s7,800021fa <kwait+0x60>
              copyout(p->pagetable, p->sz, addr, (char *)&pp->xstate,
    800021e2:	4711                	li	a4,4
    800021e4:	02c48693          	addi	a3,s1,44
    800021e8:	865e                	mv	a2,s7
    800021ea:	04893583          	ld	a1,72(s2)
    800021ee:	05093503          	ld	a0,80(s2)
    800021f2:	b50ff0ef          	jal	80001542 <copyout>
          if (addr != 0 &&
    800021f6:	02054c63          	bltz	a0,8000222e <kwait+0x94>
          pp->parent = 0;
    800021fa:	0204bc23          	sd	zero,56(s1)
          freeproc(pp);
    800021fe:	8526                	mv	a0,s1
    80002200:	8d9ff0ef          	jal	80001ad8 <freeproc>
          release(&pp->lock);
    80002204:	8526                	mv	a0,s1
    80002206:	a6bfe0ef          	jal	80000c70 <release>
          release(&wait_lock);
    8000220a:	00010517          	auipc	a0,0x10
    8000220e:	24e50513          	addi	a0,a0,590 # 80012458 <wait_lock>
    80002212:	a5ffe0ef          	jal	80000c70 <release>
}
    80002216:	854e                	mv	a0,s3
    80002218:	60a6                	ld	ra,72(sp)
    8000221a:	6406                	ld	s0,64(sp)
    8000221c:	74e2                	ld	s1,56(sp)
    8000221e:	7942                	ld	s2,48(sp)
    80002220:	79a2                	ld	s3,40(sp)
    80002222:	7a02                	ld	s4,32(sp)
    80002224:	6ae2                	ld	s5,24(sp)
    80002226:	6b42                	ld	s6,16(sp)
    80002228:	6ba2                	ld	s7,8(sp)
    8000222a:	6161                	addi	sp,sp,80
    8000222c:	8082                	ret
            release(&pp->lock);
    8000222e:	8526                	mv	a0,s1
    80002230:	a41fe0ef          	jal	80000c70 <release>
            release(&wait_lock);
    80002234:	00010517          	auipc	a0,0x10
    80002238:	22450513          	addi	a0,a0,548 # 80012458 <wait_lock>
    8000223c:	a35fe0ef          	jal	80000c70 <release>
            return -1;
    80002240:	59fd                	li	s3,-1
    80002242:	bfd1                	j	80002216 <kwait+0x7c>
    for (pp = proc; pp < &proc[NPROC]; pp++) {
    80002244:	16848493          	addi	s1,s1,360
    80002248:	03348063          	beq	s1,s3,80002268 <kwait+0xce>
      if (pp->parent == p) {
    8000224c:	7c9c                	ld	a5,56(s1)
    8000224e:	ff279be3          	bne	a5,s2,80002244 <kwait+0xaa>
        acquire(&pp->lock);
    80002252:	8526                	mv	a0,s1
    80002254:	995fe0ef          	jal	80000be8 <acquire>
        if (pp->state == ZOMBIE) {
    80002258:	4c9c                	lw	a5,24(s1)
    8000225a:	f94780e3          	beq	a5,s4,800021da <kwait+0x40>
        release(&pp->lock);
    8000225e:	8526                	mv	a0,s1
    80002260:	a11fe0ef          	jal	80000c70 <release>
        havekids = 1;
    80002264:	8756                	mv	a4,s5
    80002266:	bff9                	j	80002244 <kwait+0xaa>
    if (!havekids || killed(p)) {
    80002268:	c715                	beqz	a4,80002294 <kwait+0xfa>
    8000226a:	854a                	mv	a0,s2
    8000226c:	f05ff0ef          	jal	80002170 <killed>
    80002270:	e115                	bnez	a0,80002294 <kwait+0xfa>
    sleep_prepare(p); //DOC: wait-sleep
    80002272:	854a                	mv	a0,s2
    80002274:	c9fff0ef          	jal	80001f12 <sleep_prepare>
    release(&wait_lock);
    80002278:	855a                	mv	a0,s6
    8000227a:	9f7fe0ef          	jal	80000c70 <release>
    sleep();
    8000227e:	cd1ff0ef          	jal	80001f4e <sleep>
    acquire(&wait_lock);
    80002282:	855a                	mv	a0,s6
    80002284:	965fe0ef          	jal	80000be8 <acquire>
    havekids = 0;
    80002288:	4701                	li	a4,0
    for (pp = proc; pp < &proc[NPROC]; pp++) {
    8000228a:	00010497          	auipc	s1,0x10
    8000228e:	5e648493          	addi	s1,s1,1510 # 80012870 <proc>
    80002292:	bf6d                	j	8000224c <kwait+0xb2>
      release(&wait_lock);
    80002294:	00010517          	auipc	a0,0x10
    80002298:	1c450513          	addi	a0,a0,452 # 80012458 <wait_lock>
    8000229c:	9d5fe0ef          	jal	80000c70 <release>
      return -1;
    800022a0:	59fd                	li	s3,-1
    800022a2:	bf95                	j	80002216 <kwait+0x7c>

00000000800022a4 <either_copyout>:
// Copy to either a user address, or kernel address,
// depending on usr_dst.
// Returns 0 on success, -1 on error.
int
either_copyout(int user_dst, uint64 dst, void *src, uint64 len)
{
    800022a4:	7179                	addi	sp,sp,-48
    800022a6:	f406                	sd	ra,40(sp)
    800022a8:	f022                	sd	s0,32(sp)
    800022aa:	ec26                	sd	s1,24(sp)
    800022ac:	e84a                	sd	s2,16(sp)
    800022ae:	e44e                	sd	s3,8(sp)
    800022b0:	e052                	sd	s4,0(sp)
    800022b2:	1800                	addi	s0,sp,48
    800022b4:	84aa                	mv	s1,a0
    800022b6:	8a2e                	mv	s4,a1
    800022b8:	89b2                	mv	s3,a2
    800022ba:	8936                	mv	s2,a3
  struct proc *p = myproc();
    800022bc:	e4cff0ef          	jal	80001908 <myproc>
  if (user_dst) {
    800022c0:	c085                	beqz	s1,800022e0 <either_copyout+0x3c>
    return copyout(p->pagetable, p->sz, dst, src, len);
    800022c2:	874a                	mv	a4,s2
    800022c4:	86ce                	mv	a3,s3
    800022c6:	8652                	mv	a2,s4
    800022c8:	652c                	ld	a1,72(a0)
    800022ca:	6928                	ld	a0,80(a0)
    800022cc:	a76ff0ef          	jal	80001542 <copyout>
  } else {
    memmove((char *)dst, src, len);
    return 0;
  }
}
    800022d0:	70a2                	ld	ra,40(sp)
    800022d2:	7402                	ld	s0,32(sp)
    800022d4:	64e2                	ld	s1,24(sp)
    800022d6:	6942                	ld	s2,16(sp)
    800022d8:	69a2                	ld	s3,8(sp)
    800022da:	6a02                	ld	s4,0(sp)
    800022dc:	6145                	addi	sp,sp,48
    800022de:	8082                	ret
    memmove((char *)dst, src, len);
    800022e0:	0009061b          	sext.w	a2,s2
    800022e4:	85ce                	mv	a1,s3
    800022e6:	8552                	mv	a0,s4
    800022e8:	a21fe0ef          	jal	80000d08 <memmove>
    return 0;
    800022ec:	8526                	mv	a0,s1
    800022ee:	b7cd                	j	800022d0 <either_copyout+0x2c>

00000000800022f0 <either_copyin>:
// Copy from either a user address, or kernel address,
// depending on usr_src.
// Returns 0 on success, -1 on error.
int
either_copyin(void *dst, int user_src, uint64 src, uint64 len)
{
    800022f0:	7179                	addi	sp,sp,-48
    800022f2:	f406                	sd	ra,40(sp)
    800022f4:	f022                	sd	s0,32(sp)
    800022f6:	ec26                	sd	s1,24(sp)
    800022f8:	e84a                	sd	s2,16(sp)
    800022fa:	e44e                	sd	s3,8(sp)
    800022fc:	e052                	sd	s4,0(sp)
    800022fe:	1800                	addi	s0,sp,48
    80002300:	8a2a                	mv	s4,a0
    80002302:	84ae                	mv	s1,a1
    80002304:	89b2                	mv	s3,a2
    80002306:	8936                	mv	s2,a3
  struct proc *p = myproc();
    80002308:	e00ff0ef          	jal	80001908 <myproc>
  if (user_src) {
    8000230c:	c085                	beqz	s1,8000232c <either_copyin+0x3c>
    return copyin(p->pagetable, p->sz, dst, src, len);
    8000230e:	874a                	mv	a4,s2
    80002310:	86ce                	mv	a3,s3
    80002312:	8652                	mv	a2,s4
    80002314:	652c                	ld	a1,72(a0)
    80002316:	6928                	ld	a0,80(a0)
    80002318:	af0ff0ef          	jal	80001608 <copyin>
  } else {
    memmove(dst, (char *)src, len);
    return 0;
  }
}
    8000231c:	70a2                	ld	ra,40(sp)
    8000231e:	7402                	ld	s0,32(sp)
    80002320:	64e2                	ld	s1,24(sp)
    80002322:	6942                	ld	s2,16(sp)
    80002324:	69a2                	ld	s3,8(sp)
    80002326:	6a02                	ld	s4,0(sp)
    80002328:	6145                	addi	sp,sp,48
    8000232a:	8082                	ret
    memmove(dst, (char *)src, len);
    8000232c:	0009061b          	sext.w	a2,s2
    80002330:	85ce                	mv	a1,s3
    80002332:	8552                	mv	a0,s4
    80002334:	9d5fe0ef          	jal	80000d08 <memmove>
    return 0;
    80002338:	8526                	mv	a0,s1
    8000233a:	b7cd                	j	8000231c <either_copyin+0x2c>

000000008000233c <procdump>:
// Print a process listing to console.  For debugging.
// Runs when user types ^P on console.
// No lock to avoid wedging a stuck machine further.
void
procdump(void)
{
    8000233c:	715d                	addi	sp,sp,-80
    8000233e:	e486                	sd	ra,72(sp)
    80002340:	e0a2                	sd	s0,64(sp)
    80002342:	fc26                	sd	s1,56(sp)
    80002344:	f84a                	sd	s2,48(sp)
    80002346:	f44e                	sd	s3,40(sp)
    80002348:	f052                	sd	s4,32(sp)
    8000234a:	ec56                	sd	s5,24(sp)
    8000234c:	e85a                	sd	s6,16(sp)
    8000234e:	e45e                	sd	s7,8(sp)
    80002350:	0880                	addi	s0,sp,80
    // clang-format on
  };
  struct proc *p;
  char *state;

  printk("\n");
    80002352:	00005517          	auipc	a0,0x5
    80002356:	d2650513          	addi	a0,a0,-730 # 80007078 <etext+0x78>
    8000235a:	9b0fe0ef          	jal	8000050a <printk>
  for (p = proc; p < &proc[NPROC]; p++) {
    8000235e:	00010497          	auipc	s1,0x10
    80002362:	66a48493          	addi	s1,s1,1642 # 800129c8 <proc+0x158>
    80002366:	00016917          	auipc	s2,0x16
    8000236a:	06290913          	addi	s2,s2,98 # 800183c8 <bcache+0x140>
    if (p->state == UNUSED)
      continue;
    if (p->state >= 0 && p->state < NELEM(states) && states[p->state])
    8000236e:	4b15                	li	s6,5
      state = states[p->state];
    else
      state = "???";
    80002370:	00005997          	auipc	s3,0x5
    80002374:	eb098993          	addi	s3,s3,-336 # 80007220 <etext+0x220>
    printk("%d %s %s", p->pid, state, p->name);
    80002378:	00005a97          	auipc	s5,0x5
    8000237c:	eb0a8a93          	addi	s5,s5,-336 # 80007228 <etext+0x228>
    printk("\n");
    80002380:	00005a17          	auipc	s4,0x5
    80002384:	cf8a0a13          	addi	s4,s4,-776 # 80007078 <etext+0x78>
    if (p->state >= 0 && p->state < NELEM(states) && states[p->state])
    80002388:	00005b97          	auipc	s7,0x5
    8000238c:	3d8b8b93          	addi	s7,s7,984 # 80007760 <states.0>
    80002390:	a829                	j	800023aa <procdump+0x6e>
    printk("%d %s %s", p->pid, state, p->name);
    80002392:	ed86a583          	lw	a1,-296(a3)
    80002396:	8556                	mv	a0,s5
    80002398:	972fe0ef          	jal	8000050a <printk>
    printk("\n");
    8000239c:	8552                	mv	a0,s4
    8000239e:	96cfe0ef          	jal	8000050a <printk>
  for (p = proc; p < &proc[NPROC]; p++) {
    800023a2:	16848493          	addi	s1,s1,360
    800023a6:	03248263          	beq	s1,s2,800023ca <procdump+0x8e>
    if (p->state == UNUSED)
    800023aa:	86a6                	mv	a3,s1
    800023ac:	ec04a783          	lw	a5,-320(s1)
    800023b0:	dbed                	beqz	a5,800023a2 <procdump+0x66>
      state = "???";
    800023b2:	864e                	mv	a2,s3
    if (p->state >= 0 && p->state < NELEM(states) && states[p->state])
    800023b4:	fcfb6fe3          	bltu	s6,a5,80002392 <procdump+0x56>
    800023b8:	02079713          	slli	a4,a5,0x20
    800023bc:	01d75793          	srli	a5,a4,0x1d
    800023c0:	97de                	add	a5,a5,s7
    800023c2:	6390                	ld	a2,0(a5)
    800023c4:	f679                	bnez	a2,80002392 <procdump+0x56>
      state = "???";
    800023c6:	864e                	mv	a2,s3
    800023c8:	b7e9                	j	80002392 <procdump+0x56>
  }
}
    800023ca:	60a6                	ld	ra,72(sp)
    800023cc:	6406                	ld	s0,64(sp)
    800023ce:	74e2                	ld	s1,56(sp)
    800023d0:	7942                	ld	s2,48(sp)
    800023d2:	79a2                	ld	s3,40(sp)
    800023d4:	7a02                	ld	s4,32(sp)
    800023d6:	6ae2                	ld	s5,24(sp)
    800023d8:	6b42                	ld	s6,16(sp)
    800023da:	6ba2                	ld	s7,8(sp)
    800023dc:	6161                	addi	sp,sp,80
    800023de:	8082                	ret

00000000800023e0 <swtch>:
# Save current registers in old. Load from new.	


.globl swtch
swtch:
        sd ra, 0(a0)
    800023e0:	00153023          	sd	ra,0(a0)
        sd sp, 8(a0)
    800023e4:	00253423          	sd	sp,8(a0)
        sd s0, 16(a0)
    800023e8:	e900                	sd	s0,16(a0)
        sd s1, 24(a0)
    800023ea:	ed04                	sd	s1,24(a0)
        sd s2, 32(a0)
    800023ec:	03253023          	sd	s2,32(a0)
        sd s3, 40(a0)
    800023f0:	03353423          	sd	s3,40(a0)
        sd s4, 48(a0)
    800023f4:	03453823          	sd	s4,48(a0)
        sd s5, 56(a0)
    800023f8:	03553c23          	sd	s5,56(a0)
        sd s6, 64(a0)
    800023fc:	05653023          	sd	s6,64(a0)
        sd s7, 72(a0)
    80002400:	05753423          	sd	s7,72(a0)
        sd s8, 80(a0)
    80002404:	05853823          	sd	s8,80(a0)
        sd s9, 88(a0)
    80002408:	05953c23          	sd	s9,88(a0)
        sd s10, 96(a0)
    8000240c:	07a53023          	sd	s10,96(a0)
        sd s11, 104(a0)
    80002410:	07b53423          	sd	s11,104(a0)

        ld ra, 0(a1)
    80002414:	0005b083          	ld	ra,0(a1)
        ld sp, 8(a1)
    80002418:	0085b103          	ld	sp,8(a1)
        ld s0, 16(a1)
    8000241c:	6980                	ld	s0,16(a1)
        ld s1, 24(a1)
    8000241e:	6d84                	ld	s1,24(a1)
        ld s2, 32(a1)
    80002420:	0205b903          	ld	s2,32(a1)
        ld s3, 40(a1)
    80002424:	0285b983          	ld	s3,40(a1)
        ld s4, 48(a1)
    80002428:	0305ba03          	ld	s4,48(a1)
        ld s5, 56(a1)
    8000242c:	0385ba83          	ld	s5,56(a1)
        ld s6, 64(a1)
    80002430:	0405bb03          	ld	s6,64(a1)
        ld s7, 72(a1)
    80002434:	0485bb83          	ld	s7,72(a1)
        ld s8, 80(a1)
    80002438:	0505bc03          	ld	s8,80(a1)
        ld s9, 88(a1)
    8000243c:	0585bc83          	ld	s9,88(a1)
        ld s10, 96(a1)
    80002440:	0605bd03          	ld	s10,96(a1)
        ld s11, 104(a1)
    80002444:	0685bd83          	ld	s11,104(a1)
        
        ret
    80002448:	8082                	ret

000000008000244a <trapinit>:

extern int devintr();

void
trapinit(void)
{
    8000244a:	1141                	addi	sp,sp,-16
    8000244c:	e406                	sd	ra,8(sp)
    8000244e:	e022                	sd	s0,0(sp)
    80002450:	0800                	addi	s0,sp,16
  initlock(&tickslock, "time");
    80002452:	00005597          	auipc	a1,0x5
    80002456:	e1658593          	addi	a1,a1,-490 # 80007268 <etext+0x268>
    8000245a:	00016517          	auipc	a0,0x16
    8000245e:	e1650513          	addi	a0,a0,-490 # 80018270 <tickslock>
    80002462:	f06fe0ef          	jal	80000b68 <initlock>
}
    80002466:	60a2                	ld	ra,8(sp)
    80002468:	6402                	ld	s0,0(sp)
    8000246a:	0141                	addi	sp,sp,16
    8000246c:	8082                	ret

000000008000246e <trapinithart>:

// set up to take exceptions and traps while in the kernel.
void
trapinithart(void)
{
    8000246e:	1141                	addi	sp,sp,-16
    80002470:	e406                	sd	ra,8(sp)
    80002472:	e022                	sd	s0,0(sp)
    80002474:	0800                	addi	s0,sp,16
  asm volatile("csrw stvec, %0" : : "r"(x));
    80002476:	00003797          	auipc	a5,0x3
    8000247a:	1ba78793          	addi	a5,a5,442 # 80005630 <kernelvec>
    8000247e:	10579073          	csrw	stvec,a5
  w_stvec((uint64)kernelvec);
}
    80002482:	60a2                	ld	ra,8(sp)
    80002484:	6402                	ld	s0,0(sp)
    80002486:	0141                	addi	sp,sp,16
    80002488:	8082                	ret

000000008000248a <prepare_return>:
//
// set up trapframe and control registers for a return to user space
//
void
prepare_return(void)
{
    8000248a:	1141                	addi	sp,sp,-16
    8000248c:	e406                	sd	ra,8(sp)
    8000248e:	e022                	sd	s0,0(sp)
    80002490:	0800                	addi	s0,sp,16
  struct proc *p = myproc();
    80002492:	c76ff0ef          	jal	80001908 <myproc>
  __asm__ __volatile__("csrc sstatus, %0" ::"rK"(x) : "memory");
    80002496:	10017073          	csrci	sstatus,2
  // kerneltrap() to usertrap(). because a trap from kernel
  // code to usertrap would be a disaster, turn off interrupts.
  intr_off();

  // send syscalls, interrupts, and exceptions to uservec in trampoline.S
  uint64 trampoline_uservec = TRAMPOLINE + (uservec - trampoline);
    8000249a:	04000737          	lui	a4,0x4000
    8000249e:	177d                	addi	a4,a4,-1 # 3ffffff <_entry-0x7c000001>
    800024a0:	0732                	slli	a4,a4,0xc
    800024a2:	00004797          	auipc	a5,0x4
    800024a6:	b5e78793          	addi	a5,a5,-1186 # 80006000 <_trampoline>
    800024aa:	00004697          	auipc	a3,0x4
    800024ae:	b5668693          	addi	a3,a3,-1194 # 80006000 <_trampoline>
    800024b2:	8f95                	sub	a5,a5,a3
    800024b4:	97ba                	add	a5,a5,a4
  asm volatile("csrw stvec, %0" : : "r"(x));
    800024b6:	10579073          	csrw	stvec,a5
  w_stvec(trampoline_uservec);

  // set up trapframe values that uservec will need when
  // the process next traps into the kernel.
  p->trapframe->kernel_satp = r_satp();         // kernel page table
    800024ba:	6d3c                	ld	a5,88(a0)
  asm volatile("csrr %0, satp" : "=r"(x));
    800024bc:	18002773          	csrr	a4,satp
    800024c0:	e398                	sd	a4,0(a5)
  p->trapframe->kernel_sp = p->kstack + PGSIZE; // process's kernel stack
    800024c2:	6d38                	ld	a4,88(a0)
    800024c4:	613c                	ld	a5,64(a0)
    800024c6:	6685                	lui	a3,0x1
    800024c8:	97b6                	add	a5,a5,a3
    800024ca:	e71c                	sd	a5,8(a4)
  p->trapframe->kernel_trap = (uint64)usertrap;
    800024cc:	6d3c                	ld	a5,88(a0)
    800024ce:	00000717          	auipc	a4,0x0
    800024d2:	0fc70713          	addi	a4,a4,252 # 800025ca <usertrap>
    800024d6:	eb98                	sd	a4,16(a5)
  p->trapframe->kernel_hartid = r_tp(); // hartid for cpuid()
    800024d8:	6d3c                	ld	a5,88(a0)
  asm volatile("mv %0, tp" : "=r"(x));
    800024da:	8712                	mv	a4,tp
    800024dc:	f398                	sd	a4,32(a5)
  asm volatile("csrr %0, sstatus" : "=r"(x));
    800024de:	100027f3          	csrr	a5,sstatus
  // set up the registers that trampoline.S's sret will use
  // to get to user space.

  // set S Previous Privilege mode to User.
  unsigned long x = r_sstatus();
  x &= ~SSTATUS_SPP; // clear SPP to 0 for user mode
    800024e2:	eff7f793          	andi	a5,a5,-257
  x |= SSTATUS_SPIE; // enable interrupts in user mode
    800024e6:	0207e793          	ori	a5,a5,32
  asm volatile("csrw sstatus, %0" : : "r"(x));
    800024ea:	10079073          	csrw	sstatus,a5
  w_sstatus(x);

  // set S Exception Program Counter to the saved user pc.
  w_sepc(p->trapframe->epc);
    800024ee:	6d3c                	ld	a5,88(a0)
  asm volatile("csrw sepc, %0" : : "r"(x));
    800024f0:	6f9c                	ld	a5,24(a5)
    800024f2:	14179073          	csrw	sepc,a5
}
    800024f6:	60a2                	ld	ra,8(sp)
    800024f8:	6402                	ld	s0,0(sp)
    800024fa:	0141                	addi	sp,sp,16
    800024fc:	8082                	ret

00000000800024fe <clockintr>:
  w_sstatus(sstatus);
}

void
clockintr()
{
    800024fe:	1141                	addi	sp,sp,-16
    80002500:	e406                	sd	ra,8(sp)
    80002502:	e022                	sd	s0,0(sp)
    80002504:	0800                	addi	s0,sp,16
  if (cpuid() == 0) {
    80002506:	bceff0ef          	jal	800018d4 <cpuid>
    8000250a:	cd11                	beqz	a0,80002526 <clockintr+0x28>
  asm volatile("csrr %0, time" : "=r"(x));
    8000250c:	c01027f3          	rdtime	a5
  }

  // ask for the next timer interrupt. this also clears
  // the interrupt request. 1000000 is about a tenth
  // of a second.
  w_stimecmp(r_time() + 1000000);
    80002510:	000f4737          	lui	a4,0xf4
    80002514:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    80002518:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r"(x));
    8000251a:	14d79073          	csrw	stimecmp,a5
}
    8000251e:	60a2                	ld	ra,8(sp)
    80002520:	6402                	ld	s0,0(sp)
    80002522:	0141                	addi	sp,sp,16
    80002524:	8082                	ret
    acquire(&tickslock);
    80002526:	00016517          	auipc	a0,0x16
    8000252a:	d4a50513          	addi	a0,a0,-694 # 80018270 <tickslock>
    8000252e:	ebafe0ef          	jal	80000be8 <acquire>
    ticks++;
    80002532:	00008717          	auipc	a4,0x8
    80002536:	dee70713          	addi	a4,a4,-530 # 8000a320 <ticks>
    8000253a:	431c                	lw	a5,0(a4)
    8000253c:	2785                	addiw	a5,a5,1
    8000253e:	c31c                	sw	a5,0(a4)
    wakeup(&ticks);
    80002540:	853a                	mv	a0,a4
    80002542:	a3dff0ef          	jal	80001f7e <wakeup>
    release(&tickslock);
    80002546:	00016517          	auipc	a0,0x16
    8000254a:	d2a50513          	addi	a0,a0,-726 # 80018270 <tickslock>
    8000254e:	f22fe0ef          	jal	80000c70 <release>
    80002552:	bf6d                	j	8000250c <clockintr+0xe>

0000000080002554 <devintr>:
// returns 2 if timer interrupt,
// 1 if other device,
// 0 if not recognized.
int
devintr()
{
    80002554:	1101                	addi	sp,sp,-32
    80002556:	ec06                	sd	ra,24(sp)
    80002558:	e822                	sd	s0,16(sp)
    8000255a:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, scause" : "=r"(x));
    8000255c:	14202773          	csrr	a4,scause
  uint64 scause = r_scause();

  if (scause == 0x8000000000000009L) {
    80002560:	57fd                	li	a5,-1
    80002562:	17fe                	slli	a5,a5,0x3f
    80002564:	07a5                	addi	a5,a5,9
    80002566:	00f70c63          	beq	a4,a5,8000257e <devintr+0x2a>
    // now allowed to interrupt again.
    if (irq)
      plic_complete(irq);

    return 1;
  } else if (scause == 0x8000000000000005L) {
    8000256a:	57fd                	li	a5,-1
    8000256c:	17fe                	slli	a5,a5,0x3f
    8000256e:	0795                	addi	a5,a5,5
    // timer interrupt.
    clockintr();
    return 2;
  } else {
    return 0;
    80002570:	4501                	li	a0,0
  } else if (scause == 0x8000000000000005L) {
    80002572:	04f70863          	beq	a4,a5,800025c2 <devintr+0x6e>
  }
}
    80002576:	60e2                	ld	ra,24(sp)
    80002578:	6442                	ld	s0,16(sp)
    8000257a:	6105                	addi	sp,sp,32
    8000257c:	8082                	ret
    8000257e:	e426                	sd	s1,8(sp)
    int irq = plic_claim();
    80002580:	15e030ef          	jal	800056de <plic_claim>
    80002584:	872a                	mv	a4,a0
    80002586:	84aa                	mv	s1,a0
    if (irq == UART0_IRQ) {
    80002588:	47a9                	li	a5,10
    8000258a:	00f50963          	beq	a0,a5,8000259c <devintr+0x48>
    } else if (irq == VIRTIO0_IRQ) {
    8000258e:	4785                	li	a5,1
    80002590:	00f50963          	beq	a0,a5,800025a2 <devintr+0x4e>
    return 1;
    80002594:	4505                	li	a0,1
    } else if (irq) {
    80002596:	eb09                	bnez	a4,800025a8 <devintr+0x54>
    80002598:	64a2                	ld	s1,8(sp)
    8000259a:	bff1                	j	80002576 <devintr+0x22>
      uartintr();
    8000259c:	c32fe0ef          	jal	800009ce <uartintr>
    if (irq)
    800025a0:	a819                	j	800025b6 <devintr+0x62>
      virtio_disk_intr();
    800025a2:	5f8030ef          	jal	80005b9a <virtio_disk_intr>
    if (irq)
    800025a6:	a801                	j	800025b6 <devintr+0x62>
      printk("unexpected interrupt irq=%d\n", irq);
    800025a8:	85ba                	mv	a1,a4
    800025aa:	00005517          	auipc	a0,0x5
    800025ae:	cc650513          	addi	a0,a0,-826 # 80007270 <etext+0x270>
    800025b2:	f59fd0ef          	jal	8000050a <printk>
      plic_complete(irq);
    800025b6:	8526                	mv	a0,s1
    800025b8:	148030ef          	jal	80005700 <plic_complete>
    return 1;
    800025bc:	4505                	li	a0,1
    800025be:	64a2                	ld	s1,8(sp)
    800025c0:	bf5d                	j	80002576 <devintr+0x22>
    clockintr();
    800025c2:	f3dff0ef          	jal	800024fe <clockintr>
    return 2;
    800025c6:	4509                	li	a0,2
    800025c8:	b77d                	j	80002576 <devintr+0x22>

00000000800025ca <usertrap>:
{
    800025ca:	1101                	addi	sp,sp,-32
    800025cc:	ec06                	sd	ra,24(sp)
    800025ce:	e822                	sd	s0,16(sp)
    800025d0:	e426                	sd	s1,8(sp)
    800025d2:	e04a                	sd	s2,0(sp)
    800025d4:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r"(x));
    800025d6:	100027f3          	csrr	a5,sstatus
  if ((r_sstatus() & SSTATUS_SPP) != 0)
    800025da:	1007f793          	andi	a5,a5,256
    800025de:	eba5                	bnez	a5,8000264e <usertrap+0x84>
  asm volatile("csrw stvec, %0" : : "r"(x));
    800025e0:	00003797          	auipc	a5,0x3
    800025e4:	05078793          	addi	a5,a5,80 # 80005630 <kernelvec>
    800025e8:	10579073          	csrw	stvec,a5
  struct proc *p = myproc();
    800025ec:	b1cff0ef          	jal	80001908 <myproc>
    800025f0:	84aa                	mv	s1,a0
  p->trapframe->epc = r_sepc();
    800025f2:	6d3c                	ld	a5,88(a0)
  asm volatile("csrr %0, sepc" : "=r"(x));
    800025f4:	14102773          	csrr	a4,sepc
    800025f8:	ef98                	sd	a4,24(a5)
  asm volatile("csrr %0, scause" : "=r"(x));
    800025fa:	14202773          	csrr	a4,scause
  if (r_scause() == 8) {
    800025fe:	47a1                	li	a5,8
    80002600:	04f70d63          	beq	a4,a5,8000265a <usertrap+0x90>
  } else if ((which_dev = devintr()) != 0) {
    80002604:	f51ff0ef          	jal	80002554 <devintr>
    80002608:	892a                	mv	s2,a0
    8000260a:	e54d                	bnez	a0,800026b4 <usertrap+0xea>
    8000260c:	14202773          	csrr	a4,scause
  } else if ((r_scause() == 15 || r_scause() == 13) &&
    80002610:	47bd                	li	a5,15
    80002612:	08f70463          	beq	a4,a5,8000269a <usertrap+0xd0>
    80002616:	14202773          	csrr	a4,scause
    8000261a:	47b5                	li	a5,13
    8000261c:	06f70f63          	beq	a4,a5,8000269a <usertrap+0xd0>
    80002620:	142025f3          	csrr	a1,scause
    printk("usertrap(): unexpected scause 0x%lx pid=%d\n", r_scause(), p->pid);
    80002624:	5890                	lw	a2,48(s1)
    80002626:	00005517          	auipc	a0,0x5
    8000262a:	c8a50513          	addi	a0,a0,-886 # 800072b0 <etext+0x2b0>
    8000262e:	eddfd0ef          	jal	8000050a <printk>
  asm volatile("csrr %0, sepc" : "=r"(x));
    80002632:	141025f3          	csrr	a1,sepc
  asm volatile("csrr %0, stval" : "=r"(x));
    80002636:	14302673          	csrr	a2,stval
    printk("            sepc=0x%lx stval=0x%lx\n", r_sepc(), r_stval());
    8000263a:	00005517          	auipc	a0,0x5
    8000263e:	ca650513          	addi	a0,a0,-858 # 800072e0 <etext+0x2e0>
    80002642:	ec9fd0ef          	jal	8000050a <printk>
    setkilled(p);
    80002646:	8526                	mv	a0,s1
    80002648:	b05ff0ef          	jal	8000214c <setkilled>
    8000264c:	a015                	j	80002670 <usertrap+0xa6>
    panic("usertrap: not from user mode");
    8000264e:	00005517          	auipc	a0,0x5
    80002652:	c4250513          	addi	a0,a0,-958 # 80007290 <etext+0x290>
    80002656:	9defe0ef          	jal	80000834 <panic>
    if (killed(p))
    8000265a:	b17ff0ef          	jal	80002170 <killed>
    8000265e:	e915                	bnez	a0,80002692 <usertrap+0xc8>
    p->trapframe->epc += 4;
    80002660:	6cb8                	ld	a4,88(s1)
    80002662:	6f1c                	ld	a5,24(a4)
    80002664:	0791                	addi	a5,a5,4
    80002666:	ef1c                	sd	a5,24(a4)
  __asm__ __volatile__("csrs sstatus, %0" ::"rK"(x) : "memory");
    80002668:	10016073          	csrsi	sstatus,2
    syscall();
    8000266c:	244000ef          	jal	800028b0 <syscall>
  if (killed(p))
    80002670:	8526                	mv	a0,s1
    80002672:	affff0ef          	jal	80002170 <killed>
    80002676:	e521                	bnez	a0,800026be <usertrap+0xf4>
  prepare_return();
    80002678:	e13ff0ef          	jal	8000248a <prepare_return>
  uint64 satp = MAKE_SATP(p->pagetable);
    8000267c:	68a8                	ld	a0,80(s1)
    8000267e:	8131                	srli	a0,a0,0xc
    80002680:	57fd                	li	a5,-1
    80002682:	17fe                	slli	a5,a5,0x3f
    80002684:	8d5d                	or	a0,a0,a5
}
    80002686:	60e2                	ld	ra,24(sp)
    80002688:	6442                	ld	s0,16(sp)
    8000268a:	64a2                	ld	s1,8(sp)
    8000268c:	6902                	ld	s2,0(sp)
    8000268e:	6105                	addi	sp,sp,32
    80002690:	8082                	ret
      kexit(-1);
    80002692:	557d                	li	a0,-1
    80002694:	9a7ff0ef          	jal	8000203a <kexit>
    80002698:	b7e1                	j	80002660 <usertrap+0x96>
  asm volatile("csrr %0, stval" : "=r"(x));
    8000269a:	14302673          	csrr	a2,stval
  asm volatile("csrr %0, scause" : "=r"(x));
    8000269e:	142026f3          	csrr	a3,scause
             vmfault(p->pagetable, p->sz, r_stval(),
    800026a2:	16cd                	addi	a3,a3,-13 # ff3 <_entry-0x7ffff00d>
    800026a4:	0016b693          	seqz	a3,a3
    800026a8:	64ac                	ld	a1,72(s1)
    800026aa:	68a8                	ld	a0,80(s1)
    800026ac:	e1bfe0ef          	jal	800014c6 <vmfault>
  } else if ((r_scause() == 15 || r_scause() == 13) &&
    800026b0:	f161                	bnez	a0,80002670 <usertrap+0xa6>
    800026b2:	b7bd                	j	80002620 <usertrap+0x56>
  if (killed(p))
    800026b4:	8526                	mv	a0,s1
    800026b6:	abbff0ef          	jal	80002170 <killed>
    800026ba:	c511                	beqz	a0,800026c6 <usertrap+0xfc>
    800026bc:	a011                	j	800026c0 <usertrap+0xf6>
    800026be:	4901                	li	s2,0
    kexit(-1);
    800026c0:	557d                	li	a0,-1
    800026c2:	979ff0ef          	jal	8000203a <kexit>
  if (which_dev == 2)
    800026c6:	4789                	li	a5,2
    800026c8:	faf918e3          	bne	s2,a5,80002678 <usertrap+0xae>
    yield();
    800026cc:	81bff0ef          	jal	80001ee6 <yield>
    800026d0:	b765                	j	80002678 <usertrap+0xae>

00000000800026d2 <kerneltrap>:
{
    800026d2:	7179                	addi	sp,sp,-48
    800026d4:	f406                	sd	ra,40(sp)
    800026d6:	f022                	sd	s0,32(sp)
    800026d8:	ec26                	sd	s1,24(sp)
    800026da:	e84a                	sd	s2,16(sp)
    800026dc:	e44e                	sd	s3,8(sp)
    800026de:	1800                	addi	s0,sp,48
  asm volatile("csrr %0, sepc" : "=r"(x));
    800026e0:	14102973          	csrr	s2,sepc
  asm volatile("csrr %0, sstatus" : "=r"(x));
    800026e4:	100024f3          	csrr	s1,sstatus
  asm volatile("csrr %0, scause" : "=r"(x));
    800026e8:	142027f3          	csrr	a5,scause
    800026ec:	89be                	mv	s3,a5
  if ((sstatus & SSTATUS_SPP) == 0)
    800026ee:	1004f793          	andi	a5,s1,256
    800026f2:	c795                	beqz	a5,8000271e <kerneltrap+0x4c>
  asm volatile("csrr %0, sstatus" : "=r"(x));
    800026f4:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    800026f8:	8b89                	andi	a5,a5,2
  if (intr_get() != 0)
    800026fa:	eb85                	bnez	a5,8000272a <kerneltrap+0x58>
  if ((which_dev = devintr()) == 0) {
    800026fc:	e59ff0ef          	jal	80002554 <devintr>
    80002700:	c91d                	beqz	a0,80002736 <kerneltrap+0x64>
  if (which_dev == 2 && myproc() != 0)
    80002702:	4789                	li	a5,2
    80002704:	04f50a63          	beq	a0,a5,80002758 <kerneltrap+0x86>
  asm volatile("csrw sepc, %0" : : "r"(x));
    80002708:	14191073          	csrw	sepc,s2
  asm volatile("csrw sstatus, %0" : : "r"(x));
    8000270c:	10049073          	csrw	sstatus,s1
}
    80002710:	70a2                	ld	ra,40(sp)
    80002712:	7402                	ld	s0,32(sp)
    80002714:	64e2                	ld	s1,24(sp)
    80002716:	6942                	ld	s2,16(sp)
    80002718:	69a2                	ld	s3,8(sp)
    8000271a:	6145                	addi	sp,sp,48
    8000271c:	8082                	ret
    panic("kerneltrap: not from supervisor mode");
    8000271e:	00005517          	auipc	a0,0x5
    80002722:	bea50513          	addi	a0,a0,-1046 # 80007308 <etext+0x308>
    80002726:	90efe0ef          	jal	80000834 <panic>
    panic("kerneltrap: interrupts enabled");
    8000272a:	00005517          	auipc	a0,0x5
    8000272e:	c0650513          	addi	a0,a0,-1018 # 80007330 <etext+0x330>
    80002732:	902fe0ef          	jal	80000834 <panic>
  asm volatile("csrr %0, sepc" : "=r"(x));
    80002736:	14102673          	csrr	a2,sepc
  asm volatile("csrr %0, stval" : "=r"(x));
    8000273a:	143026f3          	csrr	a3,stval
    printk("scause=0x%lx sepc=0x%lx stval=0x%lx\n", scause, r_sepc(),
    8000273e:	85ce                	mv	a1,s3
    80002740:	00005517          	auipc	a0,0x5
    80002744:	c1050513          	addi	a0,a0,-1008 # 80007350 <etext+0x350>
    80002748:	dc3fd0ef          	jal	8000050a <printk>
    panic("kerneltrap");
    8000274c:	00005517          	auipc	a0,0x5
    80002750:	c2c50513          	addi	a0,a0,-980 # 80007378 <etext+0x378>
    80002754:	8e0fe0ef          	jal	80000834 <panic>
  if (which_dev == 2 && myproc() != 0)
    80002758:	9b0ff0ef          	jal	80001908 <myproc>
    8000275c:	d555                	beqz	a0,80002708 <kerneltrap+0x36>
    yield();
    8000275e:	f88ff0ef          	jal	80001ee6 <yield>
    80002762:	b75d                	j	80002708 <kerneltrap+0x36>

0000000080002764 <argraw>:
  return strlen(buf);
}

static uint64
argraw(int n)
{
    80002764:	1101                	addi	sp,sp,-32
    80002766:	ec06                	sd	ra,24(sp)
    80002768:	e822                	sd	s0,16(sp)
    8000276a:	e426                	sd	s1,8(sp)
    8000276c:	1000                	addi	s0,sp,32
    8000276e:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    80002770:	998ff0ef          	jal	80001908 <myproc>
  switch (n) {
    80002774:	4795                	li	a5,5
    80002776:	0497e163          	bltu	a5,s1,800027b8 <argraw+0x54>
    8000277a:	048a                	slli	s1,s1,0x2
    8000277c:	00005717          	auipc	a4,0x5
    80002780:	01470713          	addi	a4,a4,20 # 80007790 <states.0+0x30>
    80002784:	94ba                	add	s1,s1,a4
    80002786:	409c                	lw	a5,0(s1)
    80002788:	97ba                	add	a5,a5,a4
    8000278a:	8782                	jr	a5
  case 0:
    return p->trapframe->a0;
    8000278c:	6d3c                	ld	a5,88(a0)
    8000278e:	7ba8                	ld	a0,112(a5)
  case 5:
    return p->trapframe->a5;
  }
  panic("argraw");
  return -1;
}
    80002790:	60e2                	ld	ra,24(sp)
    80002792:	6442                	ld	s0,16(sp)
    80002794:	64a2                	ld	s1,8(sp)
    80002796:	6105                	addi	sp,sp,32
    80002798:	8082                	ret
    return p->trapframe->a1;
    8000279a:	6d3c                	ld	a5,88(a0)
    8000279c:	7fa8                	ld	a0,120(a5)
    8000279e:	bfcd                	j	80002790 <argraw+0x2c>
    return p->trapframe->a2;
    800027a0:	6d3c                	ld	a5,88(a0)
    800027a2:	63c8                	ld	a0,128(a5)
    800027a4:	b7f5                	j	80002790 <argraw+0x2c>
    return p->trapframe->a3;
    800027a6:	6d3c                	ld	a5,88(a0)
    800027a8:	67c8                	ld	a0,136(a5)
    800027aa:	b7dd                	j	80002790 <argraw+0x2c>
    return p->trapframe->a4;
    800027ac:	6d3c                	ld	a5,88(a0)
    800027ae:	6bc8                	ld	a0,144(a5)
    800027b0:	b7c5                	j	80002790 <argraw+0x2c>
    return p->trapframe->a5;
    800027b2:	6d3c                	ld	a5,88(a0)
    800027b4:	6fc8                	ld	a0,152(a5)
    800027b6:	bfe9                	j	80002790 <argraw+0x2c>
  panic("argraw");
    800027b8:	00005517          	auipc	a0,0x5
    800027bc:	bd050513          	addi	a0,a0,-1072 # 80007388 <etext+0x388>
    800027c0:	874fe0ef          	jal	80000834 <panic>

00000000800027c4 <fetchaddr>:
{
    800027c4:	1101                	addi	sp,sp,-32
    800027c6:	ec06                	sd	ra,24(sp)
    800027c8:	e822                	sd	s0,16(sp)
    800027ca:	e426                	sd	s1,8(sp)
    800027cc:	e04a                	sd	s2,0(sp)
    800027ce:	1000                	addi	s0,sp,32
    800027d0:	84aa                	mv	s1,a0
    800027d2:	892e                	mv	s2,a1
  struct proc *p = myproc();
    800027d4:	934ff0ef          	jal	80001908 <myproc>
  if (addr >= p->sz ||
    800027d8:	652c                	ld	a1,72(a0)
    800027da:	02b4f663          	bgeu	s1,a1,80002806 <fetchaddr+0x42>
      addr + sizeof(uint64) > p->sz) // both tests needed, in case of overflow
    800027de:	00848793          	addi	a5,s1,8
  if (addr >= p->sz ||
    800027e2:	02f5e463          	bltu	a1,a5,8000280a <fetchaddr+0x46>
  if (copyin(p->pagetable, p->sz, (char *)ip, addr, sizeof(*ip)) != 0)
    800027e6:	4721                	li	a4,8
    800027e8:	86a6                	mv	a3,s1
    800027ea:	864a                	mv	a2,s2
    800027ec:	6928                	ld	a0,80(a0)
    800027ee:	e1bfe0ef          	jal	80001608 <copyin>
    800027f2:	00a03533          	snez	a0,a0
    800027f6:	40a0053b          	negw	a0,a0
}
    800027fa:	60e2                	ld	ra,24(sp)
    800027fc:	6442                	ld	s0,16(sp)
    800027fe:	64a2                	ld	s1,8(sp)
    80002800:	6902                	ld	s2,0(sp)
    80002802:	6105                	addi	sp,sp,32
    80002804:	8082                	ret
    return -1;
    80002806:	557d                	li	a0,-1
    80002808:	bfcd                	j	800027fa <fetchaddr+0x36>
    8000280a:	557d                	li	a0,-1
    8000280c:	b7fd                	j	800027fa <fetchaddr+0x36>

000000008000280e <fetchstr>:
{
    8000280e:	7179                	addi	sp,sp,-48
    80002810:	f406                	sd	ra,40(sp)
    80002812:	f022                	sd	s0,32(sp)
    80002814:	ec26                	sd	s1,24(sp)
    80002816:	e84a                	sd	s2,16(sp)
    80002818:	e44e                	sd	s3,8(sp)
    8000281a:	1800                	addi	s0,sp,48
    8000281c:	89aa                	mv	s3,a0
    8000281e:	84ae                	mv	s1,a1
    80002820:	8932                	mv	s2,a2
  struct proc *p = myproc();
    80002822:	8e6ff0ef          	jal	80001908 <myproc>
  if (copyinstr(p->pagetable, p->sz, buf, addr, max) < 0)
    80002826:	874a                	mv	a4,s2
    80002828:	86ce                	mv	a3,s3
    8000282a:	8626                	mv	a2,s1
    8000282c:	652c                	ld	a1,72(a0)
    8000282e:	6928                	ld	a0,80(a0)
    80002830:	e75fe0ef          	jal	800016a4 <copyinstr>
    80002834:	00054c63          	bltz	a0,8000284c <fetchstr+0x3e>
  return strlen(buf);
    80002838:	8526                	mv	a0,s1
    8000283a:	df8fe0ef          	jal	80000e32 <strlen>
}
    8000283e:	70a2                	ld	ra,40(sp)
    80002840:	7402                	ld	s0,32(sp)
    80002842:	64e2                	ld	s1,24(sp)
    80002844:	6942                	ld	s2,16(sp)
    80002846:	69a2                	ld	s3,8(sp)
    80002848:	6145                	addi	sp,sp,48
    8000284a:	8082                	ret
    return -1;
    8000284c:	557d                	li	a0,-1
    8000284e:	bfc5                	j	8000283e <fetchstr+0x30>

0000000080002850 <argint>:

// Fetch the nth 32-bit system call argument.
void
argint(int n, int *ip)
{
    80002850:	1101                	addi	sp,sp,-32
    80002852:	ec06                	sd	ra,24(sp)
    80002854:	e822                	sd	s0,16(sp)
    80002856:	e426                	sd	s1,8(sp)
    80002858:	1000                	addi	s0,sp,32
    8000285a:	84ae                	mv	s1,a1
  *ip = argraw(n);
    8000285c:	f09ff0ef          	jal	80002764 <argraw>
    80002860:	c088                	sw	a0,0(s1)
}
    80002862:	60e2                	ld	ra,24(sp)
    80002864:	6442                	ld	s0,16(sp)
    80002866:	64a2                	ld	s1,8(sp)
    80002868:	6105                	addi	sp,sp,32
    8000286a:	8082                	ret

000000008000286c <argaddr>:
// Retrieve an argument as a pointer.
// Doesn't check for legality, since
// copyin/copyout will do that.
void
argaddr(int n, uint64 *ip)
{
    8000286c:	1101                	addi	sp,sp,-32
    8000286e:	ec06                	sd	ra,24(sp)
    80002870:	e822                	sd	s0,16(sp)
    80002872:	e426                	sd	s1,8(sp)
    80002874:	1000                	addi	s0,sp,32
    80002876:	84ae                	mv	s1,a1
  *ip = argraw(n);
    80002878:	eedff0ef          	jal	80002764 <argraw>
    8000287c:	e088                	sd	a0,0(s1)
}
    8000287e:	60e2                	ld	ra,24(sp)
    80002880:	6442                	ld	s0,16(sp)
    80002882:	64a2                	ld	s1,8(sp)
    80002884:	6105                	addi	sp,sp,32
    80002886:	8082                	ret

0000000080002888 <argstr>:
// Fetch the nth word-sized system call argument as a null-terminated string.
// Copies into buf, at most max.
// Returns string length if OK (not including nul), -1 if error.
int
argstr(int n, char *buf, int max)
{
    80002888:	1101                	addi	sp,sp,-32
    8000288a:	ec06                	sd	ra,24(sp)
    8000288c:	e822                	sd	s0,16(sp)
    8000288e:	e426                	sd	s1,8(sp)
    80002890:	e04a                	sd	s2,0(sp)
    80002892:	1000                	addi	s0,sp,32
    80002894:	892e                	mv	s2,a1
    80002896:	84b2                	mv	s1,a2
  *ip = argraw(n);
    80002898:	ecdff0ef          	jal	80002764 <argraw>
  uint64 addr;
  argaddr(n, &addr);
  return fetchstr(addr, buf, max);
    8000289c:	8626                	mv	a2,s1
    8000289e:	85ca                	mv	a1,s2
    800028a0:	f6fff0ef          	jal	8000280e <fetchstr>
}
    800028a4:	60e2                	ld	ra,24(sp)
    800028a6:	6442                	ld	s0,16(sp)
    800028a8:	64a2                	ld	s1,8(sp)
    800028aa:	6902                	ld	s2,0(sp)
    800028ac:	6105                	addi	sp,sp,32
    800028ae:	8082                	ret

00000000800028b0 <syscall>:
  // clang-format on
};

void
syscall(void)
{
    800028b0:	1101                	addi	sp,sp,-32
    800028b2:	ec06                	sd	ra,24(sp)
    800028b4:	e822                	sd	s0,16(sp)
    800028b6:	e426                	sd	s1,8(sp)
    800028b8:	e04a                	sd	s2,0(sp)
    800028ba:	1000                	addi	s0,sp,32
  int num;
  struct proc *p = myproc();
    800028bc:	84cff0ef          	jal	80001908 <myproc>
    800028c0:	84aa                	mv	s1,a0

  num = p->trapframe->a7;
    800028c2:	05853903          	ld	s2,88(a0)
    800028c6:	0a893783          	ld	a5,168(s2)
    800028ca:	0007869b          	sext.w	a3,a5
  if (num > 0 && num < NELEM(syscalls) && syscalls[num]) {
    800028ce:	37fd                	addiw	a5,a5,-1
    800028d0:	4759                	li	a4,22
    800028d2:	00f76f63          	bltu	a4,a5,800028f0 <syscall+0x40>
    800028d6:	00369713          	slli	a4,a3,0x3
    800028da:	00005797          	auipc	a5,0x5
    800028de:	ece78793          	addi	a5,a5,-306 # 800077a8 <syscalls>
    800028e2:	97ba                	add	a5,a5,a4
    800028e4:	639c                	ld	a5,0(a5)
    800028e6:	c789                	beqz	a5,800028f0 <syscall+0x40>
    // Use num to lookup the system call function for num, call it,
    // and store its return value in p->trapframe->a0
    p->trapframe->a0 = syscalls[num]();
    800028e8:	9782                	jalr	a5
    800028ea:	06a93823          	sd	a0,112(s2)
    800028ee:	a829                	j	80002908 <syscall+0x58>
  } else {
    printk("%d %s: unknown sys call %d\n", p->pid, p->name, num);
    800028f0:	15848613          	addi	a2,s1,344
    800028f4:	588c                	lw	a1,48(s1)
    800028f6:	00005517          	auipc	a0,0x5
    800028fa:	a9a50513          	addi	a0,a0,-1382 # 80007390 <etext+0x390>
    800028fe:	c0dfd0ef          	jal	8000050a <printk>
    p->trapframe->a0 = -1;
    80002902:	6cbc                	ld	a5,88(s1)
    80002904:	577d                	li	a4,-1
    80002906:	fbb8                	sd	a4,112(a5)
  }
}
    80002908:	60e2                	ld	ra,24(sp)
    8000290a:	6442                	ld	s0,16(sp)
    8000290c:	64a2                	ld	s1,8(sp)
    8000290e:	6902                	ld	s2,0(sp)
    80002910:	6105                	addi	sp,sp,32
    80002912:	8082                	ret

0000000080002914 <sys_exit>:
#include "proc.h"
#include "vm.h"

uint64
sys_exit(void)
{
    80002914:	1101                	addi	sp,sp,-32
    80002916:	ec06                	sd	ra,24(sp)
    80002918:	e822                	sd	s0,16(sp)
    8000291a:	1000                	addi	s0,sp,32
  int n;
  argint(0, &n);
    8000291c:	fec40593          	addi	a1,s0,-20
    80002920:	4501                	li	a0,0
    80002922:	f2fff0ef          	jal	80002850 <argint>
  kexit(n);
    80002926:	fec42503          	lw	a0,-20(s0)
    8000292a:	f10ff0ef          	jal	8000203a <kexit>
  return 0; // not reached
}
    8000292e:	4501                	li	a0,0
    80002930:	60e2                	ld	ra,24(sp)
    80002932:	6442                	ld	s0,16(sp)
    80002934:	6105                	addi	sp,sp,32
    80002936:	8082                	ret

0000000080002938 <sys_getpid>:

uint64
sys_getpid(void)
{
    80002938:	1141                	addi	sp,sp,-16
    8000293a:	e406                	sd	ra,8(sp)
    8000293c:	e022                	sd	s0,0(sp)
    8000293e:	0800                	addi	s0,sp,16
  return myproc()->pid;
    80002940:	fc9fe0ef          	jal	80001908 <myproc>
}
    80002944:	5908                	lw	a0,48(a0)
    80002946:	60a2                	ld	ra,8(sp)
    80002948:	6402                	ld	s0,0(sp)
    8000294a:	0141                	addi	sp,sp,16
    8000294c:	8082                	ret

000000008000294e <sys_fork>:

uint64
sys_fork(void)
{
    8000294e:	1141                	addi	sp,sp,-16
    80002950:	e406                	sd	ra,8(sp)
    80002952:	e022                	sd	s0,0(sp)
    80002954:	0800                	addi	s0,sp,16
  return kfork();
    80002956:	b12ff0ef          	jal	80001c68 <kfork>
}
    8000295a:	60a2                	ld	ra,8(sp)
    8000295c:	6402                	ld	s0,0(sp)
    8000295e:	0141                	addi	sp,sp,16
    80002960:	8082                	ret

0000000080002962 <sys_wait>:

uint64
sys_wait(void)
{
    80002962:	1101                	addi	sp,sp,-32
    80002964:	ec06                	sd	ra,24(sp)
    80002966:	e822                	sd	s0,16(sp)
    80002968:	1000                	addi	s0,sp,32
  uint64 p;
  argaddr(0, &p);
    8000296a:	fe840593          	addi	a1,s0,-24
    8000296e:	4501                	li	a0,0
    80002970:	efdff0ef          	jal	8000286c <argaddr>
  return kwait(p);
    80002974:	fe843503          	ld	a0,-24(s0)
    80002978:	823ff0ef          	jal	8000219a <kwait>
}
    8000297c:	60e2                	ld	ra,24(sp)
    8000297e:	6442                	ld	s0,16(sp)
    80002980:	6105                	addi	sp,sp,32
    80002982:	8082                	ret

0000000080002984 <sys_sbrk>:

uint64
sys_sbrk(void)
{
    80002984:	7179                	addi	sp,sp,-48
    80002986:	f406                	sd	ra,40(sp)
    80002988:	f022                	sd	s0,32(sp)
    8000298a:	ec26                	sd	s1,24(sp)
    8000298c:	1800                	addi	s0,sp,48
  uint64 addr;
  int t;
  int n;

  argint(0, &n);
    8000298e:	fd840593          	addi	a1,s0,-40
    80002992:	4501                	li	a0,0
    80002994:	ebdff0ef          	jal	80002850 <argint>
  argint(1, &t);
    80002998:	fdc40593          	addi	a1,s0,-36
    8000299c:	4505                	li	a0,1
    8000299e:	eb3ff0ef          	jal	80002850 <argint>
  addr = myproc()->sz;
    800029a2:	f67fe0ef          	jal	80001908 <myproc>
    800029a6:	6524                	ld	s1,72(a0)

  if (t == SBRK_EAGER || n < 0) {
    800029a8:	fdc42703          	lw	a4,-36(s0)
    800029ac:	4785                	li	a5,1
    800029ae:	02f70763          	beq	a4,a5,800029dc <sys_sbrk+0x58>
    800029b2:	fd842783          	lw	a5,-40(s0)
    800029b6:	0207c363          	bltz	a5,800029dc <sys_sbrk+0x58>
    }
  } else {
    // Lazily allocate memory for this process: increase its memory
    // size but don't allocate memory. If the processes uses the
    // memory, vmfault() will allocate it.
    if (addr + n < addr)
    800029ba:	97a6                	add	a5,a5,s1
      return -1;
    if (addr + n > TRAPFRAME)
    800029bc:	02000737          	lui	a4,0x2000
    800029c0:	177d                	addi	a4,a4,-1 # 1ffffff <_entry-0x7e000001>
    800029c2:	0736                	slli	a4,a4,0xd
    800029c4:	02f76a63          	bltu	a4,a5,800029f8 <sys_sbrk+0x74>
    800029c8:	0297e863          	bltu	a5,s1,800029f8 <sys_sbrk+0x74>
      return -1;
    myproc()->sz += n;
    800029cc:	f3dfe0ef          	jal	80001908 <myproc>
    800029d0:	fd842703          	lw	a4,-40(s0)
    800029d4:	653c                	ld	a5,72(a0)
    800029d6:	97ba                	add	a5,a5,a4
    800029d8:	e53c                	sd	a5,72(a0)
    800029da:	a039                	j	800029e8 <sys_sbrk+0x64>
    if (growproc(n) < 0) {
    800029dc:	fd842503          	lw	a0,-40(s0)
    800029e0:	a26ff0ef          	jal	80001c06 <growproc>
    800029e4:	00054863          	bltz	a0,800029f4 <sys_sbrk+0x70>
  }
  return addr;
}
    800029e8:	8526                	mv	a0,s1
    800029ea:	70a2                	ld	ra,40(sp)
    800029ec:	7402                	ld	s0,32(sp)
    800029ee:	64e2                	ld	s1,24(sp)
    800029f0:	6145                	addi	sp,sp,48
    800029f2:	8082                	ret
      return -1;
    800029f4:	54fd                	li	s1,-1
    800029f6:	bfcd                	j	800029e8 <sys_sbrk+0x64>
      return -1;
    800029f8:	54fd                	li	s1,-1
    800029fa:	b7fd                	j	800029e8 <sys_sbrk+0x64>

00000000800029fc <sys_pause>:

uint64
sys_pause(void)
{
    800029fc:	7139                	addi	sp,sp,-64
    800029fe:	fc06                	sd	ra,56(sp)
    80002a00:	f822                	sd	s0,48(sp)
    80002a02:	0080                	addi	s0,sp,64
  int n;
  uint ticks0;

  argint(0, &n);
    80002a04:	fcc40593          	addi	a1,s0,-52
    80002a08:	4501                	li	a0,0
    80002a0a:	e47ff0ef          	jal	80002850 <argint>
  if (n < 0)
    80002a0e:	fcc42783          	lw	a5,-52(s0)
    80002a12:	0807c063          	bltz	a5,80002a92 <sys_pause+0x96>
    n = 0;
  acquire(&tickslock);
    80002a16:	00016517          	auipc	a0,0x16
    80002a1a:	85a50513          	addi	a0,a0,-1958 # 80018270 <tickslock>
    80002a1e:	9cafe0ef          	jal	80000be8 <acquire>
  ticks0 = ticks;
  while (ticks - ticks0 < n) {
    80002a22:	fcc42783          	lw	a5,-52(s0)
    80002a26:	cbb9                	beqz	a5,80002a7c <sys_pause+0x80>
    80002a28:	f426                	sd	s1,40(sp)
    80002a2a:	f04a                	sd	s2,32(sp)
    80002a2c:	ec4e                	sd	s3,24(sp)
  ticks0 = ticks;
    80002a2e:	00008997          	auipc	s3,0x8
    80002a32:	8f29a983          	lw	s3,-1806(s3) # 8000a320 <ticks>
    if (killed(myproc())) {
      release(&tickslock);
      return -1;
    }
    sleep_prepare(&ticks);
    80002a36:	00008917          	auipc	s2,0x8
    80002a3a:	8ea90913          	addi	s2,s2,-1814 # 8000a320 <ticks>
    release(&tickslock);
    80002a3e:	00016497          	auipc	s1,0x16
    80002a42:	83248493          	addi	s1,s1,-1998 # 80018270 <tickslock>
    if (killed(myproc())) {
    80002a46:	ec3fe0ef          	jal	80001908 <myproc>
    80002a4a:	f26ff0ef          	jal	80002170 <killed>
    80002a4e:	e529                	bnez	a0,80002a98 <sys_pause+0x9c>
    sleep_prepare(&ticks);
    80002a50:	854a                	mv	a0,s2
    80002a52:	cc0ff0ef          	jal	80001f12 <sleep_prepare>
    release(&tickslock);
    80002a56:	8526                	mv	a0,s1
    80002a58:	a18fe0ef          	jal	80000c70 <release>
    sleep();
    80002a5c:	cf2ff0ef          	jal	80001f4e <sleep>
    acquire(&tickslock);
    80002a60:	8526                	mv	a0,s1
    80002a62:	986fe0ef          	jal	80000be8 <acquire>
  while (ticks - ticks0 < n) {
    80002a66:	00092783          	lw	a5,0(s2)
    80002a6a:	413787bb          	subw	a5,a5,s3
    80002a6e:	fcc42703          	lw	a4,-52(s0)
    80002a72:	fce7eae3          	bltu	a5,a4,80002a46 <sys_pause+0x4a>
    80002a76:	74a2                	ld	s1,40(sp)
    80002a78:	7902                	ld	s2,32(sp)
    80002a7a:	69e2                	ld	s3,24(sp)
  }
  release(&tickslock);
    80002a7c:	00015517          	auipc	a0,0x15
    80002a80:	7f450513          	addi	a0,a0,2036 # 80018270 <tickslock>
    80002a84:	9ecfe0ef          	jal	80000c70 <release>
  return 0;
    80002a88:	4501                	li	a0,0
}
    80002a8a:	70e2                	ld	ra,56(sp)
    80002a8c:	7442                	ld	s0,48(sp)
    80002a8e:	6121                	addi	sp,sp,64
    80002a90:	8082                	ret
    n = 0;
    80002a92:	fc042623          	sw	zero,-52(s0)
    80002a96:	b741                	j	80002a16 <sys_pause+0x1a>
      release(&tickslock);
    80002a98:	00015517          	auipc	a0,0x15
    80002a9c:	7d850513          	addi	a0,a0,2008 # 80018270 <tickslock>
    80002aa0:	9d0fe0ef          	jal	80000c70 <release>
      return -1;
    80002aa4:	557d                	li	a0,-1
    80002aa6:	74a2                	ld	s1,40(sp)
    80002aa8:	7902                	ld	s2,32(sp)
    80002aaa:	69e2                	ld	s3,24(sp)
    80002aac:	bff9                	j	80002a8a <sys_pause+0x8e>

0000000080002aae <sys_kill>:

uint64
sys_kill(void)
{
    80002aae:	1101                	addi	sp,sp,-32
    80002ab0:	ec06                	sd	ra,24(sp)
    80002ab2:	e822                	sd	s0,16(sp)
    80002ab4:	1000                	addi	s0,sp,32
  int pid;

  argint(0, &pid);
    80002ab6:	fec40593          	addi	a1,s0,-20
    80002aba:	4501                	li	a0,0
    80002abc:	d95ff0ef          	jal	80002850 <argint>
  return kkill(pid);
    80002ac0:	fec42503          	lw	a0,-20(s0)
    80002ac4:	e1cff0ef          	jal	800020e0 <kkill>
}
    80002ac8:	60e2                	ld	ra,24(sp)
    80002aca:	6442                	ld	s0,16(sp)
    80002acc:	6105                	addi	sp,sp,32
    80002ace:	8082                	ret

0000000080002ad0 <sys_uptime>:

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
    80002ad0:	1101                	addi	sp,sp,-32
    80002ad2:	ec06                	sd	ra,24(sp)
    80002ad4:	e822                	sd	s0,16(sp)
    80002ad6:	e426                	sd	s1,8(sp)
    80002ad8:	1000                	addi	s0,sp,32
  uint xticks;

  acquire(&tickslock);
    80002ada:	00015517          	auipc	a0,0x15
    80002ade:	79650513          	addi	a0,a0,1942 # 80018270 <tickslock>
    80002ae2:	906fe0ef          	jal	80000be8 <acquire>
  xticks = ticks;
    80002ae6:	00008797          	auipc	a5,0x8
    80002aea:	83a7a783          	lw	a5,-1990(a5) # 8000a320 <ticks>
    80002aee:	84be                	mv	s1,a5
  release(&tickslock);
    80002af0:	00015517          	auipc	a0,0x15
    80002af4:	78050513          	addi	a0,a0,1920 # 80018270 <tickslock>
    80002af8:	978fe0ef          	jal	80000c70 <release>
  return xticks;
}
    80002afc:	02049513          	slli	a0,s1,0x20
    80002b00:	9101                	srli	a0,a0,0x20
    80002b02:	60e2                	ld	ra,24(sp)
    80002b04:	6442                	ld	s0,16(sp)
    80002b06:	64a2                	ld	s1,8(sp)
    80002b08:	6105                	addi	sp,sp,32
    80002b0a:	8082                	ret

0000000080002b0c <sys_hello>:

//hello 
uint64
sys_hello(void)
{
    80002b0c:	1101                	addi	sp,sp,-32
    80002b0e:	ec06                	sd	ra,24(sp)
    80002b10:	e822                	sd	s0,16(sp)
    80002b12:	1000                	addi	s0,sp,32
  int a, b, c, d;

  argint(0, &a);
    80002b14:	fec40593          	addi	a1,s0,-20
    80002b18:	4501                	li	a0,0
    80002b1a:	d37ff0ef          	jal	80002850 <argint>
  argint(1, &b);
    80002b1e:	fe840593          	addi	a1,s0,-24
    80002b22:	4505                	li	a0,1
    80002b24:	d2dff0ef          	jal	80002850 <argint>
  argint(2, &c);
    80002b28:	fe440593          	addi	a1,s0,-28
    80002b2c:	4509                	li	a0,2
    80002b2e:	d23ff0ef          	jal	80002850 <argint>
  argint(3, &d);
    80002b32:	fe040593          	addi	a1,s0,-32
    80002b36:	450d                	li	a0,3
    80002b38:	d19ff0ef          	jal	80002850 <argint>

  printk("hello %d %d %d %d\n", a, b, c, d);
    80002b3c:	fe042703          	lw	a4,-32(s0)
    80002b40:	fe442683          	lw	a3,-28(s0)
    80002b44:	fe842603          	lw	a2,-24(s0)
    80002b48:	fec42583          	lw	a1,-20(s0)
    80002b4c:	00005517          	auipc	a0,0x5
    80002b50:	86450513          	addi	a0,a0,-1948 # 800073b0 <etext+0x3b0>
    80002b54:	9b7fd0ef          	jal	8000050a <printk>

  return a + b + c + d;
    80002b58:	fec42783          	lw	a5,-20(s0)
    80002b5c:	fe842703          	lw	a4,-24(s0)
    80002b60:	9f3d                	addw	a4,a4,a5
    80002b62:	fe442783          	lw	a5,-28(s0)
    80002b66:	9fb9                	addw	a5,a5,a4
    80002b68:	fe042503          	lw	a0,-32(s0)
}
    80002b6c:	9d3d                	addw	a0,a0,a5
    80002b6e:	60e2                	ld	ra,24(sp)
    80002b70:	6442                	ld	s0,16(sp)
    80002b72:	6105                	addi	sp,sp,32
    80002b74:	8082                	ret

0000000080002b76 <binit>:
  struct buf head;
} bcache;

void
binit(void)
{
    80002b76:	7179                	addi	sp,sp,-48
    80002b78:	f406                	sd	ra,40(sp)
    80002b7a:	f022                	sd	s0,32(sp)
    80002b7c:	ec26                	sd	s1,24(sp)
    80002b7e:	e84a                	sd	s2,16(sp)
    80002b80:	e44e                	sd	s3,8(sp)
    80002b82:	e052                	sd	s4,0(sp)
    80002b84:	1800                	addi	s0,sp,48
  struct buf *b;

  initlock(&bcache.lock, "bcache");
    80002b86:	00005597          	auipc	a1,0x5
    80002b8a:	84258593          	addi	a1,a1,-1982 # 800073c8 <etext+0x3c8>
    80002b8e:	00015517          	auipc	a0,0x15
    80002b92:	6fa50513          	addi	a0,a0,1786 # 80018288 <bcache>
    80002b96:	fd3fd0ef          	jal	80000b68 <initlock>

  // Create linked list of buffers
  bcache.head.prev = &bcache.head;
    80002b9a:	0001d797          	auipc	a5,0x1d
    80002b9e:	6ee78793          	addi	a5,a5,1774 # 80020288 <bcache+0x8000>
    80002ba2:	0001e717          	auipc	a4,0x1e
    80002ba6:	94e70713          	addi	a4,a4,-1714 # 800204f0 <bcache+0x8268>
    80002baa:	2ae7b823          	sd	a4,688(a5)
  bcache.head.next = &bcache.head;
    80002bae:	2ae7bc23          	sd	a4,696(a5)
  for (b = bcache.buf; b < bcache.buf + NBUF; b++) {
    80002bb2:	00015497          	auipc	s1,0x15
    80002bb6:	6ee48493          	addi	s1,s1,1774 # 800182a0 <bcache+0x18>
    b->next = bcache.head.next;
    80002bba:	893e                	mv	s2,a5
    b->prev = &bcache.head;
    80002bbc:	89ba                	mv	s3,a4
    initsleeplock(&b->lock, "buffer");
    80002bbe:	00005a17          	auipc	s4,0x5
    80002bc2:	812a0a13          	addi	s4,s4,-2030 # 800073d0 <etext+0x3d0>
    b->next = bcache.head.next;
    80002bc6:	2b893783          	ld	a5,696(s2)
    80002bca:	e8bc                	sd	a5,80(s1)
    b->prev = &bcache.head;
    80002bcc:	0534b423          	sd	s3,72(s1)
    initsleeplock(&b->lock, "buffer");
    80002bd0:	85d2                	mv	a1,s4
    80002bd2:	01048513          	addi	a0,s1,16
    80002bd6:	41c010ef          	jal	80003ff2 <initsleeplock>
    bcache.head.next->prev = b;
    80002bda:	2b893783          	ld	a5,696(s2)
    80002bde:	e7a4                	sd	s1,72(a5)
    bcache.head.next = b;
    80002be0:	2a993c23          	sd	s1,696(s2)
  for (b = bcache.buf; b < bcache.buf + NBUF; b++) {
    80002be4:	45848493          	addi	s1,s1,1112
    80002be8:	fd349fe3          	bne	s1,s3,80002bc6 <binit+0x50>
  }
}
    80002bec:	70a2                	ld	ra,40(sp)
    80002bee:	7402                	ld	s0,32(sp)
    80002bf0:	64e2                	ld	s1,24(sp)
    80002bf2:	6942                	ld	s2,16(sp)
    80002bf4:	69a2                	ld	s3,8(sp)
    80002bf6:	6a02                	ld	s4,0(sp)
    80002bf8:	6145                	addi	sp,sp,48
    80002bfa:	8082                	ret

0000000080002bfc <bread>:
}

// Return a locked buf with the contents of the indicated block.
struct buf *
bread(uint dev, uint blockno)
{
    80002bfc:	7179                	addi	sp,sp,-48
    80002bfe:	f406                	sd	ra,40(sp)
    80002c00:	f022                	sd	s0,32(sp)
    80002c02:	ec26                	sd	s1,24(sp)
    80002c04:	e84a                	sd	s2,16(sp)
    80002c06:	e44e                	sd	s3,8(sp)
    80002c08:	1800                	addi	s0,sp,48
    80002c0a:	892a                	mv	s2,a0
    80002c0c:	89ae                	mv	s3,a1
  acquire(&bcache.lock);
    80002c0e:	00015517          	auipc	a0,0x15
    80002c12:	67a50513          	addi	a0,a0,1658 # 80018288 <bcache>
    80002c16:	fd3fd0ef          	jal	80000be8 <acquire>
  for (b = bcache.head.next; b != &bcache.head; b = b->next) {
    80002c1a:	0001e497          	auipc	s1,0x1e
    80002c1e:	9264b483          	ld	s1,-1754(s1) # 80020540 <bcache+0x82b8>
    80002c22:	0001e797          	auipc	a5,0x1e
    80002c26:	8ce78793          	addi	a5,a5,-1842 # 800204f0 <bcache+0x8268>
    80002c2a:	02f48b63          	beq	s1,a5,80002c60 <bread+0x64>
    80002c2e:	873e                	mv	a4,a5
    80002c30:	a021                	j	80002c38 <bread+0x3c>
    80002c32:	68a4                	ld	s1,80(s1)
    80002c34:	02e48663          	beq	s1,a4,80002c60 <bread+0x64>
    if (b->dev == dev && b->blockno == blockno) {
    80002c38:	449c                	lw	a5,8(s1)
    80002c3a:	ff279ce3          	bne	a5,s2,80002c32 <bread+0x36>
    80002c3e:	44dc                	lw	a5,12(s1)
    80002c40:	ff3799e3          	bne	a5,s3,80002c32 <bread+0x36>
      b->refcnt++;
    80002c44:	40bc                	lw	a5,64(s1)
    80002c46:	2785                	addiw	a5,a5,1
    80002c48:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80002c4a:	00015517          	auipc	a0,0x15
    80002c4e:	63e50513          	addi	a0,a0,1598 # 80018288 <bcache>
    80002c52:	81efe0ef          	jal	80000c70 <release>
      acquiresleep(&b->lock);
    80002c56:	01048513          	addi	a0,s1,16
    80002c5a:	3ce010ef          	jal	80004028 <acquiresleep>
      return b;
    80002c5e:	a889                	j	80002cb0 <bread+0xb4>
  for (b = bcache.head.prev; b != &bcache.head; b = b->prev) {
    80002c60:	0001e497          	auipc	s1,0x1e
    80002c64:	8d84b483          	ld	s1,-1832(s1) # 80020538 <bcache+0x82b0>
    80002c68:	0001e797          	auipc	a5,0x1e
    80002c6c:	88878793          	addi	a5,a5,-1912 # 800204f0 <bcache+0x8268>
    80002c70:	00f48863          	beq	s1,a5,80002c80 <bread+0x84>
    80002c74:	873e                	mv	a4,a5
    if (b->refcnt == 0) {
    80002c76:	40bc                	lw	a5,64(s1)
    80002c78:	cb91                	beqz	a5,80002c8c <bread+0x90>
  for (b = bcache.head.prev; b != &bcache.head; b = b->prev) {
    80002c7a:	64a4                	ld	s1,72(s1)
    80002c7c:	fee49de3          	bne	s1,a4,80002c76 <bread+0x7a>
  panic("bget: no buffers");
    80002c80:	00004517          	auipc	a0,0x4
    80002c84:	75850513          	addi	a0,a0,1880 # 800073d8 <etext+0x3d8>
    80002c88:	badfd0ef          	jal	80000834 <panic>
      b->dev = dev;
    80002c8c:	0124a423          	sw	s2,8(s1)
      b->blockno = blockno;
    80002c90:	0134a623          	sw	s3,12(s1)
      b->valid = 0;
    80002c94:	0004a023          	sw	zero,0(s1)
      b->refcnt = 1;
    80002c98:	4785                	li	a5,1
    80002c9a:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80002c9c:	00015517          	auipc	a0,0x15
    80002ca0:	5ec50513          	addi	a0,a0,1516 # 80018288 <bcache>
    80002ca4:	fcdfd0ef          	jal	80000c70 <release>
      acquiresleep(&b->lock);
    80002ca8:	01048513          	addi	a0,s1,16
    80002cac:	37c010ef          	jal	80004028 <acquiresleep>
  struct buf *b;

  b = bget(dev, blockno);
  if (!b->valid) {
    80002cb0:	409c                	lw	a5,0(s1)
    80002cb2:	cb89                	beqz	a5,80002cc4 <bread+0xc8>
    virtio_disk_rw(b, 0);
    b->valid = 1;
  }
  return b;
}
    80002cb4:	8526                	mv	a0,s1
    80002cb6:	70a2                	ld	ra,40(sp)
    80002cb8:	7402                	ld	s0,32(sp)
    80002cba:	64e2                	ld	s1,24(sp)
    80002cbc:	6942                	ld	s2,16(sp)
    80002cbe:	69a2                	ld	s3,8(sp)
    80002cc0:	6145                	addi	sp,sp,48
    80002cc2:	8082                	ret
    virtio_disk_rw(b, 0);
    80002cc4:	4581                	li	a1,0
    80002cc6:	8526                	mv	a0,s1
    80002cc8:	49f020ef          	jal	80005966 <virtio_disk_rw>
    b->valid = 1;
    80002ccc:	4785                	li	a5,1
    80002cce:	c09c                	sw	a5,0(s1)
  return b;
    80002cd0:	b7d5                	j	80002cb4 <bread+0xb8>

0000000080002cd2 <bwrite>:

// Write b's contents to disk.  Must be locked.
// Only the log calls bwrite.
void
bwrite(struct buf *b)
{
    80002cd2:	1101                	addi	sp,sp,-32
    80002cd4:	ec06                	sd	ra,24(sp)
    80002cd6:	e822                	sd	s0,16(sp)
    80002cd8:	e426                	sd	s1,8(sp)
    80002cda:	1000                	addi	s0,sp,32
    80002cdc:	84aa                	mv	s1,a0
  if (!holdingsleep(&b->lock))
    80002cde:	0541                	addi	a0,a0,16
    80002ce0:	3d4010ef          	jal	800040b4 <holdingsleep>
    80002ce4:	c911                	beqz	a0,80002cf8 <bwrite+0x26>
    panic("bwrite");
  virtio_disk_rw(b, 1);
    80002ce6:	4585                	li	a1,1
    80002ce8:	8526                	mv	a0,s1
    80002cea:	47d020ef          	jal	80005966 <virtio_disk_rw>
}
    80002cee:	60e2                	ld	ra,24(sp)
    80002cf0:	6442                	ld	s0,16(sp)
    80002cf2:	64a2                	ld	s1,8(sp)
    80002cf4:	6105                	addi	sp,sp,32
    80002cf6:	8082                	ret
    panic("bwrite");
    80002cf8:	00004517          	auipc	a0,0x4
    80002cfc:	6f850513          	addi	a0,a0,1784 # 800073f0 <etext+0x3f0>
    80002d00:	b35fd0ef          	jal	80000834 <panic>

0000000080002d04 <brelse>:

// Release a locked buffer.
// Move to the head of the most-recently-used list.
void
brelse(struct buf *b)
{
    80002d04:	1101                	addi	sp,sp,-32
    80002d06:	ec06                	sd	ra,24(sp)
    80002d08:	e822                	sd	s0,16(sp)
    80002d0a:	e426                	sd	s1,8(sp)
    80002d0c:	e04a                	sd	s2,0(sp)
    80002d0e:	1000                	addi	s0,sp,32
    80002d10:	84aa                	mv	s1,a0
  if (!holdingsleep(&b->lock))
    80002d12:	01050913          	addi	s2,a0,16
    80002d16:	854a                	mv	a0,s2
    80002d18:	39c010ef          	jal	800040b4 <holdingsleep>
    80002d1c:	c125                	beqz	a0,80002d7c <brelse+0x78>
    panic("brelse");

  releasesleep(&b->lock);
    80002d1e:	854a                	mv	a0,s2
    80002d20:	35c010ef          	jal	8000407c <releasesleep>

  acquire(&bcache.lock);
    80002d24:	00015517          	auipc	a0,0x15
    80002d28:	56450513          	addi	a0,a0,1380 # 80018288 <bcache>
    80002d2c:	ebdfd0ef          	jal	80000be8 <acquire>
  b->refcnt--;
    80002d30:	40bc                	lw	a5,64(s1)
    80002d32:	37fd                	addiw	a5,a5,-1
    80002d34:	c0bc                	sw	a5,64(s1)
  if (b->refcnt == 0) {
    80002d36:	e79d                	bnez	a5,80002d64 <brelse+0x60>
    // no one is waiting for it.
    b->next->prev = b->prev;
    80002d38:	68b8                	ld	a4,80(s1)
    80002d3a:	64bc                	ld	a5,72(s1)
    80002d3c:	e73c                	sd	a5,72(a4)
    b->prev->next = b->next;
    80002d3e:	68b8                	ld	a4,80(s1)
    80002d40:	ebb8                	sd	a4,80(a5)
    b->next = bcache.head.next;
    80002d42:	0001d797          	auipc	a5,0x1d
    80002d46:	54678793          	addi	a5,a5,1350 # 80020288 <bcache+0x8000>
    80002d4a:	2b87b703          	ld	a4,696(a5)
    80002d4e:	e8b8                	sd	a4,80(s1)
    b->prev = &bcache.head;
    80002d50:	0001d717          	auipc	a4,0x1d
    80002d54:	7a070713          	addi	a4,a4,1952 # 800204f0 <bcache+0x8268>
    80002d58:	e4b8                	sd	a4,72(s1)
    bcache.head.next->prev = b;
    80002d5a:	2b87b703          	ld	a4,696(a5)
    80002d5e:	e724                	sd	s1,72(a4)
    bcache.head.next = b;
    80002d60:	2a97bc23          	sd	s1,696(a5)
  }

  release(&bcache.lock);
    80002d64:	00015517          	auipc	a0,0x15
    80002d68:	52450513          	addi	a0,a0,1316 # 80018288 <bcache>
    80002d6c:	f05fd0ef          	jal	80000c70 <release>
}
    80002d70:	60e2                	ld	ra,24(sp)
    80002d72:	6442                	ld	s0,16(sp)
    80002d74:	64a2                	ld	s1,8(sp)
    80002d76:	6902                	ld	s2,0(sp)
    80002d78:	6105                	addi	sp,sp,32
    80002d7a:	8082                	ret
    panic("brelse");
    80002d7c:	00004517          	auipc	a0,0x4
    80002d80:	67c50513          	addi	a0,a0,1660 # 800073f8 <etext+0x3f8>
    80002d84:	ab1fd0ef          	jal	80000834 <panic>

0000000080002d88 <bpin>:

void
bpin(struct buf *b)
{
    80002d88:	1101                	addi	sp,sp,-32
    80002d8a:	ec06                	sd	ra,24(sp)
    80002d8c:	e822                	sd	s0,16(sp)
    80002d8e:	e426                	sd	s1,8(sp)
    80002d90:	1000                	addi	s0,sp,32
    80002d92:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80002d94:	00015517          	auipc	a0,0x15
    80002d98:	4f450513          	addi	a0,a0,1268 # 80018288 <bcache>
    80002d9c:	e4dfd0ef          	jal	80000be8 <acquire>
  b->refcnt++;
    80002da0:	40bc                	lw	a5,64(s1)
    80002da2:	2785                	addiw	a5,a5,1
    80002da4:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    80002da6:	00015517          	auipc	a0,0x15
    80002daa:	4e250513          	addi	a0,a0,1250 # 80018288 <bcache>
    80002dae:	ec3fd0ef          	jal	80000c70 <release>
}
    80002db2:	60e2                	ld	ra,24(sp)
    80002db4:	6442                	ld	s0,16(sp)
    80002db6:	64a2                	ld	s1,8(sp)
    80002db8:	6105                	addi	sp,sp,32
    80002dba:	8082                	ret

0000000080002dbc <bunpin>:

void
bunpin(struct buf *b)
{
    80002dbc:	1101                	addi	sp,sp,-32
    80002dbe:	ec06                	sd	ra,24(sp)
    80002dc0:	e822                	sd	s0,16(sp)
    80002dc2:	e426                	sd	s1,8(sp)
    80002dc4:	1000                	addi	s0,sp,32
    80002dc6:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80002dc8:	00015517          	auipc	a0,0x15
    80002dcc:	4c050513          	addi	a0,a0,1216 # 80018288 <bcache>
    80002dd0:	e19fd0ef          	jal	80000be8 <acquire>
  b->refcnt--;
    80002dd4:	40bc                	lw	a5,64(s1)
    80002dd6:	37fd                	addiw	a5,a5,-1
    80002dd8:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    80002dda:	00015517          	auipc	a0,0x15
    80002dde:	4ae50513          	addi	a0,a0,1198 # 80018288 <bcache>
    80002de2:	e8ffd0ef          	jal	80000c70 <release>
}
    80002de6:	60e2                	ld	ra,24(sp)
    80002de8:	6442                	ld	s0,16(sp)
    80002dea:	64a2                	ld	s1,8(sp)
    80002dec:	6105                	addi	sp,sp,32
    80002dee:	8082                	ret

0000000080002df0 <bfree>:
}

// Free a disk block.
static void
bfree(int dev, uint b)
{
    80002df0:	1101                	addi	sp,sp,-32
    80002df2:	ec06                	sd	ra,24(sp)
    80002df4:	e822                	sd	s0,16(sp)
    80002df6:	e426                	sd	s1,8(sp)
    80002df8:	e04a                	sd	s2,0(sp)
    80002dfa:	1000                	addi	s0,sp,32
    80002dfc:	84ae                	mv	s1,a1
  struct buf *bp;
  int bi, m;

  bp = bread(dev, BBLOCK(b, sb));
    80002dfe:	00d5d79b          	srliw	a5,a1,0xd
    80002e02:	0001e597          	auipc	a1,0x1e
    80002e06:	b625a583          	lw	a1,-1182(a1) # 80020964 <sb+0x1c>
    80002e0a:	9dbd                	addw	a1,a1,a5
    80002e0c:	df1ff0ef          	jal	80002bfc <bread>
  bi = b % BPB;
  m = 1 << (bi % 8);
    80002e10:	0074f713          	andi	a4,s1,7
    80002e14:	4785                	li	a5,1
    80002e16:	00e797bb          	sllw	a5,a5,a4
  bi = b % BPB;
    80002e1a:	14ce                	slli	s1,s1,0x33
  if ((bp->data[bi / 8] & m) == 0)
    80002e1c:	90d9                	srli	s1,s1,0x36
    80002e1e:	00950733          	add	a4,a0,s1
    80002e22:	05874703          	lbu	a4,88(a4)
    80002e26:	00e7f6b3          	and	a3,a5,a4
    80002e2a:	c29d                	beqz	a3,80002e50 <bfree+0x60>
    80002e2c:	892a                	mv	s2,a0
    panic("freeing free block");
  bp->data[bi / 8] &= ~m;
    80002e2e:	94aa                	add	s1,s1,a0
    80002e30:	fff7c793          	not	a5,a5
    80002e34:	8f7d                	and	a4,a4,a5
    80002e36:	04e48c23          	sb	a4,88(s1)
  log_write(bp);
    80002e3a:	080010ef          	jal	80003eba <log_write>
  brelse(bp);
    80002e3e:	854a                	mv	a0,s2
    80002e40:	ec5ff0ef          	jal	80002d04 <brelse>
}
    80002e44:	60e2                	ld	ra,24(sp)
    80002e46:	6442                	ld	s0,16(sp)
    80002e48:	64a2                	ld	s1,8(sp)
    80002e4a:	6902                	ld	s2,0(sp)
    80002e4c:	6105                	addi	sp,sp,32
    80002e4e:	8082                	ret
    panic("freeing free block");
    80002e50:	00004517          	auipc	a0,0x4
    80002e54:	5b050513          	addi	a0,a0,1456 # 80007400 <etext+0x400>
    80002e58:	9ddfd0ef          	jal	80000834 <panic>

0000000080002e5c <balloc>:
{
    80002e5c:	715d                	addi	sp,sp,-80
    80002e5e:	e486                	sd	ra,72(sp)
    80002e60:	e0a2                	sd	s0,64(sp)
    80002e62:	fc26                	sd	s1,56(sp)
    80002e64:	0880                	addi	s0,sp,80
  for (b = 0; b < sb.size; b += BPB) {
    80002e66:	0001e797          	auipc	a5,0x1e
    80002e6a:	ae67a783          	lw	a5,-1306(a5) # 8002094c <sb+0x4>
    80002e6e:	0e078263          	beqz	a5,80002f52 <balloc+0xf6>
    80002e72:	f84a                	sd	s2,48(sp)
    80002e74:	f44e                	sd	s3,40(sp)
    80002e76:	f052                	sd	s4,32(sp)
    80002e78:	ec56                	sd	s5,24(sp)
    80002e7a:	e85a                	sd	s6,16(sp)
    80002e7c:	e45e                	sd	s7,8(sp)
    80002e7e:	e062                	sd	s8,0(sp)
    80002e80:	8baa                	mv	s7,a0
    80002e82:	4a81                	li	s5,0
    bp = bread(dev, BBLOCK(b, sb));
    80002e84:	0001eb17          	auipc	s6,0x1e
    80002e88:	ac4b0b13          	addi	s6,s6,-1340 # 80020948 <sb>
      m = 1 << (bi % 8);
    80002e8c:	4985                	li	s3,1
    for (bi = 0; bi < BPB && b + bi < sb.size; bi++) {
    80002e8e:	6a09                	lui	s4,0x2
  for (b = 0; b < sb.size; b += BPB) {
    80002e90:	6c09                	lui	s8,0x2
    80002e92:	a09d                	j	80002ef8 <balloc+0x9c>
        bp->data[bi / 8] |= m;           // Mark block in use.
    80002e94:	97ca                	add	a5,a5,s2
    80002e96:	8e55                	or	a2,a2,a3
    80002e98:	04c78c23          	sb	a2,88(a5)
        log_write(bp);
    80002e9c:	854a                	mv	a0,s2
    80002e9e:	01c010ef          	jal	80003eba <log_write>
        brelse(bp);
    80002ea2:	854a                	mv	a0,s2
    80002ea4:	e61ff0ef          	jal	80002d04 <brelse>
  bp = bread(dev, bno);
    80002ea8:	85a6                	mv	a1,s1
    80002eaa:	855e                	mv	a0,s7
    80002eac:	d51ff0ef          	jal	80002bfc <bread>
    80002eb0:	892a                	mv	s2,a0
  memset(bp->data, 0, BSIZE);
    80002eb2:	40000613          	li	a2,1024
    80002eb6:	4581                	li	a1,0
    80002eb8:	05850513          	addi	a0,a0,88
    80002ebc:	dedfd0ef          	jal	80000ca8 <memset>
  log_write(bp);
    80002ec0:	854a                	mv	a0,s2
    80002ec2:	7f9000ef          	jal	80003eba <log_write>
  brelse(bp);
    80002ec6:	854a                	mv	a0,s2
    80002ec8:	e3dff0ef          	jal	80002d04 <brelse>
}
    80002ecc:	7942                	ld	s2,48(sp)
    80002ece:	79a2                	ld	s3,40(sp)
    80002ed0:	7a02                	ld	s4,32(sp)
    80002ed2:	6ae2                	ld	s5,24(sp)
    80002ed4:	6b42                	ld	s6,16(sp)
    80002ed6:	6ba2                	ld	s7,8(sp)
    80002ed8:	6c02                	ld	s8,0(sp)
}
    80002eda:	8526                	mv	a0,s1
    80002edc:	60a6                	ld	ra,72(sp)
    80002ede:	6406                	ld	s0,64(sp)
    80002ee0:	74e2                	ld	s1,56(sp)
    80002ee2:	6161                	addi	sp,sp,80
    80002ee4:	8082                	ret
    brelse(bp);
    80002ee6:	854a                	mv	a0,s2
    80002ee8:	e1dff0ef          	jal	80002d04 <brelse>
  for (b = 0; b < sb.size; b += BPB) {
    80002eec:	015c0abb          	addw	s5,s8,s5
    80002ef0:	004b2783          	lw	a5,4(s6)
    80002ef4:	04faf863          	bgeu	s5,a5,80002f44 <balloc+0xe8>
    bp = bread(dev, BBLOCK(b, sb));
    80002ef8:	40dad59b          	sraiw	a1,s5,0xd
    80002efc:	01cb2783          	lw	a5,28(s6)
    80002f00:	9dbd                	addw	a1,a1,a5
    80002f02:	855e                	mv	a0,s7
    80002f04:	cf9ff0ef          	jal	80002bfc <bread>
    80002f08:	892a                	mv	s2,a0
    for (bi = 0; bi < BPB && b + bi < sb.size; bi++) {
    80002f0a:	004b2503          	lw	a0,4(s6)
    80002f0e:	84d6                	mv	s1,s5
    80002f10:	4701                	li	a4,0
    80002f12:	fca4fae3          	bgeu	s1,a0,80002ee6 <balloc+0x8a>
      m = 1 << (bi % 8);
    80002f16:	00777693          	andi	a3,a4,7
    80002f1a:	00d996bb          	sllw	a3,s3,a3
      if ((bp->data[bi / 8] & m) == 0) { // Is block free?
    80002f1e:	41f7579b          	sraiw	a5,a4,0x1f
    80002f22:	01d7d79b          	srliw	a5,a5,0x1d
    80002f26:	9fb9                	addw	a5,a5,a4
    80002f28:	4037d79b          	sraiw	a5,a5,0x3
    80002f2c:	00f90633          	add	a2,s2,a5
    80002f30:	05864603          	lbu	a2,88(a2) # 1058 <_entry-0x7fffefa8>
    80002f34:	00c6f5b3          	and	a1,a3,a2
    80002f38:	ddb1                	beqz	a1,80002e94 <balloc+0x38>
    for (bi = 0; bi < BPB && b + bi < sb.size; bi++) {
    80002f3a:	2705                	addiw	a4,a4,1
    80002f3c:	2485                	addiw	s1,s1,1
    80002f3e:	fd471ae3          	bne	a4,s4,80002f12 <balloc+0xb6>
    80002f42:	b755                	j	80002ee6 <balloc+0x8a>
    80002f44:	7942                	ld	s2,48(sp)
    80002f46:	79a2                	ld	s3,40(sp)
    80002f48:	7a02                	ld	s4,32(sp)
    80002f4a:	6ae2                	ld	s5,24(sp)
    80002f4c:	6b42                	ld	s6,16(sp)
    80002f4e:	6ba2                	ld	s7,8(sp)
    80002f50:	6c02                	ld	s8,0(sp)
  printk("balloc: out of blocks\n");
    80002f52:	00004517          	auipc	a0,0x4
    80002f56:	4c650513          	addi	a0,a0,1222 # 80007418 <etext+0x418>
    80002f5a:	db0fd0ef          	jal	8000050a <printk>
  return 0;
    80002f5e:	4481                	li	s1,0
    80002f60:	bfad                	j	80002eda <balloc+0x7e>

0000000080002f62 <bmap>:
// Return the disk block address of the nth block in inode ip.
// If there is no such block, bmap allocates one.
// returns 0 if out of disk space.
static uint
bmap(struct inode *ip, uint bn)
{
    80002f62:	7179                	addi	sp,sp,-48
    80002f64:	f406                	sd	ra,40(sp)
    80002f66:	f022                	sd	s0,32(sp)
    80002f68:	ec26                	sd	s1,24(sp)
    80002f6a:	e84a                	sd	s2,16(sp)
    80002f6c:	e44e                	sd	s3,8(sp)
    80002f6e:	1800                	addi	s0,sp,48
    80002f70:	892a                	mv	s2,a0
  uint addr, *a;
  struct buf *bp;

  if (bn < NDIRECT) {
    80002f72:	47ad                	li	a5,11
    80002f74:	02b7e363          	bltu	a5,a1,80002f9a <bmap+0x38>
    if ((addr = ip->addrs[bn]) == 0) {
    80002f78:	02059793          	slli	a5,a1,0x20
    80002f7c:	01e7d593          	srli	a1,a5,0x1e
    80002f80:	00b509b3          	add	s3,a0,a1
    80002f84:	0509a483          	lw	s1,80(s3)
    80002f88:	e0b5                	bnez	s1,80002fec <bmap+0x8a>
      addr = balloc(ip->dev);
    80002f8a:	4108                	lw	a0,0(a0)
    80002f8c:	ed1ff0ef          	jal	80002e5c <balloc>
    80002f90:	84aa                	mv	s1,a0
      if (addr == 0)
    80002f92:	cd29                	beqz	a0,80002fec <bmap+0x8a>
        return 0;
      ip->addrs[bn] = addr;
    80002f94:	04a9a823          	sw	a0,80(s3)
    80002f98:	a891                	j	80002fec <bmap+0x8a>
    }
    return addr;
  }
  bn -= NDIRECT;
    80002f9a:	ff45879b          	addiw	a5,a1,-12
    80002f9e:	873e                	mv	a4,a5
    80002fa0:	89be                	mv	s3,a5

  if (bn < NINDIRECT) {
    80002fa2:	0ff00793          	li	a5,255
    80002fa6:	06e7e763          	bltu	a5,a4,80003014 <bmap+0xb2>
    // Load indirect block, allocating if necessary.
    if ((addr = ip->addrs[NDIRECT]) == 0) {
    80002faa:	08052483          	lw	s1,128(a0)
    80002fae:	e891                	bnez	s1,80002fc2 <bmap+0x60>
      addr = balloc(ip->dev);
    80002fb0:	4108                	lw	a0,0(a0)
    80002fb2:	eabff0ef          	jal	80002e5c <balloc>
    80002fb6:	84aa                	mv	s1,a0
      if (addr == 0)
    80002fb8:	c915                	beqz	a0,80002fec <bmap+0x8a>
    80002fba:	e052                	sd	s4,0(sp)
        return 0;
      ip->addrs[NDIRECT] = addr;
    80002fbc:	08a92023          	sw	a0,128(s2)
    80002fc0:	a011                	j	80002fc4 <bmap+0x62>
    80002fc2:	e052                	sd	s4,0(sp)
    }
    bp = bread(ip->dev, addr);
    80002fc4:	85a6                	mv	a1,s1
    80002fc6:	00092503          	lw	a0,0(s2)
    80002fca:	c33ff0ef          	jal	80002bfc <bread>
    80002fce:	8a2a                	mv	s4,a0
    a = (uint *)bp->data;
    80002fd0:	05850793          	addi	a5,a0,88
    if ((addr = a[bn]) == 0) {
    80002fd4:	02099713          	slli	a4,s3,0x20
    80002fd8:	01e75593          	srli	a1,a4,0x1e
    80002fdc:	97ae                	add	a5,a5,a1
    80002fde:	89be                	mv	s3,a5
    80002fe0:	4384                	lw	s1,0(a5)
    80002fe2:	cc89                	beqz	s1,80002ffc <bmap+0x9a>
      if (addr) {
        a[bn] = addr;
        log_write(bp);
      }
    }
    brelse(bp);
    80002fe4:	8552                	mv	a0,s4
    80002fe6:	d1fff0ef          	jal	80002d04 <brelse>
    return addr;
    80002fea:	6a02                	ld	s4,0(sp)
  }

  panic("bmap: out of range");
}
    80002fec:	8526                	mv	a0,s1
    80002fee:	70a2                	ld	ra,40(sp)
    80002ff0:	7402                	ld	s0,32(sp)
    80002ff2:	64e2                	ld	s1,24(sp)
    80002ff4:	6942                	ld	s2,16(sp)
    80002ff6:	69a2                	ld	s3,8(sp)
    80002ff8:	6145                	addi	sp,sp,48
    80002ffa:	8082                	ret
      addr = balloc(ip->dev);
    80002ffc:	00092503          	lw	a0,0(s2)
    80003000:	e5dff0ef          	jal	80002e5c <balloc>
    80003004:	84aa                	mv	s1,a0
      if (addr) {
    80003006:	dd79                	beqz	a0,80002fe4 <bmap+0x82>
        a[bn] = addr;
    80003008:	00a9a023          	sw	a0,0(s3)
        log_write(bp);
    8000300c:	8552                	mv	a0,s4
    8000300e:	6ad000ef          	jal	80003eba <log_write>
    80003012:	bfc9                	j	80002fe4 <bmap+0x82>
    80003014:	e052                	sd	s4,0(sp)
  panic("bmap: out of range");
    80003016:	00004517          	auipc	a0,0x4
    8000301a:	41a50513          	addi	a0,a0,1050 # 80007430 <etext+0x430>
    8000301e:	817fd0ef          	jal	80000834 <panic>

0000000080003022 <iget>:
{
    80003022:	7179                	addi	sp,sp,-48
    80003024:	f406                	sd	ra,40(sp)
    80003026:	f022                	sd	s0,32(sp)
    80003028:	ec26                	sd	s1,24(sp)
    8000302a:	e84a                	sd	s2,16(sp)
    8000302c:	e44e                	sd	s3,8(sp)
    8000302e:	e052                	sd	s4,0(sp)
    80003030:	1800                	addi	s0,sp,48
    80003032:	892a                	mv	s2,a0
    80003034:	8a2e                	mv	s4,a1
  acquire(&itable.lock);
    80003036:	0001e517          	auipc	a0,0x1e
    8000303a:	93250513          	addi	a0,a0,-1742 # 80020968 <itable>
    8000303e:	babfd0ef          	jal	80000be8 <acquire>
  empty = 0;
    80003042:	4981                	li	s3,0
  for (ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++) {
    80003044:	0001e497          	auipc	s1,0x1e
    80003048:	93c48493          	addi	s1,s1,-1732 # 80020980 <itable+0x18>
    8000304c:	0001f697          	auipc	a3,0x1f
    80003050:	3c468693          	addi	a3,a3,964 # 80022410 <log>
    80003054:	a809                	j	80003066 <iget+0x44>
    if (empty == 0 && ip->ref == 0) // Remember empty slot.
    80003056:	e781                	bnez	a5,8000305e <iget+0x3c>
    80003058:	00099363          	bnez	s3,8000305e <iget+0x3c>
      empty = ip;
    8000305c:	89a6                	mv	s3,s1
  for (ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++) {
    8000305e:	08848493          	addi	s1,s1,136
    80003062:	02d48563          	beq	s1,a3,8000308c <iget+0x6a>
    if (ip->ref > 0 && ip->dev == dev && ip->inum == inum) {
    80003066:	449c                	lw	a5,8(s1)
    80003068:	fef057e3          	blez	a5,80003056 <iget+0x34>
    8000306c:	4098                	lw	a4,0(s1)
    8000306e:	ff2718e3          	bne	a4,s2,8000305e <iget+0x3c>
    80003072:	40d8                	lw	a4,4(s1)
    80003074:	ff4715e3          	bne	a4,s4,8000305e <iget+0x3c>
      ip->ref++;
    80003078:	2785                	addiw	a5,a5,1
    8000307a:	c49c                	sw	a5,8(s1)
      release(&itable.lock);
    8000307c:	0001e517          	auipc	a0,0x1e
    80003080:	8ec50513          	addi	a0,a0,-1812 # 80020968 <itable>
    80003084:	bedfd0ef          	jal	80000c70 <release>
      return ip;
    80003088:	89a6                	mv	s3,s1
    8000308a:	a015                	j	800030ae <iget+0x8c>
  if (empty == 0)
    8000308c:	02098a63          	beqz	s3,800030c0 <iget+0x9e>
  ip->dev = dev;
    80003090:	0129a023          	sw	s2,0(s3)
  ip->inum = inum;
    80003094:	0149a223          	sw	s4,4(s3)
  ip->ref = 1;
    80003098:	4785                	li	a5,1
    8000309a:	00f9a423          	sw	a5,8(s3)
  ip->valid = 0;
    8000309e:	0409a023          	sw	zero,64(s3)
  release(&itable.lock);
    800030a2:	0001e517          	auipc	a0,0x1e
    800030a6:	8c650513          	addi	a0,a0,-1850 # 80020968 <itable>
    800030aa:	bc7fd0ef          	jal	80000c70 <release>
}
    800030ae:	854e                	mv	a0,s3
    800030b0:	70a2                	ld	ra,40(sp)
    800030b2:	7402                	ld	s0,32(sp)
    800030b4:	64e2                	ld	s1,24(sp)
    800030b6:	6942                	ld	s2,16(sp)
    800030b8:	69a2                	ld	s3,8(sp)
    800030ba:	6a02                	ld	s4,0(sp)
    800030bc:	6145                	addi	sp,sp,48
    800030be:	8082                	ret
    panic("iget: no inodes");
    800030c0:	00004517          	auipc	a0,0x4
    800030c4:	38850513          	addi	a0,a0,904 # 80007448 <etext+0x448>
    800030c8:	f6cfd0ef          	jal	80000834 <panic>

00000000800030cc <iinit>:
{
    800030cc:	7179                	addi	sp,sp,-48
    800030ce:	f406                	sd	ra,40(sp)
    800030d0:	f022                	sd	s0,32(sp)
    800030d2:	ec26                	sd	s1,24(sp)
    800030d4:	e84a                	sd	s2,16(sp)
    800030d6:	e44e                	sd	s3,8(sp)
    800030d8:	1800                	addi	s0,sp,48
  initlock(&itable.lock, "itable");
    800030da:	00004597          	auipc	a1,0x4
    800030de:	37e58593          	addi	a1,a1,894 # 80007458 <etext+0x458>
    800030e2:	0001e517          	auipc	a0,0x1e
    800030e6:	88650513          	addi	a0,a0,-1914 # 80020968 <itable>
    800030ea:	a7ffd0ef          	jal	80000b68 <initlock>
  for (i = 0; i < NINODE; i++) {
    800030ee:	0001e497          	auipc	s1,0x1e
    800030f2:	8a248493          	addi	s1,s1,-1886 # 80020990 <itable+0x28>
    800030f6:	0001f997          	auipc	s3,0x1f
    800030fa:	32a98993          	addi	s3,s3,810 # 80022420 <log+0x10>
    initsleeplock(&itable.inode[i].lock, "inode");
    800030fe:	00004917          	auipc	s2,0x4
    80003102:	36290913          	addi	s2,s2,866 # 80007460 <etext+0x460>
    80003106:	85ca                	mv	a1,s2
    80003108:	8526                	mv	a0,s1
    8000310a:	6e9000ef          	jal	80003ff2 <initsleeplock>
  for (i = 0; i < NINODE; i++) {
    8000310e:	08848493          	addi	s1,s1,136
    80003112:	ff349ae3          	bne	s1,s3,80003106 <iinit+0x3a>
}
    80003116:	70a2                	ld	ra,40(sp)
    80003118:	7402                	ld	s0,32(sp)
    8000311a:	64e2                	ld	s1,24(sp)
    8000311c:	6942                	ld	s2,16(sp)
    8000311e:	69a2                	ld	s3,8(sp)
    80003120:	6145                	addi	sp,sp,48
    80003122:	8082                	ret

0000000080003124 <ialloc>:
{
    80003124:	7139                	addi	sp,sp,-64
    80003126:	fc06                	sd	ra,56(sp)
    80003128:	f822                	sd	s0,48(sp)
    8000312a:	0080                	addi	s0,sp,64
  for (inum = 1; inum < sb.ninodes; inum++) {
    8000312c:	0001e717          	auipc	a4,0x1e
    80003130:	82872703          	lw	a4,-2008(a4) # 80020954 <sb+0xc>
    80003134:	4785                	li	a5,1
    80003136:	06e7f063          	bgeu	a5,a4,80003196 <ialloc+0x72>
    8000313a:	f426                	sd	s1,40(sp)
    8000313c:	f04a                	sd	s2,32(sp)
    8000313e:	ec4e                	sd	s3,24(sp)
    80003140:	e852                	sd	s4,16(sp)
    80003142:	e456                	sd	s5,8(sp)
    80003144:	e05a                	sd	s6,0(sp)
    80003146:	8aaa                	mv	s5,a0
    80003148:	8b2e                	mv	s6,a1
    8000314a:	893e                	mv	s2,a5
    bp = bread(dev, IBLOCK(inum, sb));
    8000314c:	0001da17          	auipc	s4,0x1d
    80003150:	7fca0a13          	addi	s4,s4,2044 # 80020948 <sb>
    80003154:	00495593          	srli	a1,s2,0x4
    80003158:	018a2783          	lw	a5,24(s4)
    8000315c:	9dbd                	addw	a1,a1,a5
    8000315e:	8556                	mv	a0,s5
    80003160:	a9dff0ef          	jal	80002bfc <bread>
    80003164:	84aa                	mv	s1,a0
    dip = (struct dinode *)bp->data + inum % IPB;
    80003166:	05850993          	addi	s3,a0,88
    8000316a:	00f97793          	andi	a5,s2,15
    8000316e:	079a                	slli	a5,a5,0x6
    80003170:	99be                	add	s3,s3,a5
    if (dip->type == 0) { // a free inode
    80003172:	00099783          	lh	a5,0(s3)
    80003176:	cb9d                	beqz	a5,800031ac <ialloc+0x88>
    brelse(bp);
    80003178:	b8dff0ef          	jal	80002d04 <brelse>
  for (inum = 1; inum < sb.ninodes; inum++) {
    8000317c:	0905                	addi	s2,s2,1
    8000317e:	00ca2703          	lw	a4,12(s4)
    80003182:	0009079b          	sext.w	a5,s2
    80003186:	fce7e7e3          	bltu	a5,a4,80003154 <ialloc+0x30>
    8000318a:	74a2                	ld	s1,40(sp)
    8000318c:	7902                	ld	s2,32(sp)
    8000318e:	69e2                	ld	s3,24(sp)
    80003190:	6a42                	ld	s4,16(sp)
    80003192:	6aa2                	ld	s5,8(sp)
    80003194:	6b02                	ld	s6,0(sp)
  printk("ialloc: no inodes\n");
    80003196:	00004517          	auipc	a0,0x4
    8000319a:	2d250513          	addi	a0,a0,722 # 80007468 <etext+0x468>
    8000319e:	b6cfd0ef          	jal	8000050a <printk>
  return 0;
    800031a2:	4501                	li	a0,0
}
    800031a4:	70e2                	ld	ra,56(sp)
    800031a6:	7442                	ld	s0,48(sp)
    800031a8:	6121                	addi	sp,sp,64
    800031aa:	8082                	ret
      memset(dip, 0, sizeof(*dip));
    800031ac:	04000613          	li	a2,64
    800031b0:	4581                	li	a1,0
    800031b2:	854e                	mv	a0,s3
    800031b4:	af5fd0ef          	jal	80000ca8 <memset>
      dip->type = type;
    800031b8:	01699023          	sh	s6,0(s3)
      log_write(bp); // mark it allocated on the disk
    800031bc:	8526                	mv	a0,s1
    800031be:	4fd000ef          	jal	80003eba <log_write>
      brelse(bp);
    800031c2:	8526                	mv	a0,s1
    800031c4:	b41ff0ef          	jal	80002d04 <brelse>
      return iget(dev, inum);
    800031c8:	0009059b          	sext.w	a1,s2
    800031cc:	8556                	mv	a0,s5
    800031ce:	e55ff0ef          	jal	80003022 <iget>
    800031d2:	74a2                	ld	s1,40(sp)
    800031d4:	7902                	ld	s2,32(sp)
    800031d6:	69e2                	ld	s3,24(sp)
    800031d8:	6a42                	ld	s4,16(sp)
    800031da:	6aa2                	ld	s5,8(sp)
    800031dc:	6b02                	ld	s6,0(sp)
    800031de:	b7d9                	j	800031a4 <ialloc+0x80>

00000000800031e0 <iupdate>:
{
    800031e0:	1101                	addi	sp,sp,-32
    800031e2:	ec06                	sd	ra,24(sp)
    800031e4:	e822                	sd	s0,16(sp)
    800031e6:	e426                	sd	s1,8(sp)
    800031e8:	e04a                	sd	s2,0(sp)
    800031ea:	1000                	addi	s0,sp,32
    800031ec:	84aa                	mv	s1,a0
  bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    800031ee:	415c                	lw	a5,4(a0)
    800031f0:	0047d79b          	srliw	a5,a5,0x4
    800031f4:	0001d597          	auipc	a1,0x1d
    800031f8:	76c5a583          	lw	a1,1900(a1) # 80020960 <sb+0x18>
    800031fc:	9dbd                	addw	a1,a1,a5
    800031fe:	4108                	lw	a0,0(a0)
    80003200:	9fdff0ef          	jal	80002bfc <bread>
    80003204:	892a                	mv	s2,a0
  dip = (struct dinode *)bp->data + ip->inum % IPB;
    80003206:	05850793          	addi	a5,a0,88
    8000320a:	40d8                	lw	a4,4(s1)
    8000320c:	8b3d                	andi	a4,a4,15
    8000320e:	071a                	slli	a4,a4,0x6
    80003210:	97ba                	add	a5,a5,a4
  dip->type = ip->type;
    80003212:	04449703          	lh	a4,68(s1)
    80003216:	00e79023          	sh	a4,0(a5)
  dip->major = ip->major;
    8000321a:	04649703          	lh	a4,70(s1)
    8000321e:	00e79123          	sh	a4,2(a5)
  dip->minor = ip->minor;
    80003222:	04849703          	lh	a4,72(s1)
    80003226:	00e79223          	sh	a4,4(a5)
  dip->nlink = ip->nlink;
    8000322a:	04a49703          	lh	a4,74(s1)
    8000322e:	00e79323          	sh	a4,6(a5)
  dip->size = ip->size;
    80003232:	44f8                	lw	a4,76(s1)
    80003234:	c798                	sw	a4,8(a5)
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
    80003236:	03400613          	li	a2,52
    8000323a:	05048593          	addi	a1,s1,80
    8000323e:	00c78513          	addi	a0,a5,12
    80003242:	ac7fd0ef          	jal	80000d08 <memmove>
  log_write(bp);
    80003246:	854a                	mv	a0,s2
    80003248:	473000ef          	jal	80003eba <log_write>
  brelse(bp);
    8000324c:	854a                	mv	a0,s2
    8000324e:	ab7ff0ef          	jal	80002d04 <brelse>
}
    80003252:	60e2                	ld	ra,24(sp)
    80003254:	6442                	ld	s0,16(sp)
    80003256:	64a2                	ld	s1,8(sp)
    80003258:	6902                	ld	s2,0(sp)
    8000325a:	6105                	addi	sp,sp,32
    8000325c:	8082                	ret

000000008000325e <idup>:
{
    8000325e:	1101                	addi	sp,sp,-32
    80003260:	ec06                	sd	ra,24(sp)
    80003262:	e822                	sd	s0,16(sp)
    80003264:	e426                	sd	s1,8(sp)
    80003266:	1000                	addi	s0,sp,32
    80003268:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    8000326a:	0001d517          	auipc	a0,0x1d
    8000326e:	6fe50513          	addi	a0,a0,1790 # 80020968 <itable>
    80003272:	977fd0ef          	jal	80000be8 <acquire>
  ip->ref++;
    80003276:	449c                	lw	a5,8(s1)
    80003278:	2785                	addiw	a5,a5,1
    8000327a:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    8000327c:	0001d517          	auipc	a0,0x1d
    80003280:	6ec50513          	addi	a0,a0,1772 # 80020968 <itable>
    80003284:	9edfd0ef          	jal	80000c70 <release>
}
    80003288:	8526                	mv	a0,s1
    8000328a:	60e2                	ld	ra,24(sp)
    8000328c:	6442                	ld	s0,16(sp)
    8000328e:	64a2                	ld	s1,8(sp)
    80003290:	6105                	addi	sp,sp,32
    80003292:	8082                	ret

0000000080003294 <ilock>:
{
    80003294:	1101                	addi	sp,sp,-32
    80003296:	ec06                	sd	ra,24(sp)
    80003298:	e822                	sd	s0,16(sp)
    8000329a:	e426                	sd	s1,8(sp)
    8000329c:	1000                	addi	s0,sp,32
  if (ip == 0 || ip->ref < 1)
    8000329e:	cd19                	beqz	a0,800032bc <ilock+0x28>
    800032a0:	84aa                	mv	s1,a0
    800032a2:	451c                	lw	a5,8(a0)
    800032a4:	00f05c63          	blez	a5,800032bc <ilock+0x28>
  acquiresleep(&ip->lock);
    800032a8:	0541                	addi	a0,a0,16
    800032aa:	57f000ef          	jal	80004028 <acquiresleep>
  if (ip->valid == 0) {
    800032ae:	40bc                	lw	a5,64(s1)
    800032b0:	cf89                	beqz	a5,800032ca <ilock+0x36>
}
    800032b2:	60e2                	ld	ra,24(sp)
    800032b4:	6442                	ld	s0,16(sp)
    800032b6:	64a2                	ld	s1,8(sp)
    800032b8:	6105                	addi	sp,sp,32
    800032ba:	8082                	ret
    800032bc:	e04a                	sd	s2,0(sp)
    panic("ilock");
    800032be:	00004517          	auipc	a0,0x4
    800032c2:	1c250513          	addi	a0,a0,450 # 80007480 <etext+0x480>
    800032c6:	d6efd0ef          	jal	80000834 <panic>
    800032ca:	e04a                	sd	s2,0(sp)
    bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    800032cc:	40dc                	lw	a5,4(s1)
    800032ce:	0047d79b          	srliw	a5,a5,0x4
    800032d2:	0001d597          	auipc	a1,0x1d
    800032d6:	68e5a583          	lw	a1,1678(a1) # 80020960 <sb+0x18>
    800032da:	9dbd                	addw	a1,a1,a5
    800032dc:	4088                	lw	a0,0(s1)
    800032de:	91fff0ef          	jal	80002bfc <bread>
    800032e2:	892a                	mv	s2,a0
    dip = (struct dinode *)bp->data + ip->inum % IPB;
    800032e4:	05850593          	addi	a1,a0,88
    800032e8:	40dc                	lw	a5,4(s1)
    800032ea:	8bbd                	andi	a5,a5,15
    800032ec:	079a                	slli	a5,a5,0x6
    800032ee:	95be                	add	a1,a1,a5
    ip->type = dip->type;
    800032f0:	00059783          	lh	a5,0(a1)
    800032f4:	04f49223          	sh	a5,68(s1)
    ip->major = dip->major;
    800032f8:	00259783          	lh	a5,2(a1)
    800032fc:	04f49323          	sh	a5,70(s1)
    ip->minor = dip->minor;
    80003300:	00459783          	lh	a5,4(a1)
    80003304:	04f49423          	sh	a5,72(s1)
    ip->nlink = dip->nlink;
    80003308:	00659783          	lh	a5,6(a1)
    8000330c:	04f49523          	sh	a5,74(s1)
    ip->size = dip->size;
    80003310:	459c                	lw	a5,8(a1)
    80003312:	c4fc                	sw	a5,76(s1)
    memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
    80003314:	03400613          	li	a2,52
    80003318:	05b1                	addi	a1,a1,12
    8000331a:	05048513          	addi	a0,s1,80
    8000331e:	9ebfd0ef          	jal	80000d08 <memmove>
    brelse(bp);
    80003322:	854a                	mv	a0,s2
    80003324:	9e1ff0ef          	jal	80002d04 <brelse>
    ip->valid = 1;
    80003328:	4785                	li	a5,1
    8000332a:	c0bc                	sw	a5,64(s1)
    if (ip->type == 0)
    8000332c:	04449783          	lh	a5,68(s1)
    80003330:	c399                	beqz	a5,80003336 <ilock+0xa2>
    80003332:	6902                	ld	s2,0(sp)
    80003334:	bfbd                	j	800032b2 <ilock+0x1e>
      panic("ilock: no type");
    80003336:	00004517          	auipc	a0,0x4
    8000333a:	15250513          	addi	a0,a0,338 # 80007488 <etext+0x488>
    8000333e:	cf6fd0ef          	jal	80000834 <panic>

0000000080003342 <iunlock>:
{
    80003342:	1101                	addi	sp,sp,-32
    80003344:	ec06                	sd	ra,24(sp)
    80003346:	e822                	sd	s0,16(sp)
    80003348:	e426                	sd	s1,8(sp)
    8000334a:	e04a                	sd	s2,0(sp)
    8000334c:	1000                	addi	s0,sp,32
  if (ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
    8000334e:	c505                	beqz	a0,80003376 <iunlock+0x34>
    80003350:	84aa                	mv	s1,a0
    80003352:	01050913          	addi	s2,a0,16
    80003356:	854a                	mv	a0,s2
    80003358:	55d000ef          	jal	800040b4 <holdingsleep>
    8000335c:	cd09                	beqz	a0,80003376 <iunlock+0x34>
    8000335e:	449c                	lw	a5,8(s1)
    80003360:	00f05b63          	blez	a5,80003376 <iunlock+0x34>
  releasesleep(&ip->lock);
    80003364:	854a                	mv	a0,s2
    80003366:	517000ef          	jal	8000407c <releasesleep>
}
    8000336a:	60e2                	ld	ra,24(sp)
    8000336c:	6442                	ld	s0,16(sp)
    8000336e:	64a2                	ld	s1,8(sp)
    80003370:	6902                	ld	s2,0(sp)
    80003372:	6105                	addi	sp,sp,32
    80003374:	8082                	ret
    panic("iunlock");
    80003376:	00004517          	auipc	a0,0x4
    8000337a:	12250513          	addi	a0,a0,290 # 80007498 <etext+0x498>
    8000337e:	cb6fd0ef          	jal	80000834 <panic>

0000000080003382 <itrunc>:

// Truncate inode (discard contents).
// Caller must hold ip->lock.
void
itrunc(struct inode *ip)
{
    80003382:	7179                	addi	sp,sp,-48
    80003384:	f406                	sd	ra,40(sp)
    80003386:	f022                	sd	s0,32(sp)
    80003388:	ec26                	sd	s1,24(sp)
    8000338a:	e84a                	sd	s2,16(sp)
    8000338c:	e44e                	sd	s3,8(sp)
    8000338e:	1800                	addi	s0,sp,48
    80003390:	89aa                	mv	s3,a0
  int i, j;
  struct buf *bp;
  uint *a;

  for (i = 0; i < NDIRECT; i++) {
    80003392:	05050493          	addi	s1,a0,80
    80003396:	08050913          	addi	s2,a0,128
    8000339a:	a021                	j	800033a2 <itrunc+0x20>
    8000339c:	0491                	addi	s1,s1,4
    8000339e:	01248b63          	beq	s1,s2,800033b4 <itrunc+0x32>
    if (ip->addrs[i]) {
    800033a2:	408c                	lw	a1,0(s1)
    800033a4:	dde5                	beqz	a1,8000339c <itrunc+0x1a>
      bfree(ip->dev, ip->addrs[i]);
    800033a6:	0009a503          	lw	a0,0(s3)
    800033aa:	a47ff0ef          	jal	80002df0 <bfree>
      ip->addrs[i] = 0;
    800033ae:	0004a023          	sw	zero,0(s1)
    800033b2:	b7ed                	j	8000339c <itrunc+0x1a>
    }
  }

  if (ip->addrs[NDIRECT]) {
    800033b4:	0809a583          	lw	a1,128(s3)
    800033b8:	ed89                	bnez	a1,800033d2 <itrunc+0x50>
    brelse(bp);
    bfree(ip->dev, ip->addrs[NDIRECT]);
    ip->addrs[NDIRECT] = 0;
  }

  ip->size = 0;
    800033ba:	0409a623          	sw	zero,76(s3)
  iupdate(ip);
    800033be:	854e                	mv	a0,s3
    800033c0:	e21ff0ef          	jal	800031e0 <iupdate>
}
    800033c4:	70a2                	ld	ra,40(sp)
    800033c6:	7402                	ld	s0,32(sp)
    800033c8:	64e2                	ld	s1,24(sp)
    800033ca:	6942                	ld	s2,16(sp)
    800033cc:	69a2                	ld	s3,8(sp)
    800033ce:	6145                	addi	sp,sp,48
    800033d0:	8082                	ret
    800033d2:	e052                	sd	s4,0(sp)
    bp = bread(ip->dev, ip->addrs[NDIRECT]);
    800033d4:	0009a503          	lw	a0,0(s3)
    800033d8:	825ff0ef          	jal	80002bfc <bread>
    800033dc:	8a2a                	mv	s4,a0
    for (j = 0; j < NINDIRECT; j++) {
    800033de:	05850493          	addi	s1,a0,88
    800033e2:	45850913          	addi	s2,a0,1112
    800033e6:	a021                	j	800033ee <itrunc+0x6c>
    800033e8:	0491                	addi	s1,s1,4
    800033ea:	01248963          	beq	s1,s2,800033fc <itrunc+0x7a>
      if (a[j])
    800033ee:	408c                	lw	a1,0(s1)
    800033f0:	dde5                	beqz	a1,800033e8 <itrunc+0x66>
        bfree(ip->dev, a[j]);
    800033f2:	0009a503          	lw	a0,0(s3)
    800033f6:	9fbff0ef          	jal	80002df0 <bfree>
    800033fa:	b7fd                	j	800033e8 <itrunc+0x66>
    brelse(bp);
    800033fc:	8552                	mv	a0,s4
    800033fe:	907ff0ef          	jal	80002d04 <brelse>
    bfree(ip->dev, ip->addrs[NDIRECT]);
    80003402:	0809a583          	lw	a1,128(s3)
    80003406:	0009a503          	lw	a0,0(s3)
    8000340a:	9e7ff0ef          	jal	80002df0 <bfree>
    ip->addrs[NDIRECT] = 0;
    8000340e:	0809a023          	sw	zero,128(s3)
    80003412:	6a02                	ld	s4,0(sp)
    80003414:	b75d                	j	800033ba <itrunc+0x38>

0000000080003416 <iput>:
{
    80003416:	7179                	addi	sp,sp,-48
    80003418:	f406                	sd	ra,40(sp)
    8000341a:	f022                	sd	s0,32(sp)
    8000341c:	ec26                	sd	s1,24(sp)
    8000341e:	1800                	addi	s0,sp,48
    80003420:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    80003422:	0001d517          	auipc	a0,0x1d
    80003426:	54650513          	addi	a0,a0,1350 # 80020968 <itable>
    8000342a:	fbefd0ef          	jal	80000be8 <acquire>
  int last = (ip->ref == 1 && ip->valid && ip->nlink == 0);
    8000342e:	449c                	lw	a5,8(s1)
    80003430:	4705                	li	a4,1
    80003432:	00e78f63          	beq	a5,a4,80003450 <iput+0x3a>
  ip->ref--;
    80003436:	37fd                	addiw	a5,a5,-1
    80003438:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    8000343a:	0001d517          	auipc	a0,0x1d
    8000343e:	52e50513          	addi	a0,a0,1326 # 80020968 <itable>
    80003442:	82ffd0ef          	jal	80000c70 <release>
}
    80003446:	70a2                	ld	ra,40(sp)
    80003448:	7402                	ld	s0,32(sp)
    8000344a:	64e2                	ld	s1,24(sp)
    8000344c:	6145                	addi	sp,sp,48
    8000344e:	8082                	ret
  int last = (ip->ref == 1 && ip->valid && ip->nlink == 0);
    80003450:	40b8                	lw	a4,64(s1)
    80003452:	d375                	beqz	a4,80003436 <iput+0x20>
    80003454:	e84a                	sd	s2,16(sp)
    80003456:	e052                	sd	s4,0(sp)
  uint dev = ip->dev, inum = ip->inum;
    80003458:	0004aa03          	lw	s4,0(s1)
    8000345c:	0044a903          	lw	s2,4(s1)
  if (last) {
    80003460:	04a49703          	lh	a4,74(s1)
    80003464:	ef3d                	bnez	a4,800034e2 <iput+0xcc>
    80003466:	e44e                	sd	s3,8(sp)
    acquiresleep(&ip->lock);
    80003468:	01048793          	addi	a5,s1,16
    8000346c:	89be                	mv	s3,a5
    8000346e:	853e                	mv	a0,a5
    80003470:	3b9000ef          	jal	80004028 <acquiresleep>
    release(&itable.lock);
    80003474:	0001d517          	auipc	a0,0x1d
    80003478:	4f450513          	addi	a0,a0,1268 # 80020968 <itable>
    8000347c:	ff4fd0ef          	jal	80000c70 <release>
    itrunc(ip); // free the data blocks (type stays nonzero on disk)
    80003480:	8526                	mv	a0,s1
    80003482:	f01ff0ef          	jal	80003382 <itrunc>
    ip->valid = 0;
    80003486:	0404a023          	sw	zero,64(s1)
    releasesleep(&ip->lock);
    8000348a:	854e                	mv	a0,s3
    8000348c:	3f1000ef          	jal	8000407c <releasesleep>
    acquire(&itable.lock);
    80003490:	0001d517          	auipc	a0,0x1d
    80003494:	4d850513          	addi	a0,a0,1240 # 80020968 <itable>
    80003498:	f50fd0ef          	jal	80000be8 <acquire>
  ip->ref--;
    8000349c:	449c                	lw	a5,8(s1)
    8000349e:	37fd                	addiw	a5,a5,-1
    800034a0:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    800034a2:	0001d517          	auipc	a0,0x1d
    800034a6:	4c650513          	addi	a0,a0,1222 # 80020968 <itable>
    800034aa:	fc6fd0ef          	jal	80000c70 <release>
  struct buf *bp = bread(dev, IBLOCK(inum, sb));
    800034ae:	0049579b          	srliw	a5,s2,0x4
    800034b2:	0001d597          	auipc	a1,0x1d
    800034b6:	4ae5a583          	lw	a1,1198(a1) # 80020960 <sb+0x18>
    800034ba:	9dbd                	addw	a1,a1,a5
    800034bc:	8552                	mv	a0,s4
    800034be:	f3eff0ef          	jal	80002bfc <bread>
    800034c2:	84aa                	mv	s1,a0
  struct dinode *dip = (struct dinode *)bp->data + inum % IPB;
    800034c4:	00f97793          	andi	a5,s2,15
  dip->type = 0;
    800034c8:	079a                	slli	a5,a5,0x6
    800034ca:	97aa                	add	a5,a5,a0
    800034cc:	04079c23          	sh	zero,88(a5)
  log_write(bp);
    800034d0:	1eb000ef          	jal	80003eba <log_write>
  brelse(bp);
    800034d4:	8526                	mv	a0,s1
    800034d6:	82fff0ef          	jal	80002d04 <brelse>
}
    800034da:	6942                	ld	s2,16(sp)
    800034dc:	69a2                	ld	s3,8(sp)
    800034de:	6a02                	ld	s4,0(sp)
    800034e0:	b79d                	j	80003446 <iput+0x30>
    800034e2:	6942                	ld	s2,16(sp)
    800034e4:	6a02                	ld	s4,0(sp)
    800034e6:	bf81                	j	80003436 <iput+0x20>

00000000800034e8 <iunlockput>:
{
    800034e8:	1101                	addi	sp,sp,-32
    800034ea:	ec06                	sd	ra,24(sp)
    800034ec:	e822                	sd	s0,16(sp)
    800034ee:	e426                	sd	s1,8(sp)
    800034f0:	1000                	addi	s0,sp,32
    800034f2:	84aa                	mv	s1,a0
  iunlock(ip);
    800034f4:	e4fff0ef          	jal	80003342 <iunlock>
  iput(ip);
    800034f8:	8526                	mv	a0,s1
    800034fa:	f1dff0ef          	jal	80003416 <iput>
}
    800034fe:	60e2                	ld	ra,24(sp)
    80003500:	6442                	ld	s0,16(sp)
    80003502:	64a2                	ld	s1,8(sp)
    80003504:	6105                	addi	sp,sp,32
    80003506:	8082                	ret

0000000080003508 <ireclaim>:
  for (int inum = 1; inum < sb.ninodes; inum++) {
    80003508:	0001d717          	auipc	a4,0x1d
    8000350c:	44c72703          	lw	a4,1100(a4) # 80020954 <sb+0xc>
    80003510:	4785                	li	a5,1
    80003512:	0ae7fe63          	bgeu	a5,a4,800035ce <ireclaim+0xc6>
{
    80003516:	7139                	addi	sp,sp,-64
    80003518:	fc06                	sd	ra,56(sp)
    8000351a:	f822                	sd	s0,48(sp)
    8000351c:	f426                	sd	s1,40(sp)
    8000351e:	f04a                	sd	s2,32(sp)
    80003520:	ec4e                	sd	s3,24(sp)
    80003522:	e852                	sd	s4,16(sp)
    80003524:	e456                	sd	s5,8(sp)
    80003526:	e05a                	sd	s6,0(sp)
    80003528:	0080                	addi	s0,sp,64
    8000352a:	8aaa                	mv	s5,a0
  for (int inum = 1; inum < sb.ninodes; inum++) {
    8000352c:	84be                	mv	s1,a5
    struct buf *bp = bread(dev, IBLOCK(inum, sb));
    8000352e:	0001da17          	auipc	s4,0x1d
    80003532:	41aa0a13          	addi	s4,s4,1050 # 80020948 <sb>
      printk("ireclaim: orphaned inode %d\n", inum);
    80003536:	00004b17          	auipc	s6,0x4
    8000353a:	f6ab0b13          	addi	s6,s6,-150 # 800074a0 <etext+0x4a0>
    8000353e:	a099                	j	80003584 <ireclaim+0x7c>
    80003540:	85ce                	mv	a1,s3
    80003542:	855a                	mv	a0,s6
    80003544:	fc7fc0ef          	jal	8000050a <printk>
      ip = iget(dev, inum);
    80003548:	85ce                	mv	a1,s3
    8000354a:	8556                	mv	a0,s5
    8000354c:	ad7ff0ef          	jal	80003022 <iget>
    80003550:	89aa                	mv	s3,a0
    brelse(bp);
    80003552:	854a                	mv	a0,s2
    80003554:	fb0ff0ef          	jal	80002d04 <brelse>
    if (ip) {
    80003558:	00098f63          	beqz	s3,80003576 <ireclaim+0x6e>
      begin_op();
    8000355c:	7b0000ef          	jal	80003d0c <begin_op>
      ilock(ip);
    80003560:	854e                	mv	a0,s3
    80003562:	d33ff0ef          	jal	80003294 <ilock>
      iunlock(ip);
    80003566:	854e                	mv	a0,s3
    80003568:	ddbff0ef          	jal	80003342 <iunlock>
      iput(ip);
    8000356c:	854e                	mv	a0,s3
    8000356e:	ea9ff0ef          	jal	80003416 <iput>
      end_op();
    80003572:	027000ef          	jal	80003d98 <end_op>
  for (int inum = 1; inum < sb.ninodes; inum++) {
    80003576:	0485                	addi	s1,s1,1
    80003578:	00ca2703          	lw	a4,12(s4)
    8000357c:	0004879b          	sext.w	a5,s1
    80003580:	02e7fd63          	bgeu	a5,a4,800035ba <ireclaim+0xb2>
    80003584:	0004899b          	sext.w	s3,s1
    struct buf *bp = bread(dev, IBLOCK(inum, sb));
    80003588:	0044d593          	srli	a1,s1,0x4
    8000358c:	018a2783          	lw	a5,24(s4)
    80003590:	9dbd                	addw	a1,a1,a5
    80003592:	8556                	mv	a0,s5
    80003594:	e68ff0ef          	jal	80002bfc <bread>
    80003598:	892a                	mv	s2,a0
    struct dinode *dip = (struct dinode *)bp->data + inum % IPB;
    8000359a:	05850793          	addi	a5,a0,88
    8000359e:	00f9f713          	andi	a4,s3,15
    800035a2:	071a                	slli	a4,a4,0x6
    800035a4:	97ba                	add	a5,a5,a4
    if (dip->type != 0 && dip->nlink == 0) { // is an orphaned inode
    800035a6:	00079703          	lh	a4,0(a5)
    800035aa:	c701                	beqz	a4,800035b2 <ireclaim+0xaa>
    800035ac:	00679783          	lh	a5,6(a5)
    800035b0:	dbc1                	beqz	a5,80003540 <ireclaim+0x38>
    brelse(bp);
    800035b2:	854a                	mv	a0,s2
    800035b4:	f50ff0ef          	jal	80002d04 <brelse>
    if (ip) {
    800035b8:	bf7d                	j	80003576 <ireclaim+0x6e>
}
    800035ba:	70e2                	ld	ra,56(sp)
    800035bc:	7442                	ld	s0,48(sp)
    800035be:	74a2                	ld	s1,40(sp)
    800035c0:	7902                	ld	s2,32(sp)
    800035c2:	69e2                	ld	s3,24(sp)
    800035c4:	6a42                	ld	s4,16(sp)
    800035c6:	6aa2                	ld	s5,8(sp)
    800035c8:	6b02                	ld	s6,0(sp)
    800035ca:	6121                	addi	sp,sp,64
    800035cc:	8082                	ret
    800035ce:	8082                	ret

00000000800035d0 <fsinit>:
{
    800035d0:	1101                	addi	sp,sp,-32
    800035d2:	ec06                	sd	ra,24(sp)
    800035d4:	e822                	sd	s0,16(sp)
    800035d6:	e426                	sd	s1,8(sp)
    800035d8:	e04a                	sd	s2,0(sp)
    800035da:	1000                	addi	s0,sp,32
    800035dc:	892a                	mv	s2,a0
  bp = bread(dev, 1);
    800035de:	4585                	li	a1,1
    800035e0:	e1cff0ef          	jal	80002bfc <bread>
    800035e4:	84aa                	mv	s1,a0
  memmove(sb, bp->data, sizeof(*sb));
    800035e6:	02000613          	li	a2,32
    800035ea:	05850593          	addi	a1,a0,88
    800035ee:	0001d517          	auipc	a0,0x1d
    800035f2:	35a50513          	addi	a0,a0,858 # 80020948 <sb>
    800035f6:	f12fd0ef          	jal	80000d08 <memmove>
  brelse(bp);
    800035fa:	8526                	mv	a0,s1
    800035fc:	f08ff0ef          	jal	80002d04 <brelse>
  if (sb.magic != FSMAGIC)
    80003600:	0001d717          	auipc	a4,0x1d
    80003604:	34872703          	lw	a4,840(a4) # 80020948 <sb>
    80003608:	102037b7          	lui	a5,0x10203
    8000360c:	04078793          	addi	a5,a5,64 # 10203040 <_entry-0x6fdfcfc0>
    80003610:	02f71263          	bne	a4,a5,80003634 <fsinit+0x64>
  initlog(dev, &sb);
    80003614:	0001d597          	auipc	a1,0x1d
    80003618:	33458593          	addi	a1,a1,820 # 80020948 <sb>
    8000361c:	854a                	mv	a0,s2
    8000361e:	66c000ef          	jal	80003c8a <initlog>
  ireclaim(dev);
    80003622:	854a                	mv	a0,s2
    80003624:	ee5ff0ef          	jal	80003508 <ireclaim>
}
    80003628:	60e2                	ld	ra,24(sp)
    8000362a:	6442                	ld	s0,16(sp)
    8000362c:	64a2                	ld	s1,8(sp)
    8000362e:	6902                	ld	s2,0(sp)
    80003630:	6105                	addi	sp,sp,32
    80003632:	8082                	ret
    panic("invalid file system");
    80003634:	00004517          	auipc	a0,0x4
    80003638:	e8c50513          	addi	a0,a0,-372 # 800074c0 <etext+0x4c0>
    8000363c:	9f8fd0ef          	jal	80000834 <panic>

0000000080003640 <stati>:

// Copy stat information from inode.
// Caller must hold ip->lock.
void
stati(struct inode *ip, struct stat *st)
{
    80003640:	1141                	addi	sp,sp,-16
    80003642:	e406                	sd	ra,8(sp)
    80003644:	e022                	sd	s0,0(sp)
    80003646:	0800                	addi	s0,sp,16
  st->dev = ip->dev;
    80003648:	411c                	lw	a5,0(a0)
    8000364a:	c19c                	sw	a5,0(a1)
  st->ino = ip->inum;
    8000364c:	415c                	lw	a5,4(a0)
    8000364e:	c1dc                	sw	a5,4(a1)
  st->type = ip->type;
    80003650:	04451783          	lh	a5,68(a0)
    80003654:	00f59423          	sh	a5,8(a1)
  st->nlink = ip->nlink;
    80003658:	04a51783          	lh	a5,74(a0)
    8000365c:	00f59523          	sh	a5,10(a1)
  st->size = ip->size;
    80003660:	04c56783          	lwu	a5,76(a0)
    80003664:	e99c                	sd	a5,16(a1)
}
    80003666:	60a2                	ld	ra,8(sp)
    80003668:	6402                	ld	s0,0(sp)
    8000366a:	0141                	addi	sp,sp,16
    8000366c:	8082                	ret

000000008000366e <readi>:
readi(struct inode *ip, int user_dst, uint64 dst, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if (off > ip->size || off + n < off)
    8000366e:	457c                	lw	a5,76(a0)
    80003670:	0ed7e663          	bltu	a5,a3,8000375c <readi+0xee>
{
    80003674:	7159                	addi	sp,sp,-112
    80003676:	f486                	sd	ra,104(sp)
    80003678:	f0a2                	sd	s0,96(sp)
    8000367a:	eca6                	sd	s1,88(sp)
    8000367c:	e0d2                	sd	s4,64(sp)
    8000367e:	fc56                	sd	s5,56(sp)
    80003680:	f85a                	sd	s6,48(sp)
    80003682:	f45e                	sd	s7,40(sp)
    80003684:	1880                	addi	s0,sp,112
    80003686:	8b2a                	mv	s6,a0
    80003688:	8bae                	mv	s7,a1
    8000368a:	8a32                	mv	s4,a2
    8000368c:	84b6                	mv	s1,a3
    8000368e:	8aba                	mv	s5,a4
  if (off > ip->size || off + n < off)
    80003690:	9f35                	addw	a4,a4,a3
    return 0;
    80003692:	4501                	li	a0,0
  if (off > ip->size || off + n < off)
    80003694:	0ad76b63          	bltu	a4,a3,8000374a <readi+0xdc>
    80003698:	e4ce                	sd	s3,72(sp)
  if (off + n > ip->size)
    8000369a:	00e7f463          	bgeu	a5,a4,800036a2 <readi+0x34>
    n = ip->size - off;
    8000369e:	40d78abb          	subw	s5,a5,a3

  for (tot = 0; tot < n; tot += m, off += m, dst += m) {
    800036a2:	080a8b63          	beqz	s5,80003738 <readi+0xca>
    800036a6:	e8ca                	sd	s2,80(sp)
    800036a8:	f062                	sd	s8,32(sp)
    800036aa:	ec66                	sd	s9,24(sp)
    800036ac:	e86a                	sd	s10,16(sp)
    800036ae:	e46e                	sd	s11,8(sp)
    800036b0:	4981                	li	s3,0
    uint addr = bmap(ip, off / BSIZE);
    if (addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off % BSIZE);
    800036b2:	40000c93          	li	s9,1024
    if (either_copyout(user_dst, dst, bp->data + (off % BSIZE), m) == -1) {
    800036b6:	5c7d                	li	s8,-1
    800036b8:	a80d                	j	800036ea <readi+0x7c>
    800036ba:	020d1d93          	slli	s11,s10,0x20
    800036be:	020ddd93          	srli	s11,s11,0x20
    800036c2:	05890613          	addi	a2,s2,88
    800036c6:	86ee                	mv	a3,s11
    800036c8:	963e                	add	a2,a2,a5
    800036ca:	85d2                	mv	a1,s4
    800036cc:	855e                	mv	a0,s7
    800036ce:	bd7fe0ef          	jal	800022a4 <either_copyout>
    800036d2:	05850363          	beq	a0,s8,80003718 <readi+0xaa>
      brelse(bp);
      tot = -1;
      break;
    }
    brelse(bp);
    800036d6:	854a                	mv	a0,s2
    800036d8:	e2cff0ef          	jal	80002d04 <brelse>
  for (tot = 0; tot < n; tot += m, off += m, dst += m) {
    800036dc:	013d09bb          	addw	s3,s10,s3
    800036e0:	009d04bb          	addw	s1,s10,s1
    800036e4:	9a6e                	add	s4,s4,s11
    800036e6:	0559f363          	bgeu	s3,s5,8000372c <readi+0xbe>
    uint addr = bmap(ip, off / BSIZE);
    800036ea:	00a4d59b          	srliw	a1,s1,0xa
    800036ee:	855a                	mv	a0,s6
    800036f0:	873ff0ef          	jal	80002f62 <bmap>
    800036f4:	85aa                	mv	a1,a0
    if (addr == 0)
    800036f6:	c139                	beqz	a0,8000373c <readi+0xce>
    bp = bread(ip->dev, addr);
    800036f8:	000b2503          	lw	a0,0(s6)
    800036fc:	d00ff0ef          	jal	80002bfc <bread>
    80003700:	892a                	mv	s2,a0
    m = min(n - tot, BSIZE - off % BSIZE);
    80003702:	3ff4f793          	andi	a5,s1,1023
    80003706:	40fc873b          	subw	a4,s9,a5
    8000370a:	413a86bb          	subw	a3,s5,s3
    8000370e:	8d3a                	mv	s10,a4
    80003710:	fae6f5e3          	bgeu	a3,a4,800036ba <readi+0x4c>
    80003714:	8d36                	mv	s10,a3
    80003716:	b755                	j	800036ba <readi+0x4c>
      brelse(bp);
    80003718:	854a                	mv	a0,s2
    8000371a:	deaff0ef          	jal	80002d04 <brelse>
      tot = -1;
    8000371e:	59fd                	li	s3,-1
      break;
    80003720:	6946                	ld	s2,80(sp)
    80003722:	7c02                	ld	s8,32(sp)
    80003724:	6ce2                	ld	s9,24(sp)
    80003726:	6d42                	ld	s10,16(sp)
    80003728:	6da2                	ld	s11,8(sp)
    8000372a:	a831                	j	80003746 <readi+0xd8>
    8000372c:	6946                	ld	s2,80(sp)
    8000372e:	7c02                	ld	s8,32(sp)
    80003730:	6ce2                	ld	s9,24(sp)
    80003732:	6d42                	ld	s10,16(sp)
    80003734:	6da2                	ld	s11,8(sp)
    80003736:	a801                	j	80003746 <readi+0xd8>
  for (tot = 0; tot < n; tot += m, off += m, dst += m) {
    80003738:	89d6                	mv	s3,s5
    8000373a:	a031                	j	80003746 <readi+0xd8>
    8000373c:	6946                	ld	s2,80(sp)
    8000373e:	7c02                	ld	s8,32(sp)
    80003740:	6ce2                	ld	s9,24(sp)
    80003742:	6d42                	ld	s10,16(sp)
    80003744:	6da2                	ld	s11,8(sp)
  }
  return tot;
    80003746:	854e                	mv	a0,s3
    80003748:	69a6                	ld	s3,72(sp)
}
    8000374a:	70a6                	ld	ra,104(sp)
    8000374c:	7406                	ld	s0,96(sp)
    8000374e:	64e6                	ld	s1,88(sp)
    80003750:	6a06                	ld	s4,64(sp)
    80003752:	7ae2                	ld	s5,56(sp)
    80003754:	7b42                	ld	s6,48(sp)
    80003756:	7ba2                	ld	s7,40(sp)
    80003758:	6165                	addi	sp,sp,112
    8000375a:	8082                	ret
    return 0;
    8000375c:	4501                	li	a0,0
}
    8000375e:	8082                	ret

0000000080003760 <writei>:
writei(struct inode *ip, int user_src, uint64 src, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if (off > ip->size || off + n < off)
    80003760:	457c                	lw	a5,76(a0)
    80003762:	0ed7ee63          	bltu	a5,a3,8000385e <writei+0xfe>
{
    80003766:	7159                	addi	sp,sp,-112
    80003768:	f486                	sd	ra,104(sp)
    8000376a:	f0a2                	sd	s0,96(sp)
    8000376c:	e8ca                	sd	s2,80(sp)
    8000376e:	e0d2                	sd	s4,64(sp)
    80003770:	fc56                	sd	s5,56(sp)
    80003772:	f85a                	sd	s6,48(sp)
    80003774:	f45e                	sd	s7,40(sp)
    80003776:	1880                	addi	s0,sp,112
    80003778:	8aaa                	mv	s5,a0
    8000377a:	8bae                	mv	s7,a1
    8000377c:	8a32                	mv	s4,a2
    8000377e:	8936                	mv	s2,a3
    80003780:	8b3a                	mv	s6,a4
  if (off > ip->size || off + n < off)
    80003782:	00e687bb          	addw	a5,a3,a4
    return -1;
  if (off + n > MAXFILE * BSIZE)
    80003786:	00043737          	lui	a4,0x43
    8000378a:	0cf76c63          	bltu	a4,a5,80003862 <writei+0x102>
    8000378e:	0cd7ea63          	bltu	a5,a3,80003862 <writei+0x102>
    80003792:	e4ce                	sd	s3,72(sp)
    return -1;

  for (tot = 0; tot < n; tot += m, off += m, src += m) {
    80003794:	0a0b0d63          	beqz	s6,8000384e <writei+0xee>
    80003798:	eca6                	sd	s1,88(sp)
    8000379a:	f062                	sd	s8,32(sp)
    8000379c:	ec66                	sd	s9,24(sp)
    8000379e:	e86a                	sd	s10,16(sp)
    800037a0:	e46e                	sd	s11,8(sp)
    800037a2:	4981                	li	s3,0
    uint addr = bmap(ip, off / BSIZE);
    if (addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off % BSIZE);
    800037a4:	40000c93          	li	s9,1024
    if (either_copyin(bp->data + (off % BSIZE), user_src, src, m) == -1) {
    800037a8:	5c7d                	li	s8,-1
    800037aa:	a825                	j	800037e2 <writei+0x82>
    800037ac:	020d1d93          	slli	s11,s10,0x20
    800037b0:	020ddd93          	srli	s11,s11,0x20
    800037b4:	05848513          	addi	a0,s1,88
    800037b8:	86ee                	mv	a3,s11
    800037ba:	8652                	mv	a2,s4
    800037bc:	85de                	mv	a1,s7
    800037be:	953e                	add	a0,a0,a5
    800037c0:	b31fe0ef          	jal	800022f0 <either_copyin>
    800037c4:	05850663          	beq	a0,s8,80003810 <writei+0xb0>
      // Might have partially updated the block, so we need to log it.
      log_write(bp);
      brelse(bp);
      break;
    }
    log_write(bp);
    800037c8:	8526                	mv	a0,s1
    800037ca:	6f0000ef          	jal	80003eba <log_write>
    brelse(bp);
    800037ce:	8526                	mv	a0,s1
    800037d0:	d34ff0ef          	jal	80002d04 <brelse>
  for (tot = 0; tot < n; tot += m, off += m, src += m) {
    800037d4:	013d09bb          	addw	s3,s10,s3
    800037d8:	012d093b          	addw	s2,s10,s2
    800037dc:	9a6e                	add	s4,s4,s11
    800037de:	0369ff63          	bgeu	s3,s6,8000381c <writei+0xbc>
    uint addr = bmap(ip, off / BSIZE);
    800037e2:	00a9559b          	srliw	a1,s2,0xa
    800037e6:	8556                	mv	a0,s5
    800037e8:	f7aff0ef          	jal	80002f62 <bmap>
    800037ec:	85aa                	mv	a1,a0
    if (addr == 0)
    800037ee:	c51d                	beqz	a0,8000381c <writei+0xbc>
    bp = bread(ip->dev, addr);
    800037f0:	000aa503          	lw	a0,0(s5)
    800037f4:	c08ff0ef          	jal	80002bfc <bread>
    800037f8:	84aa                	mv	s1,a0
    m = min(n - tot, BSIZE - off % BSIZE);
    800037fa:	3ff97793          	andi	a5,s2,1023
    800037fe:	40fc873b          	subw	a4,s9,a5
    80003802:	413b06bb          	subw	a3,s6,s3
    80003806:	8d3a                	mv	s10,a4
    80003808:	fae6f2e3          	bgeu	a3,a4,800037ac <writei+0x4c>
    8000380c:	8d36                	mv	s10,a3
    8000380e:	bf79                	j	800037ac <writei+0x4c>
      log_write(bp);
    80003810:	8526                	mv	a0,s1
    80003812:	6a8000ef          	jal	80003eba <log_write>
      brelse(bp);
    80003816:	8526                	mv	a0,s1
    80003818:	cecff0ef          	jal	80002d04 <brelse>
  }

  if (off > ip->size)
    8000381c:	04caa783          	lw	a5,76(s5)
    80003820:	0327f963          	bgeu	a5,s2,80003852 <writei+0xf2>
    ip->size = off;
    80003824:	052aa623          	sw	s2,76(s5)
    80003828:	64e6                	ld	s1,88(sp)
    8000382a:	7c02                	ld	s8,32(sp)
    8000382c:	6ce2                	ld	s9,24(sp)
    8000382e:	6d42                	ld	s10,16(sp)
    80003830:	6da2                	ld	s11,8(sp)

  // write the i-node back to disk even if the size didn't change
  // because the loop above might have called bmap() and added a new
  // block to ip->addrs[].
  iupdate(ip);
    80003832:	8556                	mv	a0,s5
    80003834:	9adff0ef          	jal	800031e0 <iupdate>

  return tot;
    80003838:	854e                	mv	a0,s3
    8000383a:	69a6                	ld	s3,72(sp)
}
    8000383c:	70a6                	ld	ra,104(sp)
    8000383e:	7406                	ld	s0,96(sp)
    80003840:	6946                	ld	s2,80(sp)
    80003842:	6a06                	ld	s4,64(sp)
    80003844:	7ae2                	ld	s5,56(sp)
    80003846:	7b42                	ld	s6,48(sp)
    80003848:	7ba2                	ld	s7,40(sp)
    8000384a:	6165                	addi	sp,sp,112
    8000384c:	8082                	ret
  for (tot = 0; tot < n; tot += m, off += m, src += m) {
    8000384e:	89da                	mv	s3,s6
    80003850:	b7cd                	j	80003832 <writei+0xd2>
    80003852:	64e6                	ld	s1,88(sp)
    80003854:	7c02                	ld	s8,32(sp)
    80003856:	6ce2                	ld	s9,24(sp)
    80003858:	6d42                	ld	s10,16(sp)
    8000385a:	6da2                	ld	s11,8(sp)
    8000385c:	bfd9                	j	80003832 <writei+0xd2>
    return -1;
    8000385e:	557d                	li	a0,-1
}
    80003860:	8082                	ret
    return -1;
    80003862:	557d                	li	a0,-1
    80003864:	bfe1                	j	8000383c <writei+0xdc>

0000000080003866 <namecmp>:

// Directories

int
namecmp(const char *s, const char *t)
{
    80003866:	1141                	addi	sp,sp,-16
    80003868:	e406                	sd	ra,8(sp)
    8000386a:	e022                	sd	s0,0(sp)
    8000386c:	0800                	addi	s0,sp,16
  return strncmp(s, t, DIRSIZ);
    8000386e:	4639                	li	a2,14
    80003870:	d0cfd0ef          	jal	80000d7c <strncmp>
}
    80003874:	60a2                	ld	ra,8(sp)
    80003876:	6402                	ld	s0,0(sp)
    80003878:	0141                	addi	sp,sp,16
    8000387a:	8082                	ret

000000008000387c <dirlookup>:

// Look for a directory entry in a directory.
// If found, set *poff to byte offset of entry.
struct inode *
dirlookup(struct inode *dp, char *name, uint *poff)
{
    8000387c:	711d                	addi	sp,sp,-96
    8000387e:	ec86                	sd	ra,88(sp)
    80003880:	e8a2                	sd	s0,80(sp)
    80003882:	e4a6                	sd	s1,72(sp)
    80003884:	e0ca                	sd	s2,64(sp)
    80003886:	fc4e                	sd	s3,56(sp)
    80003888:	f852                	sd	s4,48(sp)
    8000388a:	f456                	sd	s5,40(sp)
    8000388c:	f05a                	sd	s6,32(sp)
    8000388e:	ec5e                	sd	s7,24(sp)
    80003890:	1080                	addi	s0,sp,96
  uint off, inum;
  struct dirent de;

  if (dp->type != T_DIR)
    80003892:	04451703          	lh	a4,68(a0)
    80003896:	4785                	li	a5,1
    80003898:	00f71f63          	bne	a4,a5,800038b6 <dirlookup+0x3a>
    8000389c:	892a                	mv	s2,a0
    8000389e:	8aae                	mv	s5,a1
    800038a0:	8bb2                	mv	s7,a2
    panic("dirlookup not DIR");

  for (off = 0; off < dp->size; off += sizeof(de)) {
    800038a2:	457c                	lw	a5,76(a0)
    800038a4:	4481                	li	s1,0
    if (readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    800038a6:	fa040a13          	addi	s4,s0,-96
    800038aa:	49c1                	li	s3,16
      panic("dirlookup read");
    if (de.inum == 0)
      continue;
    if (namecmp(name, de.name) == 0) {
    800038ac:	fa240b13          	addi	s6,s0,-94
      inum = de.inum;
      return iget(dp->dev, inum);
    }
  }

  return 0;
    800038b0:	4501                	li	a0,0
  for (off = 0; off < dp->size; off += sizeof(de)) {
    800038b2:	e39d                	bnez	a5,800038d8 <dirlookup+0x5c>
    800038b4:	a8b9                	j	80003912 <dirlookup+0x96>
    panic("dirlookup not DIR");
    800038b6:	00004517          	auipc	a0,0x4
    800038ba:	c2250513          	addi	a0,a0,-990 # 800074d8 <etext+0x4d8>
    800038be:	f77fc0ef          	jal	80000834 <panic>
      panic("dirlookup read");
    800038c2:	00004517          	auipc	a0,0x4
    800038c6:	c2e50513          	addi	a0,a0,-978 # 800074f0 <etext+0x4f0>
    800038ca:	f6bfc0ef          	jal	80000834 <panic>
  for (off = 0; off < dp->size; off += sizeof(de)) {
    800038ce:	24c1                	addiw	s1,s1,16
    800038d0:	04c92783          	lw	a5,76(s2)
    800038d4:	02f4fe63          	bgeu	s1,a5,80003910 <dirlookup+0x94>
    if (readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    800038d8:	874e                	mv	a4,s3
    800038da:	86a6                	mv	a3,s1
    800038dc:	8652                	mv	a2,s4
    800038de:	4581                	li	a1,0
    800038e0:	854a                	mv	a0,s2
    800038e2:	d8dff0ef          	jal	8000366e <readi>
    800038e6:	fd351ee3          	bne	a0,s3,800038c2 <dirlookup+0x46>
    if (de.inum == 0)
    800038ea:	fa045783          	lhu	a5,-96(s0)
    800038ee:	d3e5                	beqz	a5,800038ce <dirlookup+0x52>
    if (namecmp(name, de.name) == 0) {
    800038f0:	85da                	mv	a1,s6
    800038f2:	8556                	mv	a0,s5
    800038f4:	f73ff0ef          	jal	80003866 <namecmp>
    800038f8:	f979                	bnez	a0,800038ce <dirlookup+0x52>
      if (poff)
    800038fa:	000b8463          	beqz	s7,80003902 <dirlookup+0x86>
        *poff = off;
    800038fe:	009ba023          	sw	s1,0(s7)
      return iget(dp->dev, inum);
    80003902:	fa045583          	lhu	a1,-96(s0)
    80003906:	00092503          	lw	a0,0(s2)
    8000390a:	f18ff0ef          	jal	80003022 <iget>
    8000390e:	a011                	j	80003912 <dirlookup+0x96>
  return 0;
    80003910:	4501                	li	a0,0
}
    80003912:	60e6                	ld	ra,88(sp)
    80003914:	6446                	ld	s0,80(sp)
    80003916:	64a6                	ld	s1,72(sp)
    80003918:	6906                	ld	s2,64(sp)
    8000391a:	79e2                	ld	s3,56(sp)
    8000391c:	7a42                	ld	s4,48(sp)
    8000391e:	7aa2                	ld	s5,40(sp)
    80003920:	7b02                	ld	s6,32(sp)
    80003922:	6be2                	ld	s7,24(sp)
    80003924:	6125                	addi	sp,sp,96
    80003926:	8082                	ret

0000000080003928 <namex>:
// If parent != 0, return the inode for the parent and copy the final
// path element into name, which must have room for DIRSIZ bytes.
// Must be called inside a transaction since it calls iput().
static struct inode *
namex(char *path, int nameiparent, char *name)
{
    80003928:	711d                	addi	sp,sp,-96
    8000392a:	ec86                	sd	ra,88(sp)
    8000392c:	e8a2                	sd	s0,80(sp)
    8000392e:	e4a6                	sd	s1,72(sp)
    80003930:	e0ca                	sd	s2,64(sp)
    80003932:	fc4e                	sd	s3,56(sp)
    80003934:	f852                	sd	s4,48(sp)
    80003936:	f456                	sd	s5,40(sp)
    80003938:	f05a                	sd	s6,32(sp)
    8000393a:	ec5e                	sd	s7,24(sp)
    8000393c:	e862                	sd	s8,16(sp)
    8000393e:	e466                	sd	s9,8(sp)
    80003940:	e06a                	sd	s10,0(sp)
    80003942:	1080                	addi	s0,sp,96
    80003944:	84aa                	mv	s1,a0
    80003946:	8b2e                	mv	s6,a1
    80003948:	8ab2                	mv	s5,a2
  struct inode *ip, *next;

  if (*path == '/')
    8000394a:	00054703          	lbu	a4,0(a0)
    8000394e:	02f00793          	li	a5,47
    80003952:	00f70f63          	beq	a4,a5,80003970 <namex+0x48>
    ip = iget(ROOTDEV, ROOTINO);
  else
    ip = idup(myproc()->cwd);
    80003956:	fb3fd0ef          	jal	80001908 <myproc>
    8000395a:	15053503          	ld	a0,336(a0)
    8000395e:	901ff0ef          	jal	8000325e <idup>
    80003962:	8a2a                	mv	s4,a0
  while (*path == '/')
    80003964:	02f00993          	li	s3,47
  if (len >= DIRSIZ)
    80003968:	4c35                	li	s8,13
    memmove(name, s, DIRSIZ);
    8000396a:	4cb9                	li	s9,14

  while ((path = skipelem(path, name)) != 0) {
    ilock(ip);
    if (ip->type != T_DIR) {
    8000396c:	4b85                	li	s7,1
    8000396e:	a07d                	j	80003a1c <namex+0xf4>
    ip = iget(ROOTDEV, ROOTINO);
    80003970:	4585                	li	a1,1
    80003972:	852e                	mv	a0,a1
    80003974:	eaeff0ef          	jal	80003022 <iget>
    80003978:	8a2a                	mv	s4,a0
    8000397a:	b7ed                	j	80003964 <namex+0x3c>
      iunlockput(ip);
    8000397c:	8552                	mv	a0,s4
    8000397e:	b6bff0ef          	jal	800034e8 <iunlockput>
      return 0;
    80003982:	4a01                	li	s4,0
  if (nameiparent) {
    iput(ip);
    return 0;
  }
  return ip;
}
    80003984:	8552                	mv	a0,s4
    80003986:	60e6                	ld	ra,88(sp)
    80003988:	6446                	ld	s0,80(sp)
    8000398a:	64a6                	ld	s1,72(sp)
    8000398c:	6906                	ld	s2,64(sp)
    8000398e:	79e2                	ld	s3,56(sp)
    80003990:	7a42                	ld	s4,48(sp)
    80003992:	7aa2                	ld	s5,40(sp)
    80003994:	7b02                	ld	s6,32(sp)
    80003996:	6be2                	ld	s7,24(sp)
    80003998:	6c42                	ld	s8,16(sp)
    8000399a:	6ca2                	ld	s9,8(sp)
    8000399c:	6d02                	ld	s10,0(sp)
    8000399e:	6125                	addi	sp,sp,96
    800039a0:	8082                	ret
      iunlockput(ip);
    800039a2:	8552                	mv	a0,s4
    800039a4:	b45ff0ef          	jal	800034e8 <iunlockput>
      return 0;
    800039a8:	4a01                	li	s4,0
    800039aa:	bfe9                	j	80003984 <namex+0x5c>
      iunlock(ip);
    800039ac:	8552                	mv	a0,s4
    800039ae:	995ff0ef          	jal	80003342 <iunlock>
      return ip;
    800039b2:	bfc9                	j	80003984 <namex+0x5c>
      iunlockput(ip);
    800039b4:	8552                	mv	a0,s4
    800039b6:	b33ff0ef          	jal	800034e8 <iunlockput>
      return 0;
    800039ba:	8a4a                	mv	s4,s2
    800039bc:	b7e1                	j	80003984 <namex+0x5c>
  while (*path != '/' && *path != 0)
    800039be:	8926                	mv	s2,s1
  len = path - s;
    800039c0:	4d01                	li	s10,0
    800039c2:	4601                	li	a2,0
    memmove(name, s, len);
    800039c4:	2601                	sext.w	a2,a2
    800039c6:	85a6                	mv	a1,s1
    800039c8:	8556                	mv	a0,s5
    800039ca:	b3efd0ef          	jal	80000d08 <memmove>
    name[len] = 0;
    800039ce:	9d56                	add	s10,s10,s5
    800039d0:	000d0023          	sb	zero,0(s10) # fffffffffffff000 <end+0xffffffff7ffdb9b0>
  while (*path == '/')
    800039d4:	00094783          	lbu	a5,0(s2)
    800039d8:	09379b63          	bne	a5,s3,80003a6e <namex+0x146>
    800039dc:	84ca                	mv	s1,s2
    path++;
    800039de:	0485                	addi	s1,s1,1
  while (*path == '/')
    800039e0:	0004c783          	lbu	a5,0(s1)
    800039e4:	ff378de3          	beq	a5,s3,800039de <namex+0xb6>
    ilock(ip);
    800039e8:	8552                	mv	a0,s4
    800039ea:	8abff0ef          	jal	80003294 <ilock>
    if (ip->type != T_DIR) {
    800039ee:	044a1783          	lh	a5,68(s4)
    800039f2:	f97795e3          	bne	a5,s7,8000397c <namex+0x54>
    if (ip->nlink == 0) {
    800039f6:	04aa1783          	lh	a5,74(s4)
    800039fa:	d7c5                	beqz	a5,800039a2 <namex+0x7a>
    if (nameiparent && *path == '\0') {
    800039fc:	000b0563          	beqz	s6,80003a06 <namex+0xde>
    80003a00:	0004c783          	lbu	a5,0(s1)
    80003a04:	d7c5                	beqz	a5,800039ac <namex+0x84>
    if ((next = dirlookup(ip, name, 0)) == 0) {
    80003a06:	4601                	li	a2,0
    80003a08:	85d6                	mv	a1,s5
    80003a0a:	8552                	mv	a0,s4
    80003a0c:	e71ff0ef          	jal	8000387c <dirlookup>
    80003a10:	892a                	mv	s2,a0
    80003a12:	d14d                	beqz	a0,800039b4 <namex+0x8c>
    iunlockput(ip);
    80003a14:	8552                	mv	a0,s4
    80003a16:	ad3ff0ef          	jal	800034e8 <iunlockput>
    ip = next;
    80003a1a:	8a4a                	mv	s4,s2
  while (*path == '/')
    80003a1c:	0004c783          	lbu	a5,0(s1)
    80003a20:	01379763          	bne	a5,s3,80003a2e <namex+0x106>
    path++;
    80003a24:	0485                	addi	s1,s1,1
  while (*path == '/')
    80003a26:	0004c783          	lbu	a5,0(s1)
    80003a2a:	ff378de3          	beq	a5,s3,80003a24 <namex+0xfc>
  if (*path == 0)
    80003a2e:	c7a1                	beqz	a5,80003a76 <namex+0x14e>
  while (*path != '/' && *path != 0)
    80003a30:	0004c783          	lbu	a5,0(s1)
    80003a34:	fd178713          	addi	a4,a5,-47
    80003a38:	d359                	beqz	a4,800039be <namex+0x96>
    80003a3a:	d3d1                	beqz	a5,800039be <namex+0x96>
    80003a3c:	8926                	mv	s2,s1
    path++;
    80003a3e:	0905                	addi	s2,s2,1
  while (*path != '/' && *path != 0)
    80003a40:	00094783          	lbu	a5,0(s2)
    80003a44:	fd178713          	addi	a4,a5,-47
    80003a48:	c311                	beqz	a4,80003a4c <namex+0x124>
    80003a4a:	fbf5                	bnez	a5,80003a3e <namex+0x116>
  len = path - s;
    80003a4c:	40990633          	sub	a2,s2,s1
    80003a50:	00060d1b          	sext.w	s10,a2
  if (len >= DIRSIZ)
    80003a54:	f7ac58e3          	bge	s8,s10,800039c4 <namex+0x9c>
    memmove(name, s, DIRSIZ);
    80003a58:	8666                	mv	a2,s9
    80003a5a:	85a6                	mv	a1,s1
    80003a5c:	8556                	mv	a0,s5
    80003a5e:	aaafd0ef          	jal	80000d08 <memmove>
  while (*path == '/')
    80003a62:	00094783          	lbu	a5,0(s2)
    80003a66:	84ca                	mv	s1,s2
    80003a68:	f7378be3          	beq	a5,s3,800039de <namex+0xb6>
    80003a6c:	bfb5                	j	800039e8 <namex+0xc0>
  while ((path = skipelem(path, name)) != 0) {
    80003a6e:	00090463          	beqz	s2,80003a76 <namex+0x14e>
    80003a72:	84ca                	mv	s1,s2
    80003a74:	bf95                	j	800039e8 <namex+0xc0>
  if (nameiparent) {
    80003a76:	f00b07e3          	beqz	s6,80003984 <namex+0x5c>
    iput(ip);
    80003a7a:	8552                	mv	a0,s4
    80003a7c:	99bff0ef          	jal	80003416 <iput>
    return 0;
    80003a80:	4a01                	li	s4,0
    80003a82:	b709                	j	80003984 <namex+0x5c>

0000000080003a84 <dirlink>:
{
    80003a84:	715d                	addi	sp,sp,-80
    80003a86:	e486                	sd	ra,72(sp)
    80003a88:	e0a2                	sd	s0,64(sp)
    80003a8a:	f84a                	sd	s2,48(sp)
    80003a8c:	ec56                	sd	s5,24(sp)
    80003a8e:	e85a                	sd	s6,16(sp)
    80003a90:	0880                	addi	s0,sp,80
    80003a92:	892a                	mv	s2,a0
    80003a94:	8aae                	mv	s5,a1
    80003a96:	8b32                	mv	s6,a2
  if ((ip = dirlookup(dp, name, 0)) != 0) {
    80003a98:	4601                	li	a2,0
    80003a9a:	de3ff0ef          	jal	8000387c <dirlookup>
    80003a9e:	ed1d                	bnez	a0,80003adc <dirlink+0x58>
    80003aa0:	fc26                	sd	s1,56(sp)
  for (off = 0; off < dp->size; off += sizeof(de)) {
    80003aa2:	04c92483          	lw	s1,76(s2)
    80003aa6:	c4b9                	beqz	s1,80003af4 <dirlink+0x70>
    80003aa8:	f44e                	sd	s3,40(sp)
    80003aaa:	f052                	sd	s4,32(sp)
    80003aac:	4481                	li	s1,0
    if (readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003aae:	fb040a13          	addi	s4,s0,-80
    80003ab2:	49c1                	li	s3,16
    80003ab4:	874e                	mv	a4,s3
    80003ab6:	86a6                	mv	a3,s1
    80003ab8:	8652                	mv	a2,s4
    80003aba:	4581                	li	a1,0
    80003abc:	854a                	mv	a0,s2
    80003abe:	bb1ff0ef          	jal	8000366e <readi>
    80003ac2:	03351163          	bne	a0,s3,80003ae4 <dirlink+0x60>
    if (de.inum == 0)
    80003ac6:	fb045783          	lhu	a5,-80(s0)
    80003aca:	c39d                	beqz	a5,80003af0 <dirlink+0x6c>
  for (off = 0; off < dp->size; off += sizeof(de)) {
    80003acc:	24c1                	addiw	s1,s1,16
    80003ace:	04c92783          	lw	a5,76(s2)
    80003ad2:	fef4e1e3          	bltu	s1,a5,80003ab4 <dirlink+0x30>
    80003ad6:	79a2                	ld	s3,40(sp)
    80003ad8:	7a02                	ld	s4,32(sp)
    80003ada:	a829                	j	80003af4 <dirlink+0x70>
    iput(ip);
    80003adc:	93bff0ef          	jal	80003416 <iput>
    return -1;
    80003ae0:	557d                	li	a0,-1
    80003ae2:	a83d                	j	80003b20 <dirlink+0x9c>
      panic("dirlink read");
    80003ae4:	00004517          	auipc	a0,0x4
    80003ae8:	a1c50513          	addi	a0,a0,-1508 # 80007500 <etext+0x500>
    80003aec:	d49fc0ef          	jal	80000834 <panic>
    80003af0:	79a2                	ld	s3,40(sp)
    80003af2:	7a02                	ld	s4,32(sp)
  strncpy(de.name, name, DIRSIZ);
    80003af4:	4639                	li	a2,14
    80003af6:	85d6                	mv	a1,s5
    80003af8:	fb240513          	addi	a0,s0,-78
    80003afc:	abafd0ef          	jal	80000db6 <strncpy>
  de.inum = inum;
    80003b00:	fb641823          	sh	s6,-80(s0)
  if (writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003b04:	4741                	li	a4,16
    80003b06:	86a6                	mv	a3,s1
    80003b08:	fb040613          	addi	a2,s0,-80
    80003b0c:	4581                	li	a1,0
    80003b0e:	854a                	mv	a0,s2
    80003b10:	c51ff0ef          	jal	80003760 <writei>
    80003b14:	1541                	addi	a0,a0,-16
    80003b16:	00a03533          	snez	a0,a0
    80003b1a:	40a0053b          	negw	a0,a0
    80003b1e:	74e2                	ld	s1,56(sp)
}
    80003b20:	60a6                	ld	ra,72(sp)
    80003b22:	6406                	ld	s0,64(sp)
    80003b24:	7942                	ld	s2,48(sp)
    80003b26:	6ae2                	ld	s5,24(sp)
    80003b28:	6b42                	ld	s6,16(sp)
    80003b2a:	6161                	addi	sp,sp,80
    80003b2c:	8082                	ret

0000000080003b2e <namei>:

struct inode *
namei(char *path)
{
    80003b2e:	1101                	addi	sp,sp,-32
    80003b30:	ec06                	sd	ra,24(sp)
    80003b32:	e822                	sd	s0,16(sp)
    80003b34:	1000                	addi	s0,sp,32
  char name[DIRSIZ];
  return namex(path, 0, name);
    80003b36:	fe040613          	addi	a2,s0,-32
    80003b3a:	4581                	li	a1,0
    80003b3c:	dedff0ef          	jal	80003928 <namex>
}
    80003b40:	60e2                	ld	ra,24(sp)
    80003b42:	6442                	ld	s0,16(sp)
    80003b44:	6105                	addi	sp,sp,32
    80003b46:	8082                	ret

0000000080003b48 <nameiparent>:

struct inode *
nameiparent(char *path, char *name)
{
    80003b48:	1141                	addi	sp,sp,-16
    80003b4a:	e406                	sd	ra,8(sp)
    80003b4c:	e022                	sd	s0,0(sp)
    80003b4e:	0800                	addi	s0,sp,16
    80003b50:	862e                	mv	a2,a1
  return namex(path, 1, name);
    80003b52:	4585                	li	a1,1
    80003b54:	dd5ff0ef          	jal	80003928 <namex>
}
    80003b58:	60a2                	ld	ra,8(sp)
    80003b5a:	6402                	ld	s0,0(sp)
    80003b5c:	0141                	addi	sp,sp,16
    80003b5e:	8082                	ret

0000000080003b60 <write_head>:
// Write in-memory log header to disk.
// This is the true point at which the
// current transaction commits.
static void
write_head(void)
{
    80003b60:	1101                	addi	sp,sp,-32
    80003b62:	ec06                	sd	ra,24(sp)
    80003b64:	e822                	sd	s0,16(sp)
    80003b66:	e426                	sd	s1,8(sp)
    80003b68:	e04a                	sd	s2,0(sp)
    80003b6a:	1000                	addi	s0,sp,32
  struct buf *buf = bread(log.dev, log.start);
    80003b6c:	0001f917          	auipc	s2,0x1f
    80003b70:	8a490913          	addi	s2,s2,-1884 # 80022410 <log>
    80003b74:	01892583          	lw	a1,24(s2)
    80003b78:	02492503          	lw	a0,36(s2)
    80003b7c:	880ff0ef          	jal	80002bfc <bread>
    80003b80:	84aa                	mv	s1,a0
  struct logheader *hb = (struct logheader *)(buf->data);
  int i;
  hb->n = log.lh.n;
    80003b82:	02c92603          	lw	a2,44(s2)
    80003b86:	cd30                	sw	a2,88(a0)
  for (i = 0; i < log.lh.n; i++) {
    80003b88:	00c05f63          	blez	a2,80003ba6 <write_head+0x46>
    80003b8c:	0001f717          	auipc	a4,0x1f
    80003b90:	8b470713          	addi	a4,a4,-1868 # 80022440 <log+0x30>
    80003b94:	87aa                	mv	a5,a0
    80003b96:	060a                	slli	a2,a2,0x2
    80003b98:	962a                	add	a2,a2,a0
    hb->block[i] = log.lh.block[i];
    80003b9a:	4314                	lw	a3,0(a4)
    80003b9c:	cff4                	sw	a3,92(a5)
  for (i = 0; i < log.lh.n; i++) {
    80003b9e:	0711                	addi	a4,a4,4
    80003ba0:	0791                	addi	a5,a5,4
    80003ba2:	fec79ce3          	bne	a5,a2,80003b9a <write_head+0x3a>
  }
  bwrite(buf);
    80003ba6:	8526                	mv	a0,s1
    80003ba8:	92aff0ef          	jal	80002cd2 <bwrite>
  brelse(buf);
    80003bac:	8526                	mv	a0,s1
    80003bae:	956ff0ef          	jal	80002d04 <brelse>
}
    80003bb2:	60e2                	ld	ra,24(sp)
    80003bb4:	6442                	ld	s0,16(sp)
    80003bb6:	64a2                	ld	s1,8(sp)
    80003bb8:	6902                	ld	s2,0(sp)
    80003bba:	6105                	addi	sp,sp,32
    80003bbc:	8082                	ret

0000000080003bbe <install_trans>:
  for (tail = 0; tail < log.lh.n; tail++) {
    80003bbe:	0001f797          	auipc	a5,0x1f
    80003bc2:	87e7a783          	lw	a5,-1922(a5) # 8002243c <log+0x2c>
    80003bc6:	0cf05163          	blez	a5,80003c88 <install_trans+0xca>
{
    80003bca:	715d                	addi	sp,sp,-80
    80003bcc:	e486                	sd	ra,72(sp)
    80003bce:	e0a2                	sd	s0,64(sp)
    80003bd0:	fc26                	sd	s1,56(sp)
    80003bd2:	f84a                	sd	s2,48(sp)
    80003bd4:	f44e                	sd	s3,40(sp)
    80003bd6:	f052                	sd	s4,32(sp)
    80003bd8:	ec56                	sd	s5,24(sp)
    80003bda:	e85a                	sd	s6,16(sp)
    80003bdc:	e45e                	sd	s7,8(sp)
    80003bde:	e062                	sd	s8,0(sp)
    80003be0:	0880                	addi	s0,sp,80
    80003be2:	8b2a                	mv	s6,a0
    80003be4:	0001fa97          	auipc	s5,0x1f
    80003be8:	85ca8a93          	addi	s5,s5,-1956 # 80022440 <log+0x30>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003bec:	4981                	li	s3,0
      printk("recovering tail %d dst %d\n", tail, log.lh.block[tail]);
    80003bee:	00004c17          	auipc	s8,0x4
    80003bf2:	922c0c13          	addi	s8,s8,-1758 # 80007510 <etext+0x510>
    struct buf *lbuf = bread(log.dev, log.start + tail + 1); // read log block
    80003bf6:	0001fa17          	auipc	s4,0x1f
    80003bfa:	81aa0a13          	addi	s4,s4,-2022 # 80022410 <log>
    memmove(dbuf->data, lbuf->data, BSIZE); // copy block to dst
    80003bfe:	40000b93          	li	s7,1024
    80003c02:	a025                	j	80003c2a <install_trans+0x6c>
      printk("recovering tail %d dst %d\n", tail, log.lh.block[tail]);
    80003c04:	000aa603          	lw	a2,0(s5)
    80003c08:	85ce                	mv	a1,s3
    80003c0a:	8562                	mv	a0,s8
    80003c0c:	8fffc0ef          	jal	8000050a <printk>
    80003c10:	a839                	j	80003c2e <install_trans+0x70>
    brelse(lbuf);
    80003c12:	854a                	mv	a0,s2
    80003c14:	8f0ff0ef          	jal	80002d04 <brelse>
    brelse(dbuf);
    80003c18:	8526                	mv	a0,s1
    80003c1a:	8eaff0ef          	jal	80002d04 <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003c1e:	2985                	addiw	s3,s3,1
    80003c20:	0a91                	addi	s5,s5,4
    80003c22:	02ca2783          	lw	a5,44(s4)
    80003c26:	04f9d563          	bge	s3,a5,80003c70 <install_trans+0xb2>
    if (recovering) {
    80003c2a:	fc0b1de3          	bnez	s6,80003c04 <install_trans+0x46>
    struct buf *lbuf = bread(log.dev, log.start + tail + 1); // read log block
    80003c2e:	018a2583          	lw	a1,24(s4)
    80003c32:	013585bb          	addw	a1,a1,s3
    80003c36:	2585                	addiw	a1,a1,1
    80003c38:	024a2503          	lw	a0,36(s4)
    80003c3c:	fc1fe0ef          	jal	80002bfc <bread>
    80003c40:	892a                	mv	s2,a0
    struct buf *dbuf = bread(log.dev, log.lh.block[tail]);   // read dst
    80003c42:	000aa583          	lw	a1,0(s5)
    80003c46:	024a2503          	lw	a0,36(s4)
    80003c4a:	fb3fe0ef          	jal	80002bfc <bread>
    80003c4e:	84aa                	mv	s1,a0
    memmove(dbuf->data, lbuf->data, BSIZE); // copy block to dst
    80003c50:	865e                	mv	a2,s7
    80003c52:	05890593          	addi	a1,s2,88
    80003c56:	05850513          	addi	a0,a0,88
    80003c5a:	8aefd0ef          	jal	80000d08 <memmove>
    bwrite(dbuf);                           // write dst to disk
    80003c5e:	8526                	mv	a0,s1
    80003c60:	872ff0ef          	jal	80002cd2 <bwrite>
    if (recovering == 0)
    80003c64:	fa0b17e3          	bnez	s6,80003c12 <install_trans+0x54>
      bunpin(dbuf);
    80003c68:	8526                	mv	a0,s1
    80003c6a:	952ff0ef          	jal	80002dbc <bunpin>
    80003c6e:	b755                	j	80003c12 <install_trans+0x54>
}
    80003c70:	60a6                	ld	ra,72(sp)
    80003c72:	6406                	ld	s0,64(sp)
    80003c74:	74e2                	ld	s1,56(sp)
    80003c76:	7942                	ld	s2,48(sp)
    80003c78:	79a2                	ld	s3,40(sp)
    80003c7a:	7a02                	ld	s4,32(sp)
    80003c7c:	6ae2                	ld	s5,24(sp)
    80003c7e:	6b42                	ld	s6,16(sp)
    80003c80:	6ba2                	ld	s7,8(sp)
    80003c82:	6c02                	ld	s8,0(sp)
    80003c84:	6161                	addi	sp,sp,80
    80003c86:	8082                	ret
    80003c88:	8082                	ret

0000000080003c8a <initlog>:
{
    80003c8a:	7179                	addi	sp,sp,-48
    80003c8c:	f406                	sd	ra,40(sp)
    80003c8e:	f022                	sd	s0,32(sp)
    80003c90:	ec26                	sd	s1,24(sp)
    80003c92:	e84a                	sd	s2,16(sp)
    80003c94:	e44e                	sd	s3,8(sp)
    80003c96:	1800                	addi	s0,sp,48
    80003c98:	84aa                	mv	s1,a0
    80003c9a:	89ae                	mv	s3,a1
  initlock(&log.lock, "log");
    80003c9c:	0001e917          	auipc	s2,0x1e
    80003ca0:	77490913          	addi	s2,s2,1908 # 80022410 <log>
    80003ca4:	00004597          	auipc	a1,0x4
    80003ca8:	88c58593          	addi	a1,a1,-1908 # 80007530 <etext+0x530>
    80003cac:	854a                	mv	a0,s2
    80003cae:	ebbfc0ef          	jal	80000b68 <initlock>
  log.start = sb->logstart;
    80003cb2:	0149a583          	lw	a1,20(s3)
    80003cb6:	00b92c23          	sw	a1,24(s2)
  log.dev = dev;
    80003cba:	02992223          	sw	s1,36(s2)
  struct buf *buf = bread(log.dev, log.start);
    80003cbe:	8526                	mv	a0,s1
    80003cc0:	f3dfe0ef          	jal	80002bfc <bread>
  log.lh.n = lh->n;
    80003cc4:	4d30                	lw	a2,88(a0)
    80003cc6:	02c92623          	sw	a2,44(s2)
  for (i = 0; i < log.lh.n; i++) {
    80003cca:	00c05f63          	blez	a2,80003ce8 <initlog+0x5e>
    80003cce:	87aa                	mv	a5,a0
    80003cd0:	0001e717          	auipc	a4,0x1e
    80003cd4:	77070713          	addi	a4,a4,1904 # 80022440 <log+0x30>
    80003cd8:	060a                	slli	a2,a2,0x2
    80003cda:	962a                	add	a2,a2,a0
    log.lh.block[i] = lh->block[i];
    80003cdc:	4ff4                	lw	a3,92(a5)
    80003cde:	c314                	sw	a3,0(a4)
  for (i = 0; i < log.lh.n; i++) {
    80003ce0:	0791                	addi	a5,a5,4
    80003ce2:	0711                	addi	a4,a4,4
    80003ce4:	fec79ce3          	bne	a5,a2,80003cdc <initlog+0x52>
  brelse(buf);
    80003ce8:	81cff0ef          	jal	80002d04 <brelse>

static void
recover_from_log(void)
{
  read_head();
  install_trans(1); // if committed, copy from log to disk
    80003cec:	4505                	li	a0,1
    80003cee:	ed1ff0ef          	jal	80003bbe <install_trans>
  log.lh.n = 0;
    80003cf2:	0001e797          	auipc	a5,0x1e
    80003cf6:	7407a523          	sw	zero,1866(a5) # 8002243c <log+0x2c>
  write_head(); // clear the log
    80003cfa:	e67ff0ef          	jal	80003b60 <write_head>
}
    80003cfe:	70a2                	ld	ra,40(sp)
    80003d00:	7402                	ld	s0,32(sp)
    80003d02:	64e2                	ld	s1,24(sp)
    80003d04:	6942                	ld	s2,16(sp)
    80003d06:	69a2                	ld	s3,8(sp)
    80003d08:	6145                	addi	sp,sp,48
    80003d0a:	8082                	ret

0000000080003d0c <begin_op>:
}

// called at the start of each FS system call.
void
begin_op(void)
{
    80003d0c:	1101                	addi	sp,sp,-32
    80003d0e:	ec06                	sd	ra,24(sp)
    80003d10:	e822                	sd	s0,16(sp)
    80003d12:	e426                	sd	s1,8(sp)
    80003d14:	e04a                	sd	s2,0(sp)
    80003d16:	1000                	addi	s0,sp,32
  acquire(&log.lock);
    80003d18:	0001e517          	auipc	a0,0x1e
    80003d1c:	6f850513          	addi	a0,a0,1784 # 80022410 <log>
    80003d20:	ec9fc0ef          	jal	80000be8 <acquire>
  while (1) {
    if (log.committing) {
    80003d24:	0001e497          	auipc	s1,0x1e
    80003d28:	6ec48493          	addi	s1,s1,1772 # 80022410 <log>
      sleep_prepare(&log);
      release(&log.lock);
      sleep();
      acquire(&log.lock);
    } else if (log.lh.n + (log.outstanding + 1) * MAXOPBLOCKS > LOGBLOCKS) {
    80003d2c:	4979                	li	s2,30
    80003d2e:	a821                	j	80003d46 <begin_op+0x3a>
      sleep_prepare(&log);
    80003d30:	8526                	mv	a0,s1
    80003d32:	9e0fe0ef          	jal	80001f12 <sleep_prepare>
      release(&log.lock);
    80003d36:	8526                	mv	a0,s1
    80003d38:	f39fc0ef          	jal	80000c70 <release>
      sleep();
    80003d3c:	a12fe0ef          	jal	80001f4e <sleep>
      acquire(&log.lock);
    80003d40:	8526                	mv	a0,s1
    80003d42:	ea7fc0ef          	jal	80000be8 <acquire>
    if (log.committing) {
    80003d46:	509c                	lw	a5,32(s1)
    80003d48:	f7e5                	bnez	a5,80003d30 <begin_op+0x24>
    } else if (log.lh.n + (log.outstanding + 1) * MAXOPBLOCKS > LOGBLOCKS) {
    80003d4a:	4cd8                	lw	a4,28(s1)
    80003d4c:	2705                	addiw	a4,a4,1
    80003d4e:	0027179b          	slliw	a5,a4,0x2
    80003d52:	9fb9                	addw	a5,a5,a4
    80003d54:	0017979b          	slliw	a5,a5,0x1
    80003d58:	54d4                	lw	a3,44(s1)
    80003d5a:	9fb5                	addw	a5,a5,a3
    80003d5c:	00f95e63          	bge	s2,a5,80003d78 <begin_op+0x6c>
      // this op might exhaust log space; wait for commit.
      sleep_prepare(&log);
    80003d60:	8526                	mv	a0,s1
    80003d62:	9b0fe0ef          	jal	80001f12 <sleep_prepare>
      release(&log.lock);
    80003d66:	8526                	mv	a0,s1
    80003d68:	f09fc0ef          	jal	80000c70 <release>
      sleep();
    80003d6c:	9e2fe0ef          	jal	80001f4e <sleep>
      acquire(&log.lock);
    80003d70:	8526                	mv	a0,s1
    80003d72:	e77fc0ef          	jal	80000be8 <acquire>
    80003d76:	bfc1                	j	80003d46 <begin_op+0x3a>
    } else {
      log.outstanding += 1;
    80003d78:	0001e797          	auipc	a5,0x1e
    80003d7c:	6ae7aa23          	sw	a4,1716(a5) # 8002242c <log+0x1c>
      release(&log.lock);
    80003d80:	0001e517          	auipc	a0,0x1e
    80003d84:	69050513          	addi	a0,a0,1680 # 80022410 <log>
    80003d88:	ee9fc0ef          	jal	80000c70 <release>
      break;
    }
  }
}
    80003d8c:	60e2                	ld	ra,24(sp)
    80003d8e:	6442                	ld	s0,16(sp)
    80003d90:	64a2                	ld	s1,8(sp)
    80003d92:	6902                	ld	s2,0(sp)
    80003d94:	6105                	addi	sp,sp,32
    80003d96:	8082                	ret

0000000080003d98 <end_op>:

// called at the end of each FS system call.
// commits if this was the last outstanding operation.
void
end_op(void)
{
    80003d98:	7139                	addi	sp,sp,-64
    80003d9a:	fc06                	sd	ra,56(sp)
    80003d9c:	f822                	sd	s0,48(sp)
    80003d9e:	f426                	sd	s1,40(sp)
    80003da0:	f04a                	sd	s2,32(sp)
    80003da2:	0080                	addi	s0,sp,64
  int do_commit = 0;

  acquire(&log.lock);
    80003da4:	0001e497          	auipc	s1,0x1e
    80003da8:	66c48493          	addi	s1,s1,1644 # 80022410 <log>
    80003dac:	8526                	mv	a0,s1
    80003dae:	e3bfc0ef          	jal	80000be8 <acquire>
  log.outstanding -= 1;
    80003db2:	4cdc                	lw	a5,28(s1)
    80003db4:	37fd                	addiw	a5,a5,-1
    80003db6:	893e                	mv	s2,a5
    80003db8:	ccdc                	sw	a5,28(s1)
  if (log.committing)
    80003dba:	509c                	lw	a5,32(s1)
    80003dbc:	e3b1                	bnez	a5,80003e00 <end_op+0x68>
    panic("log.committing");
  if (log.outstanding == 0) {
    80003dbe:	04091a63          	bnez	s2,80003e12 <end_op+0x7a>
    do_commit = 1;
    log.committing = 1;
    80003dc2:	0001e497          	auipc	s1,0x1e
    80003dc6:	64e48493          	addi	s1,s1,1614 # 80022410 <log>
    80003dca:	4785                	li	a5,1
    80003dcc:	d09c                	sw	a5,32(s1)
    // begin_op() may be waiting for log space,
    // and decrementing log.outstanding has decreased
    // the amount of reserved space.
    wakeup(&log);
  }
  release(&log.lock);
    80003dce:	8526                	mv	a0,s1
    80003dd0:	ea1fc0ef          	jal	80000c70 <release>
}

static void
commit()
{
  if (log.lh.n > 0) {
    80003dd4:	54dc                	lw	a5,44(s1)
    80003dd6:	06f04063          	bgtz	a5,80003e36 <end_op+0x9e>
    acquire(&log.lock);
    80003dda:	0001e497          	auipc	s1,0x1e
    80003dde:	63648493          	addi	s1,s1,1590 # 80022410 <log>
    80003de2:	8526                	mv	a0,s1
    80003de4:	e05fc0ef          	jal	80000be8 <acquire>
    log.committing = 0;
    80003de8:	0204a023          	sw	zero,32(s1)
    log.ncommit += 1;
    80003dec:	549c                	lw	a5,40(s1)
    80003dee:	2785                	addiw	a5,a5,1
    80003df0:	d49c                	sw	a5,40(s1)
    wakeup(&log);
    80003df2:	8526                	mv	a0,s1
    80003df4:	98afe0ef          	jal	80001f7e <wakeup>
    release(&log.lock);
    80003df8:	8526                	mv	a0,s1
    80003dfa:	e77fc0ef          	jal	80000c70 <release>
}
    80003dfe:	a035                	j	80003e2a <end_op+0x92>
    80003e00:	ec4e                	sd	s3,24(sp)
    80003e02:	e852                	sd	s4,16(sp)
    80003e04:	e456                	sd	s5,8(sp)
    panic("log.committing");
    80003e06:	00003517          	auipc	a0,0x3
    80003e0a:	73250513          	addi	a0,a0,1842 # 80007538 <etext+0x538>
    80003e0e:	a27fc0ef          	jal	80000834 <panic>
    wakeup(&log);
    80003e12:	0001e517          	auipc	a0,0x1e
    80003e16:	5fe50513          	addi	a0,a0,1534 # 80022410 <log>
    80003e1a:	964fe0ef          	jal	80001f7e <wakeup>
  release(&log.lock);
    80003e1e:	0001e517          	auipc	a0,0x1e
    80003e22:	5f250513          	addi	a0,a0,1522 # 80022410 <log>
    80003e26:	e4bfc0ef          	jal	80000c70 <release>
}
    80003e2a:	70e2                	ld	ra,56(sp)
    80003e2c:	7442                	ld	s0,48(sp)
    80003e2e:	74a2                	ld	s1,40(sp)
    80003e30:	7902                	ld	s2,32(sp)
    80003e32:	6121                	addi	sp,sp,64
    80003e34:	8082                	ret
    80003e36:	ec4e                	sd	s3,24(sp)
    80003e38:	e852                	sd	s4,16(sp)
    80003e3a:	e456                	sd	s5,8(sp)
  for (tail = 0; tail < log.lh.n; tail++) {
    80003e3c:	0001ea97          	auipc	s5,0x1e
    80003e40:	604a8a93          	addi	s5,s5,1540 # 80022440 <log+0x30>
    struct buf *to = bread(log.dev, log.start + tail + 1); // log block
    80003e44:	0001ea17          	auipc	s4,0x1e
    80003e48:	5cca0a13          	addi	s4,s4,1484 # 80022410 <log>
    80003e4c:	018a2583          	lw	a1,24(s4)
    80003e50:	012585bb          	addw	a1,a1,s2
    80003e54:	2585                	addiw	a1,a1,1
    80003e56:	024a2503          	lw	a0,36(s4)
    80003e5a:	da3fe0ef          	jal	80002bfc <bread>
    80003e5e:	84aa                	mv	s1,a0
    struct buf *from = bread(log.dev, log.lh.block[tail]); // cache block
    80003e60:	000aa583          	lw	a1,0(s5)
    80003e64:	024a2503          	lw	a0,36(s4)
    80003e68:	d95fe0ef          	jal	80002bfc <bread>
    80003e6c:	89aa                	mv	s3,a0
    memmove(to->data, from->data, BSIZE);
    80003e6e:	40000613          	li	a2,1024
    80003e72:	05850593          	addi	a1,a0,88
    80003e76:	05848513          	addi	a0,s1,88
    80003e7a:	e8ffc0ef          	jal	80000d08 <memmove>
    bwrite(to); // write the log
    80003e7e:	8526                	mv	a0,s1
    80003e80:	e53fe0ef          	jal	80002cd2 <bwrite>
    brelse(from);
    80003e84:	854e                	mv	a0,s3
    80003e86:	e7ffe0ef          	jal	80002d04 <brelse>
    brelse(to);
    80003e8a:	8526                	mv	a0,s1
    80003e8c:	e79fe0ef          	jal	80002d04 <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003e90:	2905                	addiw	s2,s2,1
    80003e92:	0a91                	addi	s5,s5,4
    80003e94:	02ca2783          	lw	a5,44(s4)
    80003e98:	faf94ae3          	blt	s2,a5,80003e4c <end_op+0xb4>
    write_log();      // Write modified blocks from cache to log
    write_head();     // Write header to disk -- the real commit
    80003e9c:	cc5ff0ef          	jal	80003b60 <write_head>
    install_trans(0); // Now install writes to home locations
    80003ea0:	4501                	li	a0,0
    80003ea2:	d1dff0ef          	jal	80003bbe <install_trans>
    log.lh.n = 0;
    80003ea6:	0001e797          	auipc	a5,0x1e
    80003eaa:	5807ab23          	sw	zero,1430(a5) # 8002243c <log+0x2c>
    write_head(); // Erase the transaction from the log
    80003eae:	cb3ff0ef          	jal	80003b60 <write_head>
    80003eb2:	69e2                	ld	s3,24(sp)
    80003eb4:	6a42                	ld	s4,16(sp)
    80003eb6:	6aa2                	ld	s5,8(sp)
    80003eb8:	b70d                	j	80003dda <end_op+0x42>

0000000080003eba <log_write>:
//   modify bp->data[]
//   log_write(bp)
//   brelse(bp)
void
log_write(struct buf *b)
{
    80003eba:	1101                	addi	sp,sp,-32
    80003ebc:	ec06                	sd	ra,24(sp)
    80003ebe:	e822                	sd	s0,16(sp)
    80003ec0:	e426                	sd	s1,8(sp)
    80003ec2:	1000                	addi	s0,sp,32
    80003ec4:	84aa                	mv	s1,a0
  int i;

  acquire(&log.lock);
    80003ec6:	0001e517          	auipc	a0,0x1e
    80003eca:	54a50513          	addi	a0,a0,1354 # 80022410 <log>
    80003ece:	d1bfc0ef          	jal	80000be8 <acquire>
  if (log.lh.n >= LOGBLOCKS)
    80003ed2:	0001e617          	auipc	a2,0x1e
    80003ed6:	56a62603          	lw	a2,1386(a2) # 8002243c <log+0x2c>
    80003eda:	47f5                	li	a5,29
    80003edc:	04c7cd63          	blt	a5,a2,80003f36 <log_write+0x7c>
    panic("too big a transaction");
  if (log.outstanding < 1)
    80003ee0:	0001e797          	auipc	a5,0x1e
    80003ee4:	54c7a783          	lw	a5,1356(a5) # 8002242c <log+0x1c>
    80003ee8:	04f05d63          	blez	a5,80003f42 <log_write+0x88>
    panic("log_write outside of trans");

  for (i = 0; i < log.lh.n; i++) {
    80003eec:	4781                	li	a5,0
    80003eee:	06c05063          	blez	a2,80003f4e <log_write+0x94>
    if (log.lh.block[i] == b->blockno) // log absorption
    80003ef2:	44cc                	lw	a1,12(s1)
    80003ef4:	0001e717          	auipc	a4,0x1e
    80003ef8:	54c70713          	addi	a4,a4,1356 # 80022440 <log+0x30>
  for (i = 0; i < log.lh.n; i++) {
    80003efc:	4781                	li	a5,0
    if (log.lh.block[i] == b->blockno) // log absorption
    80003efe:	4314                	lw	a3,0(a4)
    80003f00:	04b68763          	beq	a3,a1,80003f4e <log_write+0x94>
  for (i = 0; i < log.lh.n; i++) {
    80003f04:	2785                	addiw	a5,a5,1
    80003f06:	0711                	addi	a4,a4,4
    80003f08:	fef61be3          	bne	a2,a5,80003efe <log_write+0x44>
      break;
  }
  log.lh.block[i] = b->blockno;
    80003f0c:	060a                	slli	a2,a2,0x2
    80003f0e:	02060613          	addi	a2,a2,32
    80003f12:	0001e797          	auipc	a5,0x1e
    80003f16:	4fe78793          	addi	a5,a5,1278 # 80022410 <log>
    80003f1a:	97b2                	add	a5,a5,a2
    80003f1c:	44d8                	lw	a4,12(s1)
    80003f1e:	cb98                	sw	a4,16(a5)
  if (i == log.lh.n) { // Add new block to log?
    bpin(b);
    80003f20:	8526                	mv	a0,s1
    80003f22:	e67fe0ef          	jal	80002d88 <bpin>
    log.lh.n++;
    80003f26:	0001e717          	auipc	a4,0x1e
    80003f2a:	4ea70713          	addi	a4,a4,1258 # 80022410 <log>
    80003f2e:	575c                	lw	a5,44(a4)
    80003f30:	2785                	addiw	a5,a5,1
    80003f32:	d75c                	sw	a5,44(a4)
    80003f34:	a815                	j	80003f68 <log_write+0xae>
    panic("too big a transaction");
    80003f36:	00003517          	auipc	a0,0x3
    80003f3a:	61250513          	addi	a0,a0,1554 # 80007548 <etext+0x548>
    80003f3e:	8f7fc0ef          	jal	80000834 <panic>
    panic("log_write outside of trans");
    80003f42:	00003517          	auipc	a0,0x3
    80003f46:	61e50513          	addi	a0,a0,1566 # 80007560 <etext+0x560>
    80003f4a:	8ebfc0ef          	jal	80000834 <panic>
  log.lh.block[i] = b->blockno;
    80003f4e:	00279693          	slli	a3,a5,0x2
    80003f52:	02068693          	addi	a3,a3,32
    80003f56:	0001e717          	auipc	a4,0x1e
    80003f5a:	4ba70713          	addi	a4,a4,1210 # 80022410 <log>
    80003f5e:	9736                	add	a4,a4,a3
    80003f60:	44d4                	lw	a3,12(s1)
    80003f62:	cb14                	sw	a3,16(a4)
  if (i == log.lh.n) { // Add new block to log?
    80003f64:	faf60ee3          	beq	a2,a5,80003f20 <log_write+0x66>
  }
  release(&log.lock);
    80003f68:	0001e517          	auipc	a0,0x1e
    80003f6c:	4a850513          	addi	a0,a0,1192 # 80022410 <log>
    80003f70:	d01fc0ef          	jal	80000c70 <release>
}
    80003f74:	60e2                	ld	ra,24(sp)
    80003f76:	6442                	ld	s0,16(sp)
    80003f78:	64a2                	ld	s1,8(sp)
    80003f7a:	6105                	addi	sp,sp,32
    80003f7c:	8082                	ret

0000000080003f7e <sys_sync>:

uint64
sys_sync(void)
{
    80003f7e:	1101                	addi	sp,sp,-32
    80003f80:	ec06                	sd	ra,24(sp)
    80003f82:	e822                	sd	s0,16(sp)
    80003f84:	1000                	addi	s0,sp,32
  acquire(&log.lock);
    80003f86:	0001e517          	auipc	a0,0x1e
    80003f8a:	48a50513          	addi	a0,a0,1162 # 80022410 <log>
    80003f8e:	c5bfc0ef          	jal	80000be8 <acquire>
  if (log.committing || log.outstanding > 0) {
    80003f92:	0001e797          	auipc	a5,0x1e
    80003f96:	49e7a783          	lw	a5,1182(a5) # 80022430 <log+0x20>
    80003f9a:	e799                	bnez	a5,80003fa8 <sys_sync+0x2a>
    80003f9c:	0001e797          	auipc	a5,0x1e
    80003fa0:	4907a783          	lw	a5,1168(a5) # 8002242c <log+0x1c>
    80003fa4:	02f05c63          	blez	a5,80003fdc <sys_sync+0x5e>
    80003fa8:	e426                	sd	s1,8(sp)
    80003faa:	e04a                	sd	s2,0(sp)
    int n = log.ncommit + 1;
    80003fac:	0001e917          	auipc	s2,0x1e
    80003fb0:	48c92903          	lw	s2,1164(s2) # 80022438 <log+0x28>
    while (log.ncommit < n) {
      sleep_prepare(&log);
    80003fb4:	0001e497          	auipc	s1,0x1e
    80003fb8:	45c48493          	addi	s1,s1,1116 # 80022410 <log>
    80003fbc:	8526                	mv	a0,s1
    80003fbe:	f55fd0ef          	jal	80001f12 <sleep_prepare>
      release(&log.lock);
    80003fc2:	8526                	mv	a0,s1
    80003fc4:	cadfc0ef          	jal	80000c70 <release>
      sleep();
    80003fc8:	f87fd0ef          	jal	80001f4e <sleep>
      acquire(&log.lock);
    80003fcc:	8526                	mv	a0,s1
    80003fce:	c1bfc0ef          	jal	80000be8 <acquire>
    while (log.ncommit < n) {
    80003fd2:	549c                	lw	a5,40(s1)
    80003fd4:	fef954e3          	bge	s2,a5,80003fbc <sys_sync+0x3e>
    80003fd8:	64a2                	ld	s1,8(sp)
    80003fda:	6902                	ld	s2,0(sp)
    }
  }
  release(&log.lock);
    80003fdc:	0001e517          	auipc	a0,0x1e
    80003fe0:	43450513          	addi	a0,a0,1076 # 80022410 <log>
    80003fe4:	c8dfc0ef          	jal	80000c70 <release>
  return 0;
}
    80003fe8:	4501                	li	a0,0
    80003fea:	60e2                	ld	ra,24(sp)
    80003fec:	6442                	ld	s0,16(sp)
    80003fee:	6105                	addi	sp,sp,32
    80003ff0:	8082                	ret

0000000080003ff2 <initsleeplock>:
#include "proc.h"
#include "sleeplock.h"

void
initsleeplock(struct sleeplock *lk, char *name)
{
    80003ff2:	1101                	addi	sp,sp,-32
    80003ff4:	ec06                	sd	ra,24(sp)
    80003ff6:	e822                	sd	s0,16(sp)
    80003ff8:	e426                	sd	s1,8(sp)
    80003ffa:	e04a                	sd	s2,0(sp)
    80003ffc:	1000                	addi	s0,sp,32
    80003ffe:	84aa                	mv	s1,a0
    80004000:	892e                	mv	s2,a1
  initlock(&lk->lk, "sleep lock");
    80004002:	00003597          	auipc	a1,0x3
    80004006:	57e58593          	addi	a1,a1,1406 # 80007580 <etext+0x580>
    8000400a:	0521                	addi	a0,a0,8
    8000400c:	b5dfc0ef          	jal	80000b68 <initlock>
  lk->name = name;
    80004010:	0324b023          	sd	s2,32(s1)
  lk->locked = 0;
    80004014:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    80004018:	0204a423          	sw	zero,40(s1)
}
    8000401c:	60e2                	ld	ra,24(sp)
    8000401e:	6442                	ld	s0,16(sp)
    80004020:	64a2                	ld	s1,8(sp)
    80004022:	6902                	ld	s2,0(sp)
    80004024:	6105                	addi	sp,sp,32
    80004026:	8082                	ret

0000000080004028 <acquiresleep>:

void
acquiresleep(struct sleeplock *lk)
{
    80004028:	1101                	addi	sp,sp,-32
    8000402a:	ec06                	sd	ra,24(sp)
    8000402c:	e822                	sd	s0,16(sp)
    8000402e:	e426                	sd	s1,8(sp)
    80004030:	e04a                	sd	s2,0(sp)
    80004032:	1000                	addi	s0,sp,32
    80004034:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    80004036:	00850913          	addi	s2,a0,8
    8000403a:	854a                	mv	a0,s2
    8000403c:	badfc0ef          	jal	80000be8 <acquire>
  while (lk->locked) {
    80004040:	409c                	lw	a5,0(s1)
    80004042:	cf91                	beqz	a5,8000405e <acquiresleep+0x36>
    sleep_prepare(lk);
    80004044:	8526                	mv	a0,s1
    80004046:	ecdfd0ef          	jal	80001f12 <sleep_prepare>
    release(&lk->lk);
    8000404a:	854a                	mv	a0,s2
    8000404c:	c25fc0ef          	jal	80000c70 <release>
    sleep();
    80004050:	efffd0ef          	jal	80001f4e <sleep>
    acquire(&lk->lk);
    80004054:	854a                	mv	a0,s2
    80004056:	b93fc0ef          	jal	80000be8 <acquire>
  while (lk->locked) {
    8000405a:	409c                	lw	a5,0(s1)
    8000405c:	f7e5                	bnez	a5,80004044 <acquiresleep+0x1c>
  }
  lk->locked = 1;
    8000405e:	4785                	li	a5,1
    80004060:	c09c                	sw	a5,0(s1)
  lk->pid = myproc()->pid;
    80004062:	8a7fd0ef          	jal	80001908 <myproc>
    80004066:	591c                	lw	a5,48(a0)
    80004068:	d49c                	sw	a5,40(s1)
  release(&lk->lk);
    8000406a:	854a                	mv	a0,s2
    8000406c:	c05fc0ef          	jal	80000c70 <release>
}
    80004070:	60e2                	ld	ra,24(sp)
    80004072:	6442                	ld	s0,16(sp)
    80004074:	64a2                	ld	s1,8(sp)
    80004076:	6902                	ld	s2,0(sp)
    80004078:	6105                	addi	sp,sp,32
    8000407a:	8082                	ret

000000008000407c <releasesleep>:

void
releasesleep(struct sleeplock *lk)
{
    8000407c:	1101                	addi	sp,sp,-32
    8000407e:	ec06                	sd	ra,24(sp)
    80004080:	e822                	sd	s0,16(sp)
    80004082:	e426                	sd	s1,8(sp)
    80004084:	e04a                	sd	s2,0(sp)
    80004086:	1000                	addi	s0,sp,32
    80004088:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    8000408a:	00850913          	addi	s2,a0,8
    8000408e:	854a                	mv	a0,s2
    80004090:	b59fc0ef          	jal	80000be8 <acquire>
  lk->locked = 0;
    80004094:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    80004098:	0204a423          	sw	zero,40(s1)
  wakeup(lk);
    8000409c:	8526                	mv	a0,s1
    8000409e:	ee1fd0ef          	jal	80001f7e <wakeup>
  release(&lk->lk);
    800040a2:	854a                	mv	a0,s2
    800040a4:	bcdfc0ef          	jal	80000c70 <release>
}
    800040a8:	60e2                	ld	ra,24(sp)
    800040aa:	6442                	ld	s0,16(sp)
    800040ac:	64a2                	ld	s1,8(sp)
    800040ae:	6902                	ld	s2,0(sp)
    800040b0:	6105                	addi	sp,sp,32
    800040b2:	8082                	ret

00000000800040b4 <holdingsleep>:

int
holdingsleep(struct sleeplock *lk)
{
    800040b4:	7179                	addi	sp,sp,-48
    800040b6:	f406                	sd	ra,40(sp)
    800040b8:	f022                	sd	s0,32(sp)
    800040ba:	ec26                	sd	s1,24(sp)
    800040bc:	e84a                	sd	s2,16(sp)
    800040be:	1800                	addi	s0,sp,48
    800040c0:	84aa                	mv	s1,a0
  int r;

  acquire(&lk->lk);
    800040c2:	00850913          	addi	s2,a0,8
    800040c6:	854a                	mv	a0,s2
    800040c8:	b21fc0ef          	jal	80000be8 <acquire>
  r = lk->locked && (lk->pid == myproc()->pid);
    800040cc:	409c                	lw	a5,0(s1)
    800040ce:	ef81                	bnez	a5,800040e6 <holdingsleep+0x32>
    800040d0:	4481                	li	s1,0
  release(&lk->lk);
    800040d2:	854a                	mv	a0,s2
    800040d4:	b9dfc0ef          	jal	80000c70 <release>
  return r;
}
    800040d8:	8526                	mv	a0,s1
    800040da:	70a2                	ld	ra,40(sp)
    800040dc:	7402                	ld	s0,32(sp)
    800040de:	64e2                	ld	s1,24(sp)
    800040e0:	6942                	ld	s2,16(sp)
    800040e2:	6145                	addi	sp,sp,48
    800040e4:	8082                	ret
    800040e6:	e44e                	sd	s3,8(sp)
  r = lk->locked && (lk->pid == myproc()->pid);
    800040e8:	0284a983          	lw	s3,40(s1)
    800040ec:	81dfd0ef          	jal	80001908 <myproc>
    800040f0:	5904                	lw	s1,48(a0)
    800040f2:	413484b3          	sub	s1,s1,s3
    800040f6:	0014b493          	seqz	s1,s1
    800040fa:	69a2                	ld	s3,8(sp)
    800040fc:	bfd9                	j	800040d2 <holdingsleep+0x1e>

00000000800040fe <fileinit>:
  struct file file[NFILE];
} ftable;

void
fileinit(void)
{
    800040fe:	1141                	addi	sp,sp,-16
    80004100:	e406                	sd	ra,8(sp)
    80004102:	e022                	sd	s0,0(sp)
    80004104:	0800                	addi	s0,sp,16
  initlock(&ftable.lock, "ftable");
    80004106:	00003597          	auipc	a1,0x3
    8000410a:	48a58593          	addi	a1,a1,1162 # 80007590 <etext+0x590>
    8000410e:	0001e517          	auipc	a0,0x1e
    80004112:	44a50513          	addi	a0,a0,1098 # 80022558 <ftable>
    80004116:	a53fc0ef          	jal	80000b68 <initlock>
}
    8000411a:	60a2                	ld	ra,8(sp)
    8000411c:	6402                	ld	s0,0(sp)
    8000411e:	0141                	addi	sp,sp,16
    80004120:	8082                	ret

0000000080004122 <filealloc>:

// Allocate a file structure.
struct file *
filealloc(void)
{
    80004122:	1101                	addi	sp,sp,-32
    80004124:	ec06                	sd	ra,24(sp)
    80004126:	e822                	sd	s0,16(sp)
    80004128:	e426                	sd	s1,8(sp)
    8000412a:	1000                	addi	s0,sp,32
  struct file *f;

  acquire(&ftable.lock);
    8000412c:	0001e517          	auipc	a0,0x1e
    80004130:	42c50513          	addi	a0,a0,1068 # 80022558 <ftable>
    80004134:	ab5fc0ef          	jal	80000be8 <acquire>
  for (f = ftable.file; f < ftable.file + NFILE; f++) {
    80004138:	0001e497          	auipc	s1,0x1e
    8000413c:	43848493          	addi	s1,s1,1080 # 80022570 <ftable+0x18>
    80004140:	0001f717          	auipc	a4,0x1f
    80004144:	3d070713          	addi	a4,a4,976 # 80023510 <disk>
    if (f->ref == 0) {
    80004148:	40dc                	lw	a5,4(s1)
    8000414a:	cf89                	beqz	a5,80004164 <filealloc+0x42>
  for (f = ftable.file; f < ftable.file + NFILE; f++) {
    8000414c:	02848493          	addi	s1,s1,40
    80004150:	fee49ce3          	bne	s1,a4,80004148 <filealloc+0x26>
      f->ref = 1;
      release(&ftable.lock);
      return f;
    }
  }
  release(&ftable.lock);
    80004154:	0001e517          	auipc	a0,0x1e
    80004158:	40450513          	addi	a0,a0,1028 # 80022558 <ftable>
    8000415c:	b15fc0ef          	jal	80000c70 <release>
  return 0;
    80004160:	4481                	li	s1,0
    80004162:	a809                	j	80004174 <filealloc+0x52>
      f->ref = 1;
    80004164:	4785                	li	a5,1
    80004166:	c0dc                	sw	a5,4(s1)
      release(&ftable.lock);
    80004168:	0001e517          	auipc	a0,0x1e
    8000416c:	3f050513          	addi	a0,a0,1008 # 80022558 <ftable>
    80004170:	b01fc0ef          	jal	80000c70 <release>
}
    80004174:	8526                	mv	a0,s1
    80004176:	60e2                	ld	ra,24(sp)
    80004178:	6442                	ld	s0,16(sp)
    8000417a:	64a2                	ld	s1,8(sp)
    8000417c:	6105                	addi	sp,sp,32
    8000417e:	8082                	ret

0000000080004180 <filedup>:

// Increment ref count for file f.
struct file *
filedup(struct file *f)
{
    80004180:	1101                	addi	sp,sp,-32
    80004182:	ec06                	sd	ra,24(sp)
    80004184:	e822                	sd	s0,16(sp)
    80004186:	e426                	sd	s1,8(sp)
    80004188:	1000                	addi	s0,sp,32
    8000418a:	84aa                	mv	s1,a0
  acquire(&ftable.lock);
    8000418c:	0001e517          	auipc	a0,0x1e
    80004190:	3cc50513          	addi	a0,a0,972 # 80022558 <ftable>
    80004194:	a55fc0ef          	jal	80000be8 <acquire>
  if (f->ref < 1)
    80004198:	40dc                	lw	a5,4(s1)
    8000419a:	02f05063          	blez	a5,800041ba <filedup+0x3a>
    panic("filedup");
  f->ref++;
    8000419e:	2785                	addiw	a5,a5,1
    800041a0:	c0dc                	sw	a5,4(s1)
  release(&ftable.lock);
    800041a2:	0001e517          	auipc	a0,0x1e
    800041a6:	3b650513          	addi	a0,a0,950 # 80022558 <ftable>
    800041aa:	ac7fc0ef          	jal	80000c70 <release>
  return f;
}
    800041ae:	8526                	mv	a0,s1
    800041b0:	60e2                	ld	ra,24(sp)
    800041b2:	6442                	ld	s0,16(sp)
    800041b4:	64a2                	ld	s1,8(sp)
    800041b6:	6105                	addi	sp,sp,32
    800041b8:	8082                	ret
    panic("filedup");
    800041ba:	00003517          	auipc	a0,0x3
    800041be:	3de50513          	addi	a0,a0,990 # 80007598 <etext+0x598>
    800041c2:	e72fc0ef          	jal	80000834 <panic>

00000000800041c6 <fileclose>:

// Close file f.  (Decrement ref count, close when reaches 0.)
void
fileclose(struct file *f)
{
    800041c6:	7139                	addi	sp,sp,-64
    800041c8:	fc06                	sd	ra,56(sp)
    800041ca:	f822                	sd	s0,48(sp)
    800041cc:	f426                	sd	s1,40(sp)
    800041ce:	0080                	addi	s0,sp,64
    800041d0:	84aa                	mv	s1,a0
  struct file ff;

  acquire(&ftable.lock);
    800041d2:	0001e517          	auipc	a0,0x1e
    800041d6:	38650513          	addi	a0,a0,902 # 80022558 <ftable>
    800041da:	a0ffc0ef          	jal	80000be8 <acquire>
  if (f->ref < 1)
    800041de:	40dc                	lw	a5,4(s1)
    800041e0:	04f05a63          	blez	a5,80004234 <fileclose+0x6e>
    panic("fileclose");
  if (--f->ref > 0) {
    800041e4:	37fd                	addiw	a5,a5,-1
    800041e6:	c0dc                	sw	a5,4(s1)
    800041e8:	06f04063          	bgtz	a5,80004248 <fileclose+0x82>
    800041ec:	f04a                	sd	s2,32(sp)
    800041ee:	ec4e                	sd	s3,24(sp)
    800041f0:	e852                	sd	s4,16(sp)
    800041f2:	e456                	sd	s5,8(sp)
    release(&ftable.lock);
    return;
  }
  ff = *f;
    800041f4:	0004a903          	lw	s2,0(s1)
    800041f8:	0094c783          	lbu	a5,9(s1)
    800041fc:	89be                	mv	s3,a5
    800041fe:	689c                	ld	a5,16(s1)
    80004200:	8a3e                	mv	s4,a5
    80004202:	6c9c                	ld	a5,24(s1)
    80004204:	8abe                	mv	s5,a5
  f->ref = 0;
    80004206:	0004a223          	sw	zero,4(s1)
  f->type = FD_NONE;
    8000420a:	0004a023          	sw	zero,0(s1)
  release(&ftable.lock);
    8000420e:	0001e517          	auipc	a0,0x1e
    80004212:	34a50513          	addi	a0,a0,842 # 80022558 <ftable>
    80004216:	a5bfc0ef          	jal	80000c70 <release>

  if (ff.type == FD_PIPE) {
    8000421a:	4785                	li	a5,1
    8000421c:	04f90163          	beq	s2,a5,8000425e <fileclose+0x98>
    pipeclose(ff.pipe, ff.writable);
  } else if (ff.type == FD_INODE || ff.type == FD_DEVICE) {
    80004220:	ffe9079b          	addiw	a5,s2,-2
    80004224:	4705                	li	a4,1
    80004226:	04f77563          	bgeu	a4,a5,80004270 <fileclose+0xaa>
    8000422a:	7902                	ld	s2,32(sp)
    8000422c:	69e2                	ld	s3,24(sp)
    8000422e:	6a42                	ld	s4,16(sp)
    80004230:	6aa2                	ld	s5,8(sp)
    80004232:	a00d                	j	80004254 <fileclose+0x8e>
    80004234:	f04a                	sd	s2,32(sp)
    80004236:	ec4e                	sd	s3,24(sp)
    80004238:	e852                	sd	s4,16(sp)
    8000423a:	e456                	sd	s5,8(sp)
    panic("fileclose");
    8000423c:	00003517          	auipc	a0,0x3
    80004240:	36450513          	addi	a0,a0,868 # 800075a0 <etext+0x5a0>
    80004244:	df0fc0ef          	jal	80000834 <panic>
    release(&ftable.lock);
    80004248:	0001e517          	auipc	a0,0x1e
    8000424c:	31050513          	addi	a0,a0,784 # 80022558 <ftable>
    80004250:	a21fc0ef          	jal	80000c70 <release>
    begin_op();
    iput(ff.ip);
    end_op();
  }
}
    80004254:	70e2                	ld	ra,56(sp)
    80004256:	7442                	ld	s0,48(sp)
    80004258:	74a2                	ld	s1,40(sp)
    8000425a:	6121                	addi	sp,sp,64
    8000425c:	8082                	ret
    pipeclose(ff.pipe, ff.writable);
    8000425e:	85ce                	mv	a1,s3
    80004260:	8552                	mv	a0,s4
    80004262:	360000ef          	jal	800045c2 <pipeclose>
    80004266:	7902                	ld	s2,32(sp)
    80004268:	69e2                	ld	s3,24(sp)
    8000426a:	6a42                	ld	s4,16(sp)
    8000426c:	6aa2                	ld	s5,8(sp)
    8000426e:	b7dd                	j	80004254 <fileclose+0x8e>
    begin_op();
    80004270:	a9dff0ef          	jal	80003d0c <begin_op>
    iput(ff.ip);
    80004274:	8556                	mv	a0,s5
    80004276:	9a0ff0ef          	jal	80003416 <iput>
    end_op();
    8000427a:	b1fff0ef          	jal	80003d98 <end_op>
    8000427e:	7902                	ld	s2,32(sp)
    80004280:	69e2                	ld	s3,24(sp)
    80004282:	6a42                	ld	s4,16(sp)
    80004284:	6aa2                	ld	s5,8(sp)
    80004286:	b7f9                	j	80004254 <fileclose+0x8e>

0000000080004288 <filestat>:

// Get metadata about file f.
// addr is a user virtual address, pointing to a struct stat.
int
filestat(struct file *f, uint64 addr)
{
    80004288:	715d                	addi	sp,sp,-80
    8000428a:	e486                	sd	ra,72(sp)
    8000428c:	e0a2                	sd	s0,64(sp)
    8000428e:	fc26                	sd	s1,56(sp)
    80004290:	f052                	sd	s4,32(sp)
    80004292:	0880                	addi	s0,sp,80
    80004294:	84aa                	mv	s1,a0
    80004296:	8a2e                	mv	s4,a1
  struct proc *p = myproc();
    80004298:	e70fd0ef          	jal	80001908 <myproc>
  struct stat st;

  if (f->type == FD_INODE || f->type == FD_DEVICE) {
    8000429c:	409c                	lw	a5,0(s1)
    8000429e:	37f9                	addiw	a5,a5,-2
    800042a0:	4705                	li	a4,1
    800042a2:	04f76463          	bltu	a4,a5,800042ea <filestat+0x62>
    800042a6:	f84a                	sd	s2,48(sp)
    800042a8:	f44e                	sd	s3,40(sp)
    800042aa:	892a                	mv	s2,a0
    ilock(f->ip);
    800042ac:	6c88                	ld	a0,24(s1)
    800042ae:	fe7fe0ef          	jal	80003294 <ilock>
    stati(f->ip, &st);
    800042b2:	fb840993          	addi	s3,s0,-72
    800042b6:	85ce                	mv	a1,s3
    800042b8:	6c88                	ld	a0,24(s1)
    800042ba:	b86ff0ef          	jal	80003640 <stati>
    iunlock(f->ip);
    800042be:	6c88                	ld	a0,24(s1)
    800042c0:	882ff0ef          	jal	80003342 <iunlock>
    if (copyout(p->pagetable, p->sz, addr, (char *)&st, sizeof(st)) < 0)
    800042c4:	4761                	li	a4,24
    800042c6:	86ce                	mv	a3,s3
    800042c8:	8652                	mv	a2,s4
    800042ca:	04893583          	ld	a1,72(s2)
    800042ce:	05093503          	ld	a0,80(s2)
    800042d2:	a70fd0ef          	jal	80001542 <copyout>
    800042d6:	41f5551b          	sraiw	a0,a0,0x1f
    800042da:	7942                	ld	s2,48(sp)
    800042dc:	79a2                	ld	s3,40(sp)
      return -1;
    return 0;
  }
  return -1;
}
    800042de:	60a6                	ld	ra,72(sp)
    800042e0:	6406                	ld	s0,64(sp)
    800042e2:	74e2                	ld	s1,56(sp)
    800042e4:	7a02                	ld	s4,32(sp)
    800042e6:	6161                	addi	sp,sp,80
    800042e8:	8082                	ret
  return -1;
    800042ea:	557d                	li	a0,-1
    800042ec:	bfcd                	j	800042de <filestat+0x56>

00000000800042ee <fileread>:

// Read from file f.
// addr is a user virtual address.
int
fileread(struct file *f, uint64 addr, int n)
{
    800042ee:	7179                	addi	sp,sp,-48
    800042f0:	f406                	sd	ra,40(sp)
    800042f2:	f022                	sd	s0,32(sp)
    800042f4:	e84a                	sd	s2,16(sp)
    800042f6:	1800                	addi	s0,sp,48
  int r = 0;

  if (f->readable == 0 || n < 0)
    800042f8:	00854783          	lbu	a5,8(a0)
    800042fc:	c3dd                	beqz	a5,800043a2 <fileread+0xb4>
    800042fe:	ec26                	sd	s1,24(sp)
    80004300:	e44e                	sd	s3,8(sp)
    80004302:	84aa                	mv	s1,a0
    80004304:	892e                	mv	s2,a1
    80004306:	89b2                	mv	s3,a2
    80004308:	01f6579b          	srliw	a5,a2,0x1f
    8000430c:	ebc9                	bnez	a5,8000439e <fileread+0xb0>
    return -1;

  if (f->type == FD_PIPE) {
    8000430e:	411c                	lw	a5,0(a0)
    80004310:	4705                	li	a4,1
    80004312:	04e78363          	beq	a5,a4,80004358 <fileread+0x6a>
    r = piperead(f->pipe, addr, n);
  } else if (f->type == FD_DEVICE) {
    80004316:	470d                	li	a4,3
    80004318:	04e78763          	beq	a5,a4,80004366 <fileread+0x78>
    if (f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
      return -1;
    r = devsw[f->major].read(1, addr, n);
  } else if (f->type == FD_INODE) {
    8000431c:	4709                	li	a4,2
    8000431e:	06e79a63          	bne	a5,a4,80004392 <fileread+0xa4>
    ilock(f->ip);
    80004322:	6d08                	ld	a0,24(a0)
    80004324:	f71fe0ef          	jal	80003294 <ilock>
    if ((r = readi(f->ip, 1, addr, f->off, n)) > 0)
    80004328:	874e                	mv	a4,s3
    8000432a:	5094                	lw	a3,32(s1)
    8000432c:	864a                	mv	a2,s2
    8000432e:	4585                	li	a1,1
    80004330:	6c88                	ld	a0,24(s1)
    80004332:	b3cff0ef          	jal	8000366e <readi>
    80004336:	892a                	mv	s2,a0
    80004338:	00a05563          	blez	a0,80004342 <fileread+0x54>
      f->off += r;
    8000433c:	509c                	lw	a5,32(s1)
    8000433e:	9fa9                	addw	a5,a5,a0
    80004340:	d09c                	sw	a5,32(s1)
    iunlock(f->ip);
    80004342:	6c88                	ld	a0,24(s1)
    80004344:	ffffe0ef          	jal	80003342 <iunlock>
    80004348:	64e2                	ld	s1,24(sp)
    8000434a:	69a2                	ld	s3,8(sp)
  } else {
    panic("fileread");
  }

  return r;
}
    8000434c:	854a                	mv	a0,s2
    8000434e:	70a2                	ld	ra,40(sp)
    80004350:	7402                	ld	s0,32(sp)
    80004352:	6942                	ld	s2,16(sp)
    80004354:	6145                	addi	sp,sp,48
    80004356:	8082                	ret
    r = piperead(f->pipe, addr, n);
    80004358:	6908                	ld	a0,16(a0)
    8000435a:	3e2000ef          	jal	8000473c <piperead>
    8000435e:	892a                	mv	s2,a0
    80004360:	64e2                	ld	s1,24(sp)
    80004362:	69a2                	ld	s3,8(sp)
    80004364:	b7e5                	j	8000434c <fileread+0x5e>
    if (f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
    80004366:	02451783          	lh	a5,36(a0)
    8000436a:	03079693          	slli	a3,a5,0x30
    8000436e:	92c1                	srli	a3,a3,0x30
    80004370:	4725                	li	a4,9
    80004372:	02d76b63          	bltu	a4,a3,800043a8 <fileread+0xba>
    80004376:	0792                	slli	a5,a5,0x4
    80004378:	0001e717          	auipc	a4,0x1e
    8000437c:	14070713          	addi	a4,a4,320 # 800224b8 <devsw>
    80004380:	97ba                	add	a5,a5,a4
    80004382:	639c                	ld	a5,0(a5)
    80004384:	c79d                	beqz	a5,800043b2 <fileread+0xc4>
    r = devsw[f->major].read(1, addr, n);
    80004386:	4505                	li	a0,1
    80004388:	9782                	jalr	a5
    8000438a:	892a                	mv	s2,a0
    8000438c:	64e2                	ld	s1,24(sp)
    8000438e:	69a2                	ld	s3,8(sp)
    80004390:	bf75                	j	8000434c <fileread+0x5e>
    panic("fileread");
    80004392:	00003517          	auipc	a0,0x3
    80004396:	21e50513          	addi	a0,a0,542 # 800075b0 <etext+0x5b0>
    8000439a:	c9afc0ef          	jal	80000834 <panic>
    8000439e:	64e2                	ld	s1,24(sp)
    800043a0:	69a2                	ld	s3,8(sp)
    return -1;
    800043a2:	57fd                	li	a5,-1
    800043a4:	893e                	mv	s2,a5
    800043a6:	b75d                	j	8000434c <fileread+0x5e>
      return -1;
    800043a8:	57fd                	li	a5,-1
    800043aa:	893e                	mv	s2,a5
    800043ac:	64e2                	ld	s1,24(sp)
    800043ae:	69a2                	ld	s3,8(sp)
    800043b0:	bf71                	j	8000434c <fileread+0x5e>
    800043b2:	57fd                	li	a5,-1
    800043b4:	893e                	mv	s2,a5
    800043b6:	64e2                	ld	s1,24(sp)
    800043b8:	69a2                	ld	s3,8(sp)
    800043ba:	bf49                	j	8000434c <fileread+0x5e>

00000000800043bc <filewrite>:
int
filewrite(struct file *f, uint64 addr, int n)
{
  int r, ret = 0;

  if (f->writable == 0 || n < 0)
    800043bc:	00954783          	lbu	a5,9(a0)
    800043c0:	12078b63          	beqz	a5,800044f6 <filewrite+0x13a>
{
    800043c4:	711d                	addi	sp,sp,-96
    800043c6:	ec86                	sd	ra,88(sp)
    800043c8:	e8a2                	sd	s0,80(sp)
    800043ca:	e0ca                	sd	s2,64(sp)
    800043cc:	f456                	sd	s5,40(sp)
    800043ce:	f05a                	sd	s6,32(sp)
    800043d0:	1080                	addi	s0,sp,96
    800043d2:	892a                	mv	s2,a0
    800043d4:	8b2e                	mv	s6,a1
    800043d6:	8ab2                	mv	s5,a2
  if (f->writable == 0 || n < 0)
    800043d8:	01f6579b          	srliw	a5,a2,0x1f
    800043dc:	0e079d63          	bnez	a5,800044d6 <filewrite+0x11a>
    return -1;

  if (f->type == FD_PIPE) {
    800043e0:	411c                	lw	a5,0(a0)
    800043e2:	4705                	li	a4,1
    800043e4:	02e78a63          	beq	a5,a4,80004418 <filewrite+0x5c>
    ret = pipewrite(f->pipe, addr, n);
  } else if (f->type == FD_DEVICE) {
    800043e8:	470d                	li	a4,3
    800043ea:	02e78b63          	beq	a5,a4,80004420 <filewrite+0x64>
    if (f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
      return -1;
    ret = devsw[f->major].write(1, addr, n);
  } else if (f->type == FD_INODE) {
    800043ee:	4709                	li	a4,2
    800043f0:	0ce79763          	bne	a5,a4,800044be <filewrite+0x102>
    // the maximum log transaction size, including
    // i-node, indirect block, allocation blocks,
    // and 2 blocks of slop for non-aligned writes.
    int max = ((MAXOPBLOCKS - 1 - 1 - 2) / 2) * BSIZE;
    int i = 0;
    while (i < n) {
    800043f4:	0ec05763          	blez	a2,800044e2 <filewrite+0x126>
    800043f8:	e4a6                	sd	s1,72(sp)
    800043fa:	fc4e                	sd	s3,56(sp)
    800043fc:	f852                	sd	s4,48(sp)
    800043fe:	ec5e                	sd	s7,24(sp)
    80004400:	e862                	sd	s8,16(sp)
    80004402:	e466                	sd	s9,8(sp)
    int i = 0;
    80004404:	4a01                	li	s4,0
      int n1 = n - i;
      if (n1 > max)
    80004406:	6b85                	lui	s7,0x1
    80004408:	c00b8b93          	addi	s7,s7,-1024 # c00 <_entry-0x7ffff400>
    8000440c:	6785                	lui	a5,0x1
    8000440e:	c007879b          	addiw	a5,a5,-1024 # c00 <_entry-0x7ffff400>
    80004412:	8cbe                	mv	s9,a5
        n1 = max;

      begin_op();
      ilock(f->ip);
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    80004414:	4c05                	li	s8,1
    80004416:	a8ad                	j	80004490 <filewrite+0xd4>
    ret = pipewrite(f->pipe, addr, n);
    80004418:	6908                	ld	a0,16(a0)
    8000441a:	206000ef          	jal	80004620 <pipewrite>
    8000441e:	a849                	j	800044b0 <filewrite+0xf4>
    if (f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
    80004420:	02451783          	lh	a5,36(a0)
    80004424:	03079693          	slli	a3,a5,0x30
    80004428:	92c1                	srli	a3,a3,0x30
    8000442a:	4725                	li	a4,9
    8000442c:	0ad76763          	bltu	a4,a3,800044da <filewrite+0x11e>
    80004430:	0792                	slli	a5,a5,0x4
    80004432:	0001e717          	auipc	a4,0x1e
    80004436:	08670713          	addi	a4,a4,134 # 800224b8 <devsw>
    8000443a:	97ba                	add	a5,a5,a4
    8000443c:	679c                	ld	a5,8(a5)
    8000443e:	c3c5                	beqz	a5,800044de <filewrite+0x122>
    ret = devsw[f->major].write(1, addr, n);
    80004440:	4505                	li	a0,1
    80004442:	9782                	jalr	a5
    80004444:	a0b5                	j	800044b0 <filewrite+0xf4>
      if (n1 > max)
    80004446:	2981                	sext.w	s3,s3
      begin_op();
    80004448:	8c5ff0ef          	jal	80003d0c <begin_op>
      ilock(f->ip);
    8000444c:	01893503          	ld	a0,24(s2)
    80004450:	e45fe0ef          	jal	80003294 <ilock>
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    80004454:	874e                	mv	a4,s3
    80004456:	02092683          	lw	a3,32(s2)
    8000445a:	016a0633          	add	a2,s4,s6
    8000445e:	85e2                	mv	a1,s8
    80004460:	01893503          	ld	a0,24(s2)
    80004464:	afcff0ef          	jal	80003760 <writei>
    80004468:	84aa                	mv	s1,a0
    8000446a:	00a05763          	blez	a0,80004478 <filewrite+0xbc>
        f->off += r;
    8000446e:	02092783          	lw	a5,32(s2)
    80004472:	9fa9                	addw	a5,a5,a0
    80004474:	02f92023          	sw	a5,32(s2)
      iunlock(f->ip);
    80004478:	01893503          	ld	a0,24(s2)
    8000447c:	ec7fe0ef          	jal	80003342 <iunlock>
      end_op();
    80004480:	919ff0ef          	jal	80003d98 <end_op>

      if (r != n1) {
    80004484:	00999d63          	bne	s3,s1,8000449e <filewrite+0xe2>
        // error from writei
        break;
      }
      i += r;
    80004488:	01448a3b          	addw	s4,s1,s4
    while (i < n) {
    8000448c:	015a5963          	bge	s4,s5,8000449e <filewrite+0xe2>
      int n1 = n - i;
    80004490:	414a87bb          	subw	a5,s5,s4
    80004494:	89be                	mv	s3,a5
      if (n1 > max)
    80004496:	fafbd8e3          	bge	s7,a5,80004446 <filewrite+0x8a>
    8000449a:	89e6                	mv	s3,s9
    8000449c:	b76d                	j	80004446 <filewrite+0x8a>
    }
    ret = (i == n ? n : -1);
    8000449e:	054a9463          	bne	s5,s4,800044e6 <filewrite+0x12a>
    800044a2:	8556                	mv	a0,s5
    800044a4:	64a6                	ld	s1,72(sp)
    800044a6:	79e2                	ld	s3,56(sp)
    800044a8:	7a42                	ld	s4,48(sp)
    800044aa:	6be2                	ld	s7,24(sp)
    800044ac:	6c42                	ld	s8,16(sp)
    800044ae:	6ca2                	ld	s9,8(sp)
  } else {
    panic("filewrite");
  }

  return ret;
}
    800044b0:	60e6                	ld	ra,88(sp)
    800044b2:	6446                	ld	s0,80(sp)
    800044b4:	6906                	ld	s2,64(sp)
    800044b6:	7aa2                	ld	s5,40(sp)
    800044b8:	7b02                	ld	s6,32(sp)
    800044ba:	6125                	addi	sp,sp,96
    800044bc:	8082                	ret
    800044be:	e4a6                	sd	s1,72(sp)
    800044c0:	fc4e                	sd	s3,56(sp)
    800044c2:	f852                	sd	s4,48(sp)
    800044c4:	ec5e                	sd	s7,24(sp)
    800044c6:	e862                	sd	s8,16(sp)
    800044c8:	e466                	sd	s9,8(sp)
    panic("filewrite");
    800044ca:	00003517          	auipc	a0,0x3
    800044ce:	0f650513          	addi	a0,a0,246 # 800075c0 <etext+0x5c0>
    800044d2:	b62fc0ef          	jal	80000834 <panic>
    return -1;
    800044d6:	557d                	li	a0,-1
    800044d8:	bfe1                	j	800044b0 <filewrite+0xf4>
      return -1;
    800044da:	557d                	li	a0,-1
    800044dc:	bfd1                	j	800044b0 <filewrite+0xf4>
    800044de:	557d                	li	a0,-1
    800044e0:	bfc1                	j	800044b0 <filewrite+0xf4>
    ret = (i == n ? n : -1);
    800044e2:	8532                	mv	a0,a2
    800044e4:	b7f1                	j	800044b0 <filewrite+0xf4>
    800044e6:	557d                	li	a0,-1
    800044e8:	64a6                	ld	s1,72(sp)
    800044ea:	79e2                	ld	s3,56(sp)
    800044ec:	7a42                	ld	s4,48(sp)
    800044ee:	6be2                	ld	s7,24(sp)
    800044f0:	6c42                	ld	s8,16(sp)
    800044f2:	6ca2                	ld	s9,8(sp)
    800044f4:	bf75                	j	800044b0 <filewrite+0xf4>
    return -1;
    800044f6:	557d                	li	a0,-1
}
    800044f8:	8082                	ret

00000000800044fa <pipealloc>:
  int writeopen; // write fd is still open
};

int
pipealloc(struct file **f0, struct file **f1)
{
    800044fa:	7179                	addi	sp,sp,-48
    800044fc:	f406                	sd	ra,40(sp)
    800044fe:	f022                	sd	s0,32(sp)
    80004500:	ec26                	sd	s1,24(sp)
    80004502:	e052                	sd	s4,0(sp)
    80004504:	1800                	addi	s0,sp,48
    80004506:	84aa                	mv	s1,a0
    80004508:	8a2e                	mv	s4,a1
  struct pipe *pi;

  pi = 0;
  *f0 = *f1 = 0;
    8000450a:	0005b023          	sd	zero,0(a1)
    8000450e:	00053023          	sd	zero,0(a0)
  if ((*f0 = filealloc()) == 0 || (*f1 = filealloc()) == 0)
    80004512:	c11ff0ef          	jal	80004122 <filealloc>
    80004516:	e088                	sd	a0,0(s1)
    80004518:	c549                	beqz	a0,800045a2 <pipealloc+0xa8>
    8000451a:	c09ff0ef          	jal	80004122 <filealloc>
    8000451e:	00aa3023          	sd	a0,0(s4)
    80004522:	cd25                	beqz	a0,8000459a <pipealloc+0xa0>
    80004524:	e84a                	sd	s2,16(sp)
    goto bad;
  if ((pi = (struct pipe *)kalloc()) == 0)
    80004526:	de8fc0ef          	jal	80000b0e <kalloc>
    8000452a:	892a                	mv	s2,a0
    8000452c:	c12d                	beqz	a0,8000458e <pipealloc+0x94>
    8000452e:	e44e                	sd	s3,8(sp)
    goto bad;
  pi->readopen = 1;
    80004530:	4985                	li	s3,1
    80004532:	23352023          	sw	s3,544(a0)
  pi->writeopen = 1;
    80004536:	23352223          	sw	s3,548(a0)
  pi->nwrite = 0;
    8000453a:	20052e23          	sw	zero,540(a0)
  pi->nread = 0;
    8000453e:	20052c23          	sw	zero,536(a0)
  initlock(&pi->lock, "pipe");
    80004542:	00003597          	auipc	a1,0x3
    80004546:	08e58593          	addi	a1,a1,142 # 800075d0 <etext+0x5d0>
    8000454a:	e1efc0ef          	jal	80000b68 <initlock>
  (*f0)->type = FD_PIPE;
    8000454e:	609c                	ld	a5,0(s1)
    80004550:	0137a023          	sw	s3,0(a5)
  (*f0)->readable = 1;
    80004554:	609c                	ld	a5,0(s1)
    80004556:	01378423          	sb	s3,8(a5)
  (*f0)->writable = 0;
    8000455a:	609c                	ld	a5,0(s1)
    8000455c:	000784a3          	sb	zero,9(a5)
  (*f0)->pipe = pi;
    80004560:	609c                	ld	a5,0(s1)
    80004562:	0127b823          	sd	s2,16(a5)
  (*f1)->type = FD_PIPE;
    80004566:	000a3783          	ld	a5,0(s4)
    8000456a:	0137a023          	sw	s3,0(a5)
  (*f1)->readable = 0;
    8000456e:	000a3783          	ld	a5,0(s4)
    80004572:	00078423          	sb	zero,8(a5)
  (*f1)->writable = 1;
    80004576:	000a3783          	ld	a5,0(s4)
    8000457a:	013784a3          	sb	s3,9(a5)
  (*f1)->pipe = pi;
    8000457e:	000a3783          	ld	a5,0(s4)
    80004582:	0127b823          	sd	s2,16(a5)
  return 0;
    80004586:	4501                	li	a0,0
    80004588:	6942                	ld	s2,16(sp)
    8000458a:	69a2                	ld	s3,8(sp)
    8000458c:	a01d                	j	800045b2 <pipealloc+0xb8>

bad:
  if (pi)
    kfree((char *)pi);
  if (*f0)
    8000458e:	6088                	ld	a0,0(s1)
    80004590:	c119                	beqz	a0,80004596 <pipealloc+0x9c>
    80004592:	6942                	ld	s2,16(sp)
    80004594:	a029                	j	8000459e <pipealloc+0xa4>
    80004596:	6942                	ld	s2,16(sp)
    80004598:	a029                	j	800045a2 <pipealloc+0xa8>
    8000459a:	6088                	ld	a0,0(s1)
    8000459c:	c10d                	beqz	a0,800045be <pipealloc+0xc4>
    fileclose(*f0);
    8000459e:	c29ff0ef          	jal	800041c6 <fileclose>
  if (*f1)
    800045a2:	000a3783          	ld	a5,0(s4)
    fileclose(*f1);
  return -1;
    800045a6:	557d                	li	a0,-1
  if (*f1)
    800045a8:	c789                	beqz	a5,800045b2 <pipealloc+0xb8>
    fileclose(*f1);
    800045aa:	853e                	mv	a0,a5
    800045ac:	c1bff0ef          	jal	800041c6 <fileclose>
  return -1;
    800045b0:	557d                	li	a0,-1
}
    800045b2:	70a2                	ld	ra,40(sp)
    800045b4:	7402                	ld	s0,32(sp)
    800045b6:	64e2                	ld	s1,24(sp)
    800045b8:	6a02                	ld	s4,0(sp)
    800045ba:	6145                	addi	sp,sp,48
    800045bc:	8082                	ret
  return -1;
    800045be:	557d                	li	a0,-1
    800045c0:	bfcd                	j	800045b2 <pipealloc+0xb8>

00000000800045c2 <pipeclose>:

void
pipeclose(struct pipe *pi, int writable)
{
    800045c2:	1101                	addi	sp,sp,-32
    800045c4:	ec06                	sd	ra,24(sp)
    800045c6:	e822                	sd	s0,16(sp)
    800045c8:	e426                	sd	s1,8(sp)
    800045ca:	e04a                	sd	s2,0(sp)
    800045cc:	1000                	addi	s0,sp,32
    800045ce:	84aa                	mv	s1,a0
    800045d0:	892e                	mv	s2,a1
  acquire(&pi->lock);
    800045d2:	e16fc0ef          	jal	80000be8 <acquire>
  if (writable) {
    800045d6:	02090763          	beqz	s2,80004604 <pipeclose+0x42>
    pi->writeopen = 0;
    800045da:	2204a223          	sw	zero,548(s1)
    wakeup(&pi->nread);
    800045de:	21848513          	addi	a0,s1,536
    800045e2:	99dfd0ef          	jal	80001f7e <wakeup>
  } else {
    pi->readopen = 0;
    wakeup(&pi->nwrite);
  }
  if (pi->readopen == 0 && pi->writeopen == 0) {
    800045e6:	2204a783          	lw	a5,544(s1)
    800045ea:	e781                	bnez	a5,800045f2 <pipeclose+0x30>
    800045ec:	2244a783          	lw	a5,548(s1)
    800045f0:	c38d                	beqz	a5,80004612 <pipeclose+0x50>
    release(&pi->lock);
    kfree((char *)pi);
  } else
    release(&pi->lock);
    800045f2:	8526                	mv	a0,s1
    800045f4:	e7cfc0ef          	jal	80000c70 <release>
}
    800045f8:	60e2                	ld	ra,24(sp)
    800045fa:	6442                	ld	s0,16(sp)
    800045fc:	64a2                	ld	s1,8(sp)
    800045fe:	6902                	ld	s2,0(sp)
    80004600:	6105                	addi	sp,sp,32
    80004602:	8082                	ret
    pi->readopen = 0;
    80004604:	2204a023          	sw	zero,544(s1)
    wakeup(&pi->nwrite);
    80004608:	21c48513          	addi	a0,s1,540
    8000460c:	973fd0ef          	jal	80001f7e <wakeup>
    80004610:	bfd9                	j	800045e6 <pipeclose+0x24>
    release(&pi->lock);
    80004612:	8526                	mv	a0,s1
    80004614:	e5cfc0ef          	jal	80000c70 <release>
    kfree((char *)pi);
    80004618:	8526                	mv	a0,s1
    8000461a:	c0cfc0ef          	jal	80000a26 <kfree>
    8000461e:	bfe9                	j	800045f8 <pipeclose+0x36>

0000000080004620 <pipewrite>:

int
pipewrite(struct pipe *pi, uint64 addr, int n)
{
    80004620:	7159                	addi	sp,sp,-112
    80004622:	f486                	sd	ra,104(sp)
    80004624:	f0a2                	sd	s0,96(sp)
    80004626:	eca6                	sd	s1,88(sp)
    80004628:	e8ca                	sd	s2,80(sp)
    8000462a:	e4ce                	sd	s3,72(sp)
    8000462c:	e0d2                	sd	s4,64(sp)
    8000462e:	fc56                	sd	s5,56(sp)
    80004630:	1880                	addi	s0,sp,112
    80004632:	84aa                	mv	s1,a0
    80004634:	8aae                	mv	s5,a1
    80004636:	8a32                	mv	s4,a2
  int i = 0;
  struct proc *pr = myproc();
    80004638:	ad0fd0ef          	jal	80001908 <myproc>
    8000463c:	89aa                	mv	s3,a0

  acquire(&pi->lock);
    8000463e:	8526                	mv	a0,s1
    80004640:	da8fc0ef          	jal	80000be8 <acquire>
  while (i < n) {
    80004644:	0f405a63          	blez	s4,80004738 <pipewrite+0x118>
    80004648:	f85a                	sd	s6,48(sp)
    8000464a:	f45e                	sd	s7,40(sp)
    8000464c:	f062                	sd	s8,32(sp)
    8000464e:	ec66                	sd	s9,24(sp)
    80004650:	e86a                	sd	s10,16(sp)
  int i = 0;
    80004652:	4901                	li	s2,0
      release(&pi->lock);
      sleep();
      acquire(&pi->lock);
    } else {
      char ch;
      if (copyin(pr->pagetable, pr->sz, &ch, addr + i, 1) == -1) {
    80004654:	f9f40c13          	addi	s8,s0,-97
    80004658:	4b85                	li	s7,1
    8000465a:	5b7d                	li	s6,-1
      wakeup(&pi->nread);
    8000465c:	21848d13          	addi	s10,s1,536
      sleep_prepare(&pi->nwrite);
    80004660:	21c48c93          	addi	s9,s1,540
    80004664:	a0a1                	j	800046ac <pipewrite+0x8c>
      release(&pi->lock);
    80004666:	8526                	mv	a0,s1
    80004668:	e08fc0ef          	jal	80000c70 <release>
      return -1;
    8000466c:	597d                	li	s2,-1
    8000466e:	7b42                	ld	s6,48(sp)
    80004670:	7ba2                	ld	s7,40(sp)
    80004672:	7c02                	ld	s8,32(sp)
    80004674:	6ce2                	ld	s9,24(sp)
    80004676:	6d42                	ld	s10,16(sp)
  }
  wakeup(&pi->nread);
  release(&pi->lock);

  return i;
}
    80004678:	854a                	mv	a0,s2
    8000467a:	70a6                	ld	ra,104(sp)
    8000467c:	7406                	ld	s0,96(sp)
    8000467e:	64e6                	ld	s1,88(sp)
    80004680:	6946                	ld	s2,80(sp)
    80004682:	69a6                	ld	s3,72(sp)
    80004684:	6a06                	ld	s4,64(sp)
    80004686:	7ae2                	ld	s5,56(sp)
    80004688:	6165                	addi	sp,sp,112
    8000468a:	8082                	ret
      wakeup(&pi->nread);
    8000468c:	856a                	mv	a0,s10
    8000468e:	8f1fd0ef          	jal	80001f7e <wakeup>
      sleep_prepare(&pi->nwrite);
    80004692:	8566                	mv	a0,s9
    80004694:	87ffd0ef          	jal	80001f12 <sleep_prepare>
      release(&pi->lock);
    80004698:	8526                	mv	a0,s1
    8000469a:	dd6fc0ef          	jal	80000c70 <release>
      sleep();
    8000469e:	8b1fd0ef          	jal	80001f4e <sleep>
      acquire(&pi->lock);
    800046a2:	8526                	mv	a0,s1
    800046a4:	d44fc0ef          	jal	80000be8 <acquire>
  while (i < n) {
    800046a8:	07495b63          	bge	s2,s4,8000471e <pipewrite+0xfe>
    if (pi->readopen == 0 || killed(pr)) {
    800046ac:	2204a783          	lw	a5,544(s1)
    800046b0:	dbdd                	beqz	a5,80004666 <pipewrite+0x46>
    800046b2:	854e                	mv	a0,s3
    800046b4:	abdfd0ef          	jal	80002170 <killed>
    800046b8:	f55d                	bnez	a0,80004666 <pipewrite+0x46>
    if (pi->nwrite == pi->nread + PIPESIZE) { //DOC: pipewrite-full
    800046ba:	2184a783          	lw	a5,536(s1)
    800046be:	21c4a703          	lw	a4,540(s1)
    800046c2:	2007879b          	addiw	a5,a5,512
    800046c6:	fcf703e3          	beq	a4,a5,8000468c <pipewrite+0x6c>
      if (copyin(pr->pagetable, pr->sz, &ch, addr + i, 1) == -1) {
    800046ca:	875e                	mv	a4,s7
    800046cc:	015906b3          	add	a3,s2,s5
    800046d0:	8662                	mv	a2,s8
    800046d2:	0489b583          	ld	a1,72(s3)
    800046d6:	0509b503          	ld	a0,80(s3)
    800046da:	f2ffc0ef          	jal	80001608 <copyin>
    800046de:	03650163          	beq	a0,s6,80004700 <pipewrite+0xe0>
      pi->data[pi->nwrite++ % PIPESIZE] = ch;
    800046e2:	21c4a783          	lw	a5,540(s1)
    800046e6:	0017871b          	addiw	a4,a5,1
    800046ea:	20e4ae23          	sw	a4,540(s1)
    800046ee:	1ff7f793          	andi	a5,a5,511
    800046f2:	97a6                	add	a5,a5,s1
    800046f4:	f9f44703          	lbu	a4,-97(s0)
    800046f8:	00e78c23          	sb	a4,24(a5)
      i++;
    800046fc:	2905                	addiw	s2,s2,1
    800046fe:	b76d                	j	800046a8 <pipewrite+0x88>
        if (i == 0)
    80004700:	00090863          	beqz	s2,80004710 <pipewrite+0xf0>
    80004704:	7b42                	ld	s6,48(sp)
    80004706:	7ba2                	ld	s7,40(sp)
    80004708:	7c02                	ld	s8,32(sp)
    8000470a:	6ce2                	ld	s9,24(sp)
    8000470c:	6d42                	ld	s10,16(sp)
    8000470e:	a829                	j	80004728 <pipewrite+0x108>
          i = -1;
    80004710:	892a                	mv	s2,a0
        break;
    80004712:	7b42                	ld	s6,48(sp)
    80004714:	7ba2                	ld	s7,40(sp)
    80004716:	7c02                	ld	s8,32(sp)
    80004718:	6ce2                	ld	s9,24(sp)
    8000471a:	6d42                	ld	s10,16(sp)
    8000471c:	a031                	j	80004728 <pipewrite+0x108>
    8000471e:	7b42                	ld	s6,48(sp)
    80004720:	7ba2                	ld	s7,40(sp)
    80004722:	7c02                	ld	s8,32(sp)
    80004724:	6ce2                	ld	s9,24(sp)
    80004726:	6d42                	ld	s10,16(sp)
  wakeup(&pi->nread);
    80004728:	21848513          	addi	a0,s1,536
    8000472c:	853fd0ef          	jal	80001f7e <wakeup>
  release(&pi->lock);
    80004730:	8526                	mv	a0,s1
    80004732:	d3efc0ef          	jal	80000c70 <release>
  return i;
    80004736:	b789                	j	80004678 <pipewrite+0x58>
  int i = 0;
    80004738:	4901                	li	s2,0
    8000473a:	b7fd                	j	80004728 <pipewrite+0x108>

000000008000473c <piperead>:

int
piperead(struct pipe *pi, uint64 addr, int n)
{
    8000473c:	711d                	addi	sp,sp,-96
    8000473e:	ec86                	sd	ra,88(sp)
    80004740:	e8a2                	sd	s0,80(sp)
    80004742:	e4a6                	sd	s1,72(sp)
    80004744:	e0ca                	sd	s2,64(sp)
    80004746:	fc4e                	sd	s3,56(sp)
    80004748:	f852                	sd	s4,48(sp)
    8000474a:	f456                	sd	s5,40(sp)
    8000474c:	1080                	addi	s0,sp,96
    8000474e:	84aa                	mv	s1,a0
    80004750:	89ae                	mv	s3,a1
    80004752:	8ab2                	mv	s5,a2
  int i;
  struct proc *pr = myproc();
    80004754:	9b4fd0ef          	jal	80001908 <myproc>
    80004758:	892a                	mv	s2,a0
  char ch;

  acquire(&pi->lock);
    8000475a:	8526                	mv	a0,s1
    8000475c:	c8cfc0ef          	jal	80000be8 <acquire>
  while (pi->nread == pi->nwrite && pi->writeopen) { //DOC: pipe-empty
    80004760:	2184a703          	lw	a4,536(s1)
    80004764:	21c4a783          	lw	a5,540(s1)
    if (killed(pr)) {
      release(&pi->lock);
      return -1;
    }
    sleep_prepare(&pi->nread); //DOC: piperead-sleep
    80004768:	21848a13          	addi	s4,s1,536
  while (pi->nread == pi->nwrite && pi->writeopen) { //DOC: pipe-empty
    8000476c:	02f71e63          	bne	a4,a5,800047a8 <piperead+0x6c>
    80004770:	2244a783          	lw	a5,548(s1)
    80004774:	c3b9                	beqz	a5,800047ba <piperead+0x7e>
    if (killed(pr)) {
    80004776:	854a                	mv	a0,s2
    80004778:	9f9fd0ef          	jal	80002170 <killed>
    8000477c:	e915                	bnez	a0,800047b0 <piperead+0x74>
    sleep_prepare(&pi->nread); //DOC: piperead-sleep
    8000477e:	8552                	mv	a0,s4
    80004780:	f92fd0ef          	jal	80001f12 <sleep_prepare>
    release(&pi->lock);
    80004784:	8526                	mv	a0,s1
    80004786:	ceafc0ef          	jal	80000c70 <release>
    sleep();
    8000478a:	fc4fd0ef          	jal	80001f4e <sleep>
    acquire(&pi->lock);
    8000478e:	8526                	mv	a0,s1
    80004790:	c58fc0ef          	jal	80000be8 <acquire>
  while (pi->nread == pi->nwrite && pi->writeopen) { //DOC: pipe-empty
    80004794:	2184a703          	lw	a4,536(s1)
    80004798:	21c4a783          	lw	a5,540(s1)
    8000479c:	fcf70ae3          	beq	a4,a5,80004770 <piperead+0x34>
    800047a0:	f05a                	sd	s6,32(sp)
    800047a2:	ec5e                	sd	s7,24(sp)
    800047a4:	e862                	sd	s8,16(sp)
    800047a6:	a829                	j	800047c0 <piperead+0x84>
    800047a8:	f05a                	sd	s6,32(sp)
    800047aa:	ec5e                	sd	s7,24(sp)
    800047ac:	e862                	sd	s8,16(sp)
    800047ae:	a809                	j	800047c0 <piperead+0x84>
      release(&pi->lock);
    800047b0:	8526                	mv	a0,s1
    800047b2:	cbefc0ef          	jal	80000c70 <release>
      return -1;
    800047b6:	5a7d                	li	s4,-1
    800047b8:	a0b5                	j	80004824 <piperead+0xe8>
    800047ba:	f05a                	sd	s6,32(sp)
    800047bc:	ec5e                	sd	s7,24(sp)
    800047be:	e862                	sd	s8,16(sp)
  }
  for (i = 0; i < n; i++) { //DOC: piperead-copy
    800047c0:	4a01                	li	s4,0
    if (pi->nread == pi->nwrite)
      break;
    ch = pi->data[pi->nread % PIPESIZE];
    if (copyout(pr->pagetable, pr->sz, addr + i, &ch, 1) == -1) {
    800047c2:	faf40c13          	addi	s8,s0,-81
    800047c6:	4b85                	li	s7,1
    800047c8:	5b7d                	li	s6,-1
  for (i = 0; i < n; i++) { //DOC: piperead-copy
    800047ca:	05505363          	blez	s5,80004810 <piperead+0xd4>
    if (pi->nread == pi->nwrite)
    800047ce:	2184a783          	lw	a5,536(s1)
    800047d2:	21c4a703          	lw	a4,540(s1)
    800047d6:	02f70d63          	beq	a4,a5,80004810 <piperead+0xd4>
    ch = pi->data[pi->nread % PIPESIZE];
    800047da:	1ff7f793          	andi	a5,a5,511
    800047de:	97a6                	add	a5,a5,s1
    800047e0:	0187c783          	lbu	a5,24(a5)
    800047e4:	faf407a3          	sb	a5,-81(s0)
    if (copyout(pr->pagetable, pr->sz, addr + i, &ch, 1) == -1) {
    800047e8:	875e                	mv	a4,s7
    800047ea:	86e2                	mv	a3,s8
    800047ec:	864e                	mv	a2,s3
    800047ee:	04893583          	ld	a1,72(s2)
    800047f2:	05093503          	ld	a0,80(s2)
    800047f6:	d4dfc0ef          	jal	80001542 <copyout>
    800047fa:	03650f63          	beq	a0,s6,80004838 <piperead+0xfc>
      if (i == 0)
        i = -1;
      break;
    }
    pi->nread++;
    800047fe:	2184a783          	lw	a5,536(s1)
    80004802:	2785                	addiw	a5,a5,1
    80004804:	20f4ac23          	sw	a5,536(s1)
  for (i = 0; i < n; i++) { //DOC: piperead-copy
    80004808:	2a05                	addiw	s4,s4,1
    8000480a:	0985                	addi	s3,s3,1
    8000480c:	fd4a91e3          	bne	s5,s4,800047ce <piperead+0x92>
  }
  wakeup(&pi->nwrite); //DOC: piperead-wakeup
    80004810:	21c48513          	addi	a0,s1,540
    80004814:	f6afd0ef          	jal	80001f7e <wakeup>
  release(&pi->lock);
    80004818:	8526                	mv	a0,s1
    8000481a:	c56fc0ef          	jal	80000c70 <release>
    8000481e:	7b02                	ld	s6,32(sp)
    80004820:	6be2                	ld	s7,24(sp)
    80004822:	6c42                	ld	s8,16(sp)
  return i;
}
    80004824:	8552                	mv	a0,s4
    80004826:	60e6                	ld	ra,88(sp)
    80004828:	6446                	ld	s0,80(sp)
    8000482a:	64a6                	ld	s1,72(sp)
    8000482c:	6906                	ld	s2,64(sp)
    8000482e:	79e2                	ld	s3,56(sp)
    80004830:	7a42                	ld	s4,48(sp)
    80004832:	7aa2                	ld	s5,40(sp)
    80004834:	6125                	addi	sp,sp,96
    80004836:	8082                	ret
      if (i == 0)
    80004838:	fc0a1ce3          	bnez	s4,80004810 <piperead+0xd4>
        i = -1;
    8000483c:	8a2a                	mv	s4,a0
    8000483e:	bfc9                	j	80004810 <piperead+0xd4>

0000000080004840 <flags2perm>:
static int loadseg(pde_t *, uint64, struct inode *, uint, uint);

// map ELF permissions to PTE permission bits.
int
flags2perm(int flags)
{
    80004840:	1141                	addi	sp,sp,-16
    80004842:	e406                	sd	ra,8(sp)
    80004844:	e022                	sd	s0,0(sp)
    80004846:	0800                	addi	s0,sp,16
    80004848:	87aa                	mv	a5,a0
  int perm = 0;
  if (flags & 0x1)
    8000484a:	0035151b          	slliw	a0,a0,0x3
    8000484e:	8921                	andi	a0,a0,8
    perm = PTE_X;
  if (flags & 0x2)
    80004850:	8b89                	andi	a5,a5,2
    80004852:	c399                	beqz	a5,80004858 <flags2perm+0x18>
    perm |= PTE_W;
    80004854:	00456513          	ori	a0,a0,4
  return perm;
}
    80004858:	60a2                	ld	ra,8(sp)
    8000485a:	6402                	ld	s0,0(sp)
    8000485c:	0141                	addi	sp,sp,16
    8000485e:	8082                	ret

0000000080004860 <kexec>:
//
// the implementation of the exec() system call
//
int
kexec(char *path, char **argv)
{
    80004860:	de010113          	addi	sp,sp,-544
    80004864:	20113c23          	sd	ra,536(sp)
    80004868:	20813823          	sd	s0,528(sp)
    8000486c:	20913423          	sd	s1,520(sp)
    80004870:	21213023          	sd	s2,512(sp)
    80004874:	1400                	addi	s0,sp,544
    80004876:	892a                	mv	s2,a0
    80004878:	dea43823          	sd	a0,-528(s0)
    8000487c:	e0b43023          	sd	a1,-512(s0)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
  struct elfhdr elf;
  struct inode *ip;
  struct proghdr ph;
  pagetable_t pagetable = 0, oldpagetable;
  struct proc *p = myproc();
    80004880:	888fd0ef          	jal	80001908 <myproc>
    80004884:	84aa                	mv	s1,a0

  begin_op();
    80004886:	c86ff0ef          	jal	80003d0c <begin_op>

  // Open the executable file.
  if ((ip = namei(path)) == 0) {
    8000488a:	854a                	mv	a0,s2
    8000488c:	aa2ff0ef          	jal	80003b2e <namei>
    80004890:	cd21                	beqz	a0,800048e8 <kexec+0x88>
    80004892:	fbd2                	sd	s4,496(sp)
    80004894:	8a2a                	mv	s4,a0
    end_op();
    return -1;
  }
  ilock(ip);
    80004896:	9fffe0ef          	jal	80003294 <ilock>

  // Read the ELF header.
  if (readi(ip, 0, (uint64)&elf, 0, sizeof(elf)) != sizeof(elf))
    8000489a:	04000713          	li	a4,64
    8000489e:	4681                	li	a3,0
    800048a0:	e5040613          	addi	a2,s0,-432
    800048a4:	4581                	li	a1,0
    800048a6:	8552                	mv	a0,s4
    800048a8:	dc7fe0ef          	jal	8000366e <readi>
    800048ac:	04000793          	li	a5,64
    800048b0:	00f51a63          	bne	a0,a5,800048c4 <kexec+0x64>
    goto bad;

  // Is this really an ELF file?
  if (elf.magic != ELF_MAGIC)
    800048b4:	e5042703          	lw	a4,-432(s0)
    800048b8:	464c47b7          	lui	a5,0x464c4
    800048bc:	57f78793          	addi	a5,a5,1407 # 464c457f <_entry-0x39b3ba81>
    800048c0:	02f70863          	beq	a4,a5,800048f0 <kexec+0x90>

bad:
  if (pagetable)
    proc_freepagetable(pagetable, sz);
  if (ip) {
    iunlockput(ip);
    800048c4:	8552                	mv	a0,s4
    800048c6:	c23fe0ef          	jal	800034e8 <iunlockput>
    end_op();
    800048ca:	cceff0ef          	jal	80003d98 <end_op>
  }
  return -1;
    800048ce:	557d                	li	a0,-1
    800048d0:	7a5e                	ld	s4,496(sp)
}
    800048d2:	21813083          	ld	ra,536(sp)
    800048d6:	21013403          	ld	s0,528(sp)
    800048da:	20813483          	ld	s1,520(sp)
    800048de:	20013903          	ld	s2,512(sp)
    800048e2:	22010113          	addi	sp,sp,544
    800048e6:	8082                	ret
    end_op();
    800048e8:	cb0ff0ef          	jal	80003d98 <end_op>
    return -1;
    800048ec:	557d                	li	a0,-1
    800048ee:	b7d5                	j	800048d2 <kexec+0x72>
    800048f0:	f3da                	sd	s6,480(sp)
  if ((pagetable = proc_pagetable(p)) == 0)
    800048f2:	8526                	mv	a0,s1
    800048f4:	91afd0ef          	jal	80001a0e <proc_pagetable>
    800048f8:	8b2a                	mv	s6,a0
    800048fa:	26050e63          	beqz	a0,80004b76 <kexec+0x316>
    800048fe:	ffce                	sd	s3,504(sp)
    80004900:	f7d6                	sd	s5,488(sp)
    80004902:	efde                	sd	s7,472(sp)
    80004904:	ebe2                	sd	s8,464(sp)
    80004906:	e7e6                	sd	s9,456(sp)
    80004908:	e3ea                	sd	s10,448(sp)
  for (i = 0, off = elf.phoff; i < elf.phnum; i++, off += sizeof(ph)) {
    8000490a:	e8845783          	lhu	a5,-376(s0)
    8000490e:	14078263          	beqz	a5,80004a52 <kexec+0x1f2>
    80004912:	ff6e                	sd	s11,440(sp)
    80004914:	e7042683          	lw	a3,-400(s0)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    80004918:	4901                	li	s2,0
  for (i = 0, off = elf.phoff; i < elf.phnum; i++, off += sizeof(ph)) {
    8000491a:	4d01                	li	s10,0
    if (readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
    8000491c:	03800d93          	li	s11,56
    if (ph.vaddr % PGSIZE != 0)
    80004920:	6c85                	lui	s9,0x1
    80004922:	fffc8793          	addi	a5,s9,-1 # fff <_entry-0x7ffff001>
    80004926:	def43423          	sd	a5,-536(s0)

  for (i = 0; i < sz; i += PGSIZE) {
    pa = walkaddr(pagetable, va + i);
    if (pa == 0)
      panic("loadseg: address should exist");
    if (sz - i < PGSIZE)
    8000492a:	6a85                	lui	s5,0x1
    8000492c:	a085                	j	8000498c <kexec+0x12c>
      panic("loadseg: address should exist");
    8000492e:	00003517          	auipc	a0,0x3
    80004932:	caa50513          	addi	a0,a0,-854 # 800075d8 <etext+0x5d8>
    80004936:	efffb0ef          	jal	80000834 <panic>
    if (sz - i < PGSIZE)
    8000493a:	2901                	sext.w	s2,s2
      n = sz - i;
    else
      n = PGSIZE;
    if (readi(ip, 0, (uint64)pa, offset + i, n) != n)
    8000493c:	874a                	mv	a4,s2
    8000493e:	009b86bb          	addw	a3,s7,s1
    80004942:	4581                	li	a1,0
    80004944:	8552                	mv	a0,s4
    80004946:	d29fe0ef          	jal	8000366e <readi>
    8000494a:	22a91a63          	bne	s2,a0,80004b7e <kexec+0x31e>
  for (i = 0; i < sz; i += PGSIZE) {
    8000494e:	009a84bb          	addw	s1,s5,s1
    80004952:	0334f263          	bgeu	s1,s3,80004976 <kexec+0x116>
    pa = walkaddr(pagetable, va + i);
    80004956:	02049593          	slli	a1,s1,0x20
    8000495a:	9181                	srli	a1,a1,0x20
    8000495c:	95e2                	add	a1,a1,s8
    8000495e:	855a                	mv	a0,s6
    80004960:	e78fc0ef          	jal	80000fd8 <walkaddr>
    80004964:	862a                	mv	a2,a0
    if (pa == 0)
    80004966:	d561                	beqz	a0,8000492e <kexec+0xce>
    if (sz - i < PGSIZE)
    80004968:	409987bb          	subw	a5,s3,s1
    8000496c:	893e                	mv	s2,a5
    8000496e:	fcfcf6e3          	bgeu	s9,a5,8000493a <kexec+0xda>
    80004972:	8956                	mv	s2,s5
    80004974:	b7d9                	j	8000493a <kexec+0xda>
    sz = sz1;
    80004976:	df843903          	ld	s2,-520(s0)
  for (i = 0, off = elf.phoff; i < elf.phnum; i++, off += sizeof(ph)) {
    8000497a:	2d05                	addiw	s10,s10,1
    8000497c:	e0843783          	ld	a5,-504(s0)
    80004980:	0387869b          	addiw	a3,a5,56
    80004984:	e8845783          	lhu	a5,-376(s0)
    80004988:	06fd5d63          	bge	s10,a5,80004a02 <kexec+0x1a2>
    if (readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
    8000498c:	e0d43423          	sd	a3,-504(s0)
    80004990:	876e                	mv	a4,s11
    80004992:	e1840613          	addi	a2,s0,-488
    80004996:	4581                	li	a1,0
    80004998:	8552                	mv	a0,s4
    8000499a:	cd5fe0ef          	jal	8000366e <readi>
    8000499e:	1db51e63          	bne	a0,s11,80004b7a <kexec+0x31a>
    if (ph.type != ELF_PROG_LOAD)
    800049a2:	e1842783          	lw	a5,-488(s0)
    800049a6:	4705                	li	a4,1
    800049a8:	fce799e3          	bne	a5,a4,8000497a <kexec+0x11a>
    if (ph.memsz < ph.filesz)
    800049ac:	e4043483          	ld	s1,-448(s0)
    800049b0:	e3843783          	ld	a5,-456(s0)
    800049b4:	1ef4e363          	bltu	s1,a5,80004b9a <kexec+0x33a>
    if (ph.vaddr + ph.memsz < ph.vaddr)
    800049b8:	e2843783          	ld	a5,-472(s0)
    800049bc:	94be                	add	s1,s1,a5
    800049be:	1ef4e163          	bltu	s1,a5,80004ba0 <kexec+0x340>
    if (ph.vaddr % PGSIZE != 0)
    800049c2:	de843703          	ld	a4,-536(s0)
    800049c6:	8ff9                	and	a5,a5,a4
    800049c8:	1c079f63          	bnez	a5,80004ba6 <kexec+0x346>
    if ((sz1 = uvmalloc(pagetable, sz, ph.vaddr + ph.memsz,
    800049cc:	e1c42503          	lw	a0,-484(s0)
    800049d0:	e71ff0ef          	jal	80004840 <flags2perm>
    800049d4:	86aa                	mv	a3,a0
    800049d6:	8626                	mv	a2,s1
    800049d8:	85ca                	mv	a1,s2
    800049da:	855a                	mv	a0,s6
    800049dc:	8d3fc0ef          	jal	800012ae <uvmalloc>
    800049e0:	dea43c23          	sd	a0,-520(s0)
    800049e4:	1c050463          	beqz	a0,80004bac <kexec+0x34c>
    if (loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
    800049e8:	e3842983          	lw	s3,-456(s0)
  for (i = 0; i < sz; i += PGSIZE) {
    800049ec:	00098863          	beqz	s3,800049fc <kexec+0x19c>
    if (loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
    800049f0:	e2843c03          	ld	s8,-472(s0)
    800049f4:	e2042b83          	lw	s7,-480(s0)
  for (i = 0; i < sz; i += PGSIZE) {
    800049f8:	4481                	li	s1,0
    800049fa:	bfb1                	j	80004956 <kexec+0xf6>
    sz = sz1;
    800049fc:	df843903          	ld	s2,-520(s0)
    80004a00:	bfad                	j	8000497a <kexec+0x11a>
    80004a02:	7dfa                	ld	s11,440(sp)
  iunlockput(ip);
    80004a04:	8552                	mv	a0,s4
    80004a06:	ae3fe0ef          	jal	800034e8 <iunlockput>
  end_op();
    80004a0a:	b8eff0ef          	jal	80003d98 <end_op>
  p = myproc();
    80004a0e:	efbfc0ef          	jal	80001908 <myproc>
    80004a12:	89aa                	mv	s3,a0
  uint64 oldsz = p->sz;
    80004a14:	04853a83          	ld	s5,72(a0)
  sz = PGROUNDUP(sz);
    80004a18:	6c05                	lui	s8,0x1
    80004a1a:	1c7d                	addi	s8,s8,-1 # fff <_entry-0x7ffff001>
    80004a1c:	9c4a                	add	s8,s8,s2
    80004a1e:	77fd                	lui	a5,0xfffff
    80004a20:	00fc7c33          	and	s8,s8,a5
  if ((sz1 = uvmalloc(pagetable, sz, sz + (USERSTACK + 1) * PGSIZE, PTE_W)) ==
    80004a24:	4691                	li	a3,4
    80004a26:	6609                	lui	a2,0x2
    80004a28:	9662                	add	a2,a2,s8
    80004a2a:	85e2                	mv	a1,s8
    80004a2c:	855a                	mv	a0,s6
    80004a2e:	881fc0ef          	jal	800012ae <uvmalloc>
    80004a32:	892a                	mv	s2,a0
    80004a34:	e10d                	bnez	a0,80004a56 <kexec+0x1f6>
    proc_freepagetable(pagetable, sz);
    80004a36:	85e2                	mv	a1,s8
    80004a38:	855a                	mv	a0,s6
    80004a3a:	858fd0ef          	jal	80001a92 <proc_freepagetable>
  return -1;
    80004a3e:	557d                	li	a0,-1
    80004a40:	79fe                	ld	s3,504(sp)
    80004a42:	7a5e                	ld	s4,496(sp)
    80004a44:	7abe                	ld	s5,488(sp)
    80004a46:	7b1e                	ld	s6,480(sp)
    80004a48:	6bfe                	ld	s7,472(sp)
    80004a4a:	6c5e                	ld	s8,464(sp)
    80004a4c:	6cbe                	ld	s9,456(sp)
    80004a4e:	6d1e                	ld	s10,448(sp)
    80004a50:	b549                	j	800048d2 <kexec+0x72>
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    80004a52:	4901                	li	s2,0
    80004a54:	bf45                	j	80004a04 <kexec+0x1a4>
  uvmclear(pagetable, sz - (USERSTACK + 1) * PGSIZE);
    80004a56:	75f9                	lui	a1,0xffffe
    80004a58:	95aa                	add	a1,a1,a0
    80004a5a:	855a                	mv	a0,s6
    80004a5c:	a25fc0ef          	jal	80001480 <uvmclear>
  stackbase = sp - USERSTACK * PGSIZE;
    80004a60:	80090a13          	addi	s4,s2,-2048
    80004a64:	800a0a13          	addi	s4,s4,-2048
  for (argc = 0; argv[argc]; argc++) {
    80004a68:	e0043783          	ld	a5,-512(s0)
    80004a6c:	6388                	ld	a0,0(a5)
    80004a6e:	c545                	beqz	a0,80004b16 <kexec+0x2b6>
  sp = sz;
    80004a70:	8c4a                	mv	s8,s2
  for (argc = 0; argv[argc]; argc++) {
    80004a72:	4481                	li	s1,0
    ustack[argc] = sp;
    80004a74:	e9040b93          	addi	s7,s0,-368
    sp -= strlen(argv[argc]) + 1;
    80004a78:	bbafc0ef          	jal	80000e32 <strlen>
    80004a7c:	0015079b          	addiw	a5,a0,1
    80004a80:	40fc07b3          	sub	a5,s8,a5
    sp -= sp % 16; // riscv sp must be 16-byte aligned
    80004a84:	ff07fc13          	andi	s8,a5,-16
    if (sp < stackbase)
    80004a88:	134c6563          	bltu	s8,s4,80004bb2 <kexec+0x352>
    if (copyout(pagetable, sz, sp, argv[argc], strlen(argv[argc]) + 1) < 0)
    80004a8c:	e0043d03          	ld	s10,-512(s0)
    80004a90:	000d3c83          	ld	s9,0(s10)
    80004a94:	8566                	mv	a0,s9
    80004a96:	b9cfc0ef          	jal	80000e32 <strlen>
    80004a9a:	0015071b          	addiw	a4,a0,1
    80004a9e:	86e6                	mv	a3,s9
    80004aa0:	8662                	mv	a2,s8
    80004aa2:	85ca                	mv	a1,s2
    80004aa4:	855a                	mv	a0,s6
    80004aa6:	a9dfc0ef          	jal	80001542 <copyout>
    80004aaa:	10054663          	bltz	a0,80004bb6 <kexec+0x356>
    ustack[argc] = sp;
    80004aae:	00349793          	slli	a5,s1,0x3
    80004ab2:	97de                	add	a5,a5,s7
    80004ab4:	0187b023          	sd	s8,0(a5) # fffffffffffff000 <end+0xffffffff7ffdb9b0>
  for (argc = 0; argv[argc]; argc++) {
    80004ab8:	0485                	addi	s1,s1,1
    80004aba:	008d0793          	addi	a5,s10,8
    80004abe:	e0f43023          	sd	a5,-512(s0)
    80004ac2:	008d3503          	ld	a0,8(s10)
    80004ac6:	f94d                	bnez	a0,80004a78 <kexec+0x218>
  ustack[argc] = 0;
    80004ac8:	00349793          	slli	a5,s1,0x3
    80004acc:	f9078793          	addi	a5,a5,-112
    80004ad0:	97a2                	add	a5,a5,s0
    80004ad2:	f007b023          	sd	zero,-256(a5)
  sp -= (argc + 1) * sizeof(uint64);
    80004ad6:	00349713          	slli	a4,s1,0x3
    80004ada:	0721                	addi	a4,a4,8
    80004adc:	40ec0bb3          	sub	s7,s8,a4
  sp -= sp % 16;
    80004ae0:	ff0bfb93          	andi	s7,s7,-16
  sz = sz1;
    80004ae4:	8c4a                	mv	s8,s2
  if (sp < stackbase)
    80004ae6:	f54be8e3          	bltu	s7,s4,80004a36 <kexec+0x1d6>
  if (copyout(pagetable, sz, sp, (char *)ustack, (argc + 1) * sizeof(uint64)) <
    80004aea:	e9040693          	addi	a3,s0,-368
    80004aee:	865e                	mv	a2,s7
    80004af0:	85ca                	mv	a1,s2
    80004af2:	855a                	mv	a0,s6
    80004af4:	a4ffc0ef          	jal	80001542 <copyout>
    80004af8:	f2054fe3          	bltz	a0,80004a36 <kexec+0x1d6>
  p->trapframe->a1 = sp;
    80004afc:	0589b783          	ld	a5,88(s3)
    80004b00:	0777bc23          	sd	s7,120(a5)
  for (last = s = path; *s; s++)
    80004b04:	df043783          	ld	a5,-528(s0)
    80004b08:	0007c703          	lbu	a4,0(a5)
    80004b0c:	c30d                	beqz	a4,80004b2e <kexec+0x2ce>
    80004b0e:	0785                	addi	a5,a5,1
    if (*s == '/')
    80004b10:	02f00693          	li	a3,47
    80004b14:	a801                	j	80004b24 <kexec+0x2c4>
  sp = sz;
    80004b16:	8c4a                	mv	s8,s2
  for (argc = 0; argv[argc]; argc++) {
    80004b18:	4481                	li	s1,0
    80004b1a:	b77d                	j	80004ac8 <kexec+0x268>
  for (last = s = path; *s; s++)
    80004b1c:	0785                	addi	a5,a5,1
    80004b1e:	fff7c703          	lbu	a4,-1(a5)
    80004b22:	c711                	beqz	a4,80004b2e <kexec+0x2ce>
    if (*s == '/')
    80004b24:	fed71ce3          	bne	a4,a3,80004b1c <kexec+0x2bc>
      last = s + 1;
    80004b28:	def43823          	sd	a5,-528(s0)
    80004b2c:	bfc5                	j	80004b1c <kexec+0x2bc>
  safestrcpy(p->name, last, sizeof(p->name));
    80004b2e:	4641                	li	a2,16
    80004b30:	df043583          	ld	a1,-528(s0)
    80004b34:	15898513          	addi	a0,s3,344
    80004b38:	ac4fc0ef          	jal	80000dfc <safestrcpy>
  oldpagetable = p->pagetable;
    80004b3c:	0509b503          	ld	a0,80(s3)
  p->pagetable = pagetable;
    80004b40:	0569b823          	sd	s6,80(s3)
  p->sz = sz;
    80004b44:	0529b423          	sd	s2,72(s3)
  p->trapframe->epc = elf.entry; // initial program counter = ulib.c:start()
    80004b48:	0589b783          	ld	a5,88(s3)
    80004b4c:	e6843703          	ld	a4,-408(s0)
    80004b50:	ef98                	sd	a4,24(a5)
  p->trapframe->sp = sp;         // initial stack pointer
    80004b52:	0589b783          	ld	a5,88(s3)
    80004b56:	0377b823          	sd	s7,48(a5)
  proc_freepagetable(oldpagetable, oldsz);
    80004b5a:	85d6                	mv	a1,s5
    80004b5c:	f37fc0ef          	jal	80001a92 <proc_freepagetable>
  return argc; // this ends up in a0, the first argument to main(argc, argv)
    80004b60:	0004851b          	sext.w	a0,s1
    80004b64:	79fe                	ld	s3,504(sp)
    80004b66:	7a5e                	ld	s4,496(sp)
    80004b68:	7abe                	ld	s5,488(sp)
    80004b6a:	7b1e                	ld	s6,480(sp)
    80004b6c:	6bfe                	ld	s7,472(sp)
    80004b6e:	6c5e                	ld	s8,464(sp)
    80004b70:	6cbe                	ld	s9,456(sp)
    80004b72:	6d1e                	ld	s10,448(sp)
    80004b74:	bbb9                	j	800048d2 <kexec+0x72>
    80004b76:	7b1e                	ld	s6,480(sp)
    80004b78:	b3b1                	j	800048c4 <kexec+0x64>
    80004b7a:	df243c23          	sd	s2,-520(s0)
    proc_freepagetable(pagetable, sz);
    80004b7e:	df843583          	ld	a1,-520(s0)
    80004b82:	855a                	mv	a0,s6
    80004b84:	f0ffc0ef          	jal	80001a92 <proc_freepagetable>
  if (ip) {
    80004b88:	79fe                	ld	s3,504(sp)
    80004b8a:	7abe                	ld	s5,488(sp)
    80004b8c:	7b1e                	ld	s6,480(sp)
    80004b8e:	6bfe                	ld	s7,472(sp)
    80004b90:	6c5e                	ld	s8,464(sp)
    80004b92:	6cbe                	ld	s9,456(sp)
    80004b94:	6d1e                	ld	s10,448(sp)
    80004b96:	7dfa                	ld	s11,440(sp)
    80004b98:	b335                	j	800048c4 <kexec+0x64>
    80004b9a:	df243c23          	sd	s2,-520(s0)
    80004b9e:	b7c5                	j	80004b7e <kexec+0x31e>
    80004ba0:	df243c23          	sd	s2,-520(s0)
    80004ba4:	bfe9                	j	80004b7e <kexec+0x31e>
    80004ba6:	df243c23          	sd	s2,-520(s0)
    80004baa:	bfd1                	j	80004b7e <kexec+0x31e>
    80004bac:	df243c23          	sd	s2,-520(s0)
    80004bb0:	b7f9                	j	80004b7e <kexec+0x31e>
  sz = sz1;
    80004bb2:	8c4a                	mv	s8,s2
    80004bb4:	b549                	j	80004a36 <kexec+0x1d6>
    80004bb6:	8c4a                	mv	s8,s2
    80004bb8:	bdbd                	j	80004a36 <kexec+0x1d6>

0000000080004bba <argfd>:

// Fetch the nth word-sized system call argument as a file descriptor
// and return both the descriptor and the corresponding struct file.
static int
argfd(int n, int *pfd, struct file **pf)
{
    80004bba:	7179                	addi	sp,sp,-48
    80004bbc:	f406                	sd	ra,40(sp)
    80004bbe:	f022                	sd	s0,32(sp)
    80004bc0:	ec26                	sd	s1,24(sp)
    80004bc2:	e84a                	sd	s2,16(sp)
    80004bc4:	1800                	addi	s0,sp,48
    80004bc6:	892e                	mv	s2,a1
    80004bc8:	84b2                	mv	s1,a2
  int fd;
  struct file *f;

  argint(n, &fd);
    80004bca:	fdc40593          	addi	a1,s0,-36
    80004bce:	c83fd0ef          	jal	80002850 <argint>
  if (fd < 0 || fd >= NOFILE || (f = myproc()->ofile[fd]) == 0)
    80004bd2:	fdc42703          	lw	a4,-36(s0)
    80004bd6:	47bd                	li	a5,15
    80004bd8:	02e7ea63          	bltu	a5,a4,80004c0c <argfd+0x52>
    80004bdc:	d2dfc0ef          	jal	80001908 <myproc>
    80004be0:	fdc42703          	lw	a4,-36(s0)
    80004be4:	00371793          	slli	a5,a4,0x3
    80004be8:	0d078793          	addi	a5,a5,208
    80004bec:	953e                	add	a0,a0,a5
    80004bee:	611c                	ld	a5,0(a0)
    80004bf0:	c385                	beqz	a5,80004c10 <argfd+0x56>
    return -1;
  if (pfd)
    80004bf2:	00090463          	beqz	s2,80004bfa <argfd+0x40>
    *pfd = fd;
    80004bf6:	00e92023          	sw	a4,0(s2)
  if (pf)
    *pf = f;
  return 0;
    80004bfa:	4501                	li	a0,0
  if (pf)
    80004bfc:	c091                	beqz	s1,80004c00 <argfd+0x46>
    *pf = f;
    80004bfe:	e09c                	sd	a5,0(s1)
}
    80004c00:	70a2                	ld	ra,40(sp)
    80004c02:	7402                	ld	s0,32(sp)
    80004c04:	64e2                	ld	s1,24(sp)
    80004c06:	6942                	ld	s2,16(sp)
    80004c08:	6145                	addi	sp,sp,48
    80004c0a:	8082                	ret
    return -1;
    80004c0c:	557d                	li	a0,-1
    80004c0e:	bfcd                	j	80004c00 <argfd+0x46>
    80004c10:	557d                	li	a0,-1
    80004c12:	b7fd                	j	80004c00 <argfd+0x46>

0000000080004c14 <fdalloc>:

// Allocate a file descriptor for the given file.
// Takes over file reference from caller on success.
static int
fdalloc(struct file *f)
{
    80004c14:	1101                	addi	sp,sp,-32
    80004c16:	ec06                	sd	ra,24(sp)
    80004c18:	e822                	sd	s0,16(sp)
    80004c1a:	e426                	sd	s1,8(sp)
    80004c1c:	1000                	addi	s0,sp,32
    80004c1e:	84aa                	mv	s1,a0
  int fd;
  struct proc *p = myproc();
    80004c20:	ce9fc0ef          	jal	80001908 <myproc>
    80004c24:	862a                	mv	a2,a0

  for (fd = 0; fd < NOFILE; fd++) {
    80004c26:	0d050793          	addi	a5,a0,208
    80004c2a:	4501                	li	a0,0
    80004c2c:	46c1                	li	a3,16
    if (p->ofile[fd] == 0) {
    80004c2e:	6398                	ld	a4,0(a5)
    80004c30:	cb19                	beqz	a4,80004c46 <fdalloc+0x32>
  for (fd = 0; fd < NOFILE; fd++) {
    80004c32:	2505                	addiw	a0,a0,1
    80004c34:	07a1                	addi	a5,a5,8
    80004c36:	fed51ce3          	bne	a0,a3,80004c2e <fdalloc+0x1a>
      p->ofile[fd] = f;
      return fd;
    }
  }
  return -1;
    80004c3a:	557d                	li	a0,-1
}
    80004c3c:	60e2                	ld	ra,24(sp)
    80004c3e:	6442                	ld	s0,16(sp)
    80004c40:	64a2                	ld	s1,8(sp)
    80004c42:	6105                	addi	sp,sp,32
    80004c44:	8082                	ret
      p->ofile[fd] = f;
    80004c46:	00351793          	slli	a5,a0,0x3
    80004c4a:	0d078793          	addi	a5,a5,208
    80004c4e:	963e                	add	a2,a2,a5
    80004c50:	e204                	sd	s1,0(a2)
      return fd;
    80004c52:	b7ed                	j	80004c3c <fdalloc+0x28>

0000000080004c54 <create>:
  return -1;
}

static struct inode *
create(char *path, short type, short major, short minor)
{
    80004c54:	715d                	addi	sp,sp,-80
    80004c56:	e486                	sd	ra,72(sp)
    80004c58:	e0a2                	sd	s0,64(sp)
    80004c5a:	fc26                	sd	s1,56(sp)
    80004c5c:	f84a                	sd	s2,48(sp)
    80004c5e:	f052                	sd	s4,32(sp)
    80004c60:	ec56                	sd	s5,24(sp)
    80004c62:	e85a                	sd	s6,16(sp)
    80004c64:	0880                	addi	s0,sp,80
    80004c66:	8a2e                	mv	s4,a1
    80004c68:	8ab2                	mv	s5,a2
    80004c6a:	8b36                	mv	s6,a3
  struct inode *ip, *dp;
  char name[DIRSIZ];

  if ((dp = nameiparent(path, name)) == 0)
    80004c6c:	fb040593          	addi	a1,s0,-80
    80004c70:	ed9fe0ef          	jal	80003b48 <nameiparent>
    80004c74:	84aa                	mv	s1,a0
    80004c76:	12050f63          	beqz	a0,80004db4 <create+0x160>
    return 0;

  ilock(dp);
    80004c7a:	e1afe0ef          	jal	80003294 <ilock>

  if (dp->nlink == 0) {
    80004c7e:	04a49783          	lh	a5,74(s1)
    80004c82:	cbb9                	beqz	a5,80004cd8 <create+0x84>
    iunlockput(dp);
    return 0;
  }

  // a new directory's ".." would push dp->nlink past its maximum
  if (type == T_DIR && dp->nlink >= NLINK_MAX) {
    80004c84:	7761                	lui	a4,0xffff8
    80004c86:	0705                	addi	a4,a4,1 # ffffffffffff8001 <end+0xffffffff7ffd49b1>
    80004c88:	97ba                	add	a5,a5,a4
    80004c8a:	e781                	bnez	a5,80004c92 <create+0x3e>
    80004c8c:	fffa0793          	addi	a5,s4,-1
    80004c90:	cba9                	beqz	a5,80004ce2 <create+0x8e>
    iunlockput(dp);
    return 0;
  }

  if ((ip = dirlookup(dp, name, 0)) != 0) {
    80004c92:	4601                	li	a2,0
    80004c94:	fb040593          	addi	a1,s0,-80
    80004c98:	8526                	mv	a0,s1
    80004c9a:	be3fe0ef          	jal	8000387c <dirlookup>
    80004c9e:	892a                	mv	s2,a0
    80004ca0:	c939                	beqz	a0,80004cf6 <create+0xa2>
    iunlockput(dp);
    80004ca2:	8526                	mv	a0,s1
    80004ca4:	845fe0ef          	jal	800034e8 <iunlockput>
    ilock(ip);
    80004ca8:	854a                	mv	a0,s2
    80004caa:	deafe0ef          	jal	80003294 <ilock>
    if (type == T_FILE && (ip->type == T_FILE || ip->type == T_DEVICE))
    80004cae:	4789                	li	a5,2
    80004cb0:	02fa1e63          	bne	s4,a5,80004cec <create+0x98>
    80004cb4:	04495783          	lhu	a5,68(s2)
    80004cb8:	37f9                	addiw	a5,a5,-2
    80004cba:	17c2                	slli	a5,a5,0x30
    80004cbc:	93c1                	srli	a5,a5,0x30
    80004cbe:	4705                	li	a4,1
    80004cc0:	02f76663          	bltu	a4,a5,80004cec <create+0x98>
  ip->nlink = 0;
  iupdate(ip);
  iunlockput(ip);
  iunlockput(dp);
  return 0;
}
    80004cc4:	854a                	mv	a0,s2
    80004cc6:	60a6                	ld	ra,72(sp)
    80004cc8:	6406                	ld	s0,64(sp)
    80004cca:	74e2                	ld	s1,56(sp)
    80004ccc:	7942                	ld	s2,48(sp)
    80004cce:	7a02                	ld	s4,32(sp)
    80004cd0:	6ae2                	ld	s5,24(sp)
    80004cd2:	6b42                	ld	s6,16(sp)
    80004cd4:	6161                	addi	sp,sp,80
    80004cd6:	8082                	ret
    iunlockput(dp);
    80004cd8:	8526                	mv	a0,s1
    80004cda:	80ffe0ef          	jal	800034e8 <iunlockput>
    return 0;
    80004cde:	4901                	li	s2,0
    80004ce0:	b7d5                	j	80004cc4 <create+0x70>
    iunlockput(dp);
    80004ce2:	8526                	mv	a0,s1
    80004ce4:	805fe0ef          	jal	800034e8 <iunlockput>
    return 0;
    80004ce8:	4901                	li	s2,0
    80004cea:	bfe9                	j	80004cc4 <create+0x70>
    iunlockput(ip);
    80004cec:	854a                	mv	a0,s2
    80004cee:	ffafe0ef          	jal	800034e8 <iunlockput>
    return 0;
    80004cf2:	4901                	li	s2,0
    80004cf4:	bfc1                	j	80004cc4 <create+0x70>
    80004cf6:	f44e                	sd	s3,40(sp)
  if ((ip = ialloc(dp->dev, type)) == 0) {
    80004cf8:	85d2                	mv	a1,s4
    80004cfa:	4088                	lw	a0,0(s1)
    80004cfc:	c28fe0ef          	jal	80003124 <ialloc>
    80004d00:	89aa                	mv	s3,a0
    80004d02:	cd1d                	beqz	a0,80004d40 <create+0xec>
  ilock(ip);
    80004d04:	d90fe0ef          	jal	80003294 <ilock>
  ip->major = major;
    80004d08:	05599323          	sh	s5,70(s3)
  ip->minor = minor;
    80004d0c:	05699423          	sh	s6,72(s3)
  ip->nlink = 1;
    80004d10:	4705                	li	a4,1
    80004d12:	04e99523          	sh	a4,74(s3)
  iupdate(ip);
    80004d16:	854e                	mv	a0,s3
    80004d18:	cc8fe0ef          	jal	800031e0 <iupdate>
  if (type == T_DIR) { // Create . and .. entries.
    80004d1c:	4705                	li	a4,1
    80004d1e:	02ea0763          	beq	s4,a4,80004d4c <create+0xf8>
  if (dirlink(dp, name, ip->inum) < 0)
    80004d22:	0049a603          	lw	a2,4(s3)
    80004d26:	fb040593          	addi	a1,s0,-80
    80004d2a:	8526                	mv	a0,s1
    80004d2c:	d59fe0ef          	jal	80003a84 <dirlink>
    80004d30:	06054563          	bltz	a0,80004d9a <create+0x146>
  iunlockput(dp);
    80004d34:	8526                	mv	a0,s1
    80004d36:	fb2fe0ef          	jal	800034e8 <iunlockput>
  return ip;
    80004d3a:	894e                	mv	s2,s3
    80004d3c:	79a2                	ld	s3,40(sp)
    80004d3e:	b759                	j	80004cc4 <create+0x70>
    iunlockput(dp);
    80004d40:	8526                	mv	a0,s1
    80004d42:	fa6fe0ef          	jal	800034e8 <iunlockput>
    return 0;
    80004d46:	894e                	mv	s2,s3
    80004d48:	79a2                	ld	s3,40(sp)
    80004d4a:	bfad                	j	80004cc4 <create+0x70>
    if (dirlink(ip, ".", ip->inum) < 0 || dirlink(ip, "..", dp->inum) < 0)
    80004d4c:	0049a603          	lw	a2,4(s3)
    80004d50:	00003597          	auipc	a1,0x3
    80004d54:	8a858593          	addi	a1,a1,-1880 # 800075f8 <etext+0x5f8>
    80004d58:	854e                	mv	a0,s3
    80004d5a:	d2bfe0ef          	jal	80003a84 <dirlink>
    80004d5e:	02054e63          	bltz	a0,80004d9a <create+0x146>
    80004d62:	40d0                	lw	a2,4(s1)
    80004d64:	00003597          	auipc	a1,0x3
    80004d68:	89c58593          	addi	a1,a1,-1892 # 80007600 <etext+0x600>
    80004d6c:	854e                	mv	a0,s3
    80004d6e:	d17fe0ef          	jal	80003a84 <dirlink>
    80004d72:	02054463          	bltz	a0,80004d9a <create+0x146>
  if (dirlink(dp, name, ip->inum) < 0)
    80004d76:	0049a603          	lw	a2,4(s3)
    80004d7a:	fb040593          	addi	a1,s0,-80
    80004d7e:	8526                	mv	a0,s1
    80004d80:	d05fe0ef          	jal	80003a84 <dirlink>
    80004d84:	00054b63          	bltz	a0,80004d9a <create+0x146>
    dp->nlink++; // for ".."
    80004d88:	04a4d783          	lhu	a5,74(s1)
    80004d8c:	2785                	addiw	a5,a5,1
    80004d8e:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    80004d92:	8526                	mv	a0,s1
    80004d94:	c4cfe0ef          	jal	800031e0 <iupdate>
    80004d98:	bf71                	j	80004d34 <create+0xe0>
  ip->nlink = 0;
    80004d9a:	04099523          	sh	zero,74(s3)
  iupdate(ip);
    80004d9e:	854e                	mv	a0,s3
    80004da0:	c40fe0ef          	jal	800031e0 <iupdate>
  iunlockput(ip);
    80004da4:	854e                	mv	a0,s3
    80004da6:	f42fe0ef          	jal	800034e8 <iunlockput>
  iunlockput(dp);
    80004daa:	8526                	mv	a0,s1
    80004dac:	f3cfe0ef          	jal	800034e8 <iunlockput>
  return 0;
    80004db0:	79a2                	ld	s3,40(sp)
    80004db2:	bf09                	j	80004cc4 <create+0x70>
    return 0;
    80004db4:	892a                	mv	s2,a0
    80004db6:	b739                	j	80004cc4 <create+0x70>

0000000080004db8 <sys_dup>:
{
    80004db8:	7179                	addi	sp,sp,-48
    80004dba:	f406                	sd	ra,40(sp)
    80004dbc:	f022                	sd	s0,32(sp)
    80004dbe:	1800                	addi	s0,sp,48
  if (argfd(0, 0, &f) < 0)
    80004dc0:	fd840613          	addi	a2,s0,-40
    80004dc4:	4581                	li	a1,0
    80004dc6:	4501                	li	a0,0
    80004dc8:	df3ff0ef          	jal	80004bba <argfd>
    return -1;
    80004dcc:	57fd                	li	a5,-1
  if (argfd(0, 0, &f) < 0)
    80004dce:	02054363          	bltz	a0,80004df4 <sys_dup+0x3c>
    80004dd2:	ec26                	sd	s1,24(sp)
    80004dd4:	e84a                	sd	s2,16(sp)
  if ((fd = fdalloc(f)) < 0)
    80004dd6:	fd843483          	ld	s1,-40(s0)
    80004dda:	8526                	mv	a0,s1
    80004ddc:	e39ff0ef          	jal	80004c14 <fdalloc>
    80004de0:	892a                	mv	s2,a0
    return -1;
    80004de2:	57fd                	li	a5,-1
  if ((fd = fdalloc(f)) < 0)
    80004de4:	00054d63          	bltz	a0,80004dfe <sys_dup+0x46>
  filedup(f);
    80004de8:	8526                	mv	a0,s1
    80004dea:	b96ff0ef          	jal	80004180 <filedup>
  return fd;
    80004dee:	87ca                	mv	a5,s2
    80004df0:	64e2                	ld	s1,24(sp)
    80004df2:	6942                	ld	s2,16(sp)
}
    80004df4:	853e                	mv	a0,a5
    80004df6:	70a2                	ld	ra,40(sp)
    80004df8:	7402                	ld	s0,32(sp)
    80004dfa:	6145                	addi	sp,sp,48
    80004dfc:	8082                	ret
    80004dfe:	64e2                	ld	s1,24(sp)
    80004e00:	6942                	ld	s2,16(sp)
    80004e02:	bfcd                	j	80004df4 <sys_dup+0x3c>

0000000080004e04 <sys_read>:
{
    80004e04:	7179                	addi	sp,sp,-48
    80004e06:	f406                	sd	ra,40(sp)
    80004e08:	f022                	sd	s0,32(sp)
    80004e0a:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    80004e0c:	fd840593          	addi	a1,s0,-40
    80004e10:	4505                	li	a0,1
    80004e12:	a5bfd0ef          	jal	8000286c <argaddr>
  argint(2, &n);
    80004e16:	fe440593          	addi	a1,s0,-28
    80004e1a:	4509                	li	a0,2
    80004e1c:	a35fd0ef          	jal	80002850 <argint>
  if (argfd(0, 0, &f) < 0)
    80004e20:	fe840613          	addi	a2,s0,-24
    80004e24:	4581                	li	a1,0
    80004e26:	4501                	li	a0,0
    80004e28:	d93ff0ef          	jal	80004bba <argfd>
    80004e2c:	87aa                	mv	a5,a0
    return -1;
    80004e2e:	557d                	li	a0,-1
  if (argfd(0, 0, &f) < 0)
    80004e30:	0007ca63          	bltz	a5,80004e44 <sys_read+0x40>
  return fileread(f, p, n);
    80004e34:	fe442603          	lw	a2,-28(s0)
    80004e38:	fd843583          	ld	a1,-40(s0)
    80004e3c:	fe843503          	ld	a0,-24(s0)
    80004e40:	caeff0ef          	jal	800042ee <fileread>
}
    80004e44:	70a2                	ld	ra,40(sp)
    80004e46:	7402                	ld	s0,32(sp)
    80004e48:	6145                	addi	sp,sp,48
    80004e4a:	8082                	ret

0000000080004e4c <sys_write>:
{
    80004e4c:	7179                	addi	sp,sp,-48
    80004e4e:	f406                	sd	ra,40(sp)
    80004e50:	f022                	sd	s0,32(sp)
    80004e52:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    80004e54:	fd840593          	addi	a1,s0,-40
    80004e58:	4505                	li	a0,1
    80004e5a:	a13fd0ef          	jal	8000286c <argaddr>
  argint(2, &n);
    80004e5e:	fe440593          	addi	a1,s0,-28
    80004e62:	4509                	li	a0,2
    80004e64:	9edfd0ef          	jal	80002850 <argint>
  if (argfd(0, 0, &f) < 0)
    80004e68:	fe840613          	addi	a2,s0,-24
    80004e6c:	4581                	li	a1,0
    80004e6e:	4501                	li	a0,0
    80004e70:	d4bff0ef          	jal	80004bba <argfd>
    80004e74:	87aa                	mv	a5,a0
    return -1;
    80004e76:	557d                	li	a0,-1
  if (argfd(0, 0, &f) < 0)
    80004e78:	0007ca63          	bltz	a5,80004e8c <sys_write+0x40>
  return filewrite(f, p, n);
    80004e7c:	fe442603          	lw	a2,-28(s0)
    80004e80:	fd843583          	ld	a1,-40(s0)
    80004e84:	fe843503          	ld	a0,-24(s0)
    80004e88:	d34ff0ef          	jal	800043bc <filewrite>
}
    80004e8c:	70a2                	ld	ra,40(sp)
    80004e8e:	7402                	ld	s0,32(sp)
    80004e90:	6145                	addi	sp,sp,48
    80004e92:	8082                	ret

0000000080004e94 <sys_close>:
{
    80004e94:	1101                	addi	sp,sp,-32
    80004e96:	ec06                	sd	ra,24(sp)
    80004e98:	e822                	sd	s0,16(sp)
    80004e9a:	1000                	addi	s0,sp,32
  if (argfd(0, &fd, &f) < 0)
    80004e9c:	fe040613          	addi	a2,s0,-32
    80004ea0:	fec40593          	addi	a1,s0,-20
    80004ea4:	4501                	li	a0,0
    80004ea6:	d15ff0ef          	jal	80004bba <argfd>
    return -1;
    80004eaa:	57fd                	li	a5,-1
  if (argfd(0, &fd, &f) < 0)
    80004eac:	02054163          	bltz	a0,80004ece <sys_close+0x3a>
  myproc()->ofile[fd] = 0;
    80004eb0:	a59fc0ef          	jal	80001908 <myproc>
    80004eb4:	fec42783          	lw	a5,-20(s0)
    80004eb8:	078e                	slli	a5,a5,0x3
    80004eba:	0d078793          	addi	a5,a5,208
    80004ebe:	953e                	add	a0,a0,a5
    80004ec0:	00053023          	sd	zero,0(a0)
  fileclose(f);
    80004ec4:	fe043503          	ld	a0,-32(s0)
    80004ec8:	afeff0ef          	jal	800041c6 <fileclose>
  return 0;
    80004ecc:	4781                	li	a5,0
}
    80004ece:	853e                	mv	a0,a5
    80004ed0:	60e2                	ld	ra,24(sp)
    80004ed2:	6442                	ld	s0,16(sp)
    80004ed4:	6105                	addi	sp,sp,32
    80004ed6:	8082                	ret

0000000080004ed8 <sys_fstat>:
{
    80004ed8:	1101                	addi	sp,sp,-32
    80004eda:	ec06                	sd	ra,24(sp)
    80004edc:	e822                	sd	s0,16(sp)
    80004ede:	1000                	addi	s0,sp,32
  argaddr(1, &st);
    80004ee0:	fe040593          	addi	a1,s0,-32
    80004ee4:	4505                	li	a0,1
    80004ee6:	987fd0ef          	jal	8000286c <argaddr>
  if (argfd(0, 0, &f) < 0)
    80004eea:	fe840613          	addi	a2,s0,-24
    80004eee:	4581                	li	a1,0
    80004ef0:	4501                	li	a0,0
    80004ef2:	cc9ff0ef          	jal	80004bba <argfd>
    80004ef6:	87aa                	mv	a5,a0
    return -1;
    80004ef8:	557d                	li	a0,-1
  if (argfd(0, 0, &f) < 0)
    80004efa:	0007c863          	bltz	a5,80004f0a <sys_fstat+0x32>
  return filestat(f, st);
    80004efe:	fe043583          	ld	a1,-32(s0)
    80004f02:	fe843503          	ld	a0,-24(s0)
    80004f06:	b82ff0ef          	jal	80004288 <filestat>
}
    80004f0a:	60e2                	ld	ra,24(sp)
    80004f0c:	6442                	ld	s0,16(sp)
    80004f0e:	6105                	addi	sp,sp,32
    80004f10:	8082                	ret

0000000080004f12 <sys_link>:
{
    80004f12:	7169                	addi	sp,sp,-304
    80004f14:	f606                	sd	ra,296(sp)
    80004f16:	f222                	sd	s0,288(sp)
    80004f18:	1a00                	addi	s0,sp,304
  if (argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80004f1a:	08000613          	li	a2,128
    80004f1e:	ed040593          	addi	a1,s0,-304
    80004f22:	4501                	li	a0,0
    80004f24:	965fd0ef          	jal	80002888 <argstr>
    return -1;
    80004f28:	57fd                	li	a5,-1
  if (argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80004f2a:	10054163          	bltz	a0,8000502c <sys_link+0x11a>
    80004f2e:	08000613          	li	a2,128
    80004f32:	f5040593          	addi	a1,s0,-176
    80004f36:	4505                	li	a0,1
    80004f38:	951fd0ef          	jal	80002888 <argstr>
    return -1;
    80004f3c:	57fd                	li	a5,-1
  if (argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80004f3e:	0e054763          	bltz	a0,8000502c <sys_link+0x11a>
    80004f42:	ee26                	sd	s1,280(sp)
  begin_op();
    80004f44:	dc9fe0ef          	jal	80003d0c <begin_op>
  if ((ip = namei(old)) == 0) {
    80004f48:	ed040513          	addi	a0,s0,-304
    80004f4c:	be3fe0ef          	jal	80003b2e <namei>
    80004f50:	84aa                	mv	s1,a0
    80004f52:	cd35                	beqz	a0,80004fce <sys_link+0xbc>
  ilock(ip);
    80004f54:	b40fe0ef          	jal	80003294 <ilock>
  if (ip->type == T_DIR) {
    80004f58:	04449703          	lh	a4,68(s1)
    80004f5c:	4785                	li	a5,1
    80004f5e:	06f70d63          	beq	a4,a5,80004fd8 <sys_link+0xc6>
  if (ip->nlink >= NLINK_MAX) {
    80004f62:	04a49783          	lh	a5,74(s1)
    80004f66:	6721                	lui	a4,0x8
    80004f68:	177d                	addi	a4,a4,-1 # 7fff <_entry-0x7fff8001>
    80004f6a:	06e78f63          	beq	a5,a4,80004fe8 <sys_link+0xd6>
    80004f6e:	ea4a                	sd	s2,272(sp)
  ip->nlink++;
    80004f70:	2785                	addiw	a5,a5,1
    80004f72:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    80004f76:	8526                	mv	a0,s1
    80004f78:	a68fe0ef          	jal	800031e0 <iupdate>
  iunlock(ip);
    80004f7c:	8526                	mv	a0,s1
    80004f7e:	bc4fe0ef          	jal	80003342 <iunlock>
  if ((dp = nameiparent(new, name)) == 0)
    80004f82:	fd040593          	addi	a1,s0,-48
    80004f86:	f5040513          	addi	a0,s0,-176
    80004f8a:	bbffe0ef          	jal	80003b48 <nameiparent>
    80004f8e:	892a                	mv	s2,a0
    80004f90:	c93d                	beqz	a0,80005006 <sys_link+0xf4>
  ilock(dp);
    80004f92:	b02fe0ef          	jal	80003294 <ilock>
  if (dp->nlink == 0) {
    80004f96:	04a91783          	lh	a5,74(s2)
    80004f9a:	cfb9                	beqz	a5,80004ff8 <sys_link+0xe6>
  if (dp->dev != ip->dev || dirlink(dp, name, ip->inum) < 0) {
    80004f9c:	854a                	mv	a0,s2
    80004f9e:	00092703          	lw	a4,0(s2)
    80004fa2:	409c                	lw	a5,0(s1)
    80004fa4:	04f71e63          	bne	a4,a5,80005000 <sys_link+0xee>
    80004fa8:	40d0                	lw	a2,4(s1)
    80004faa:	fd040593          	addi	a1,s0,-48
    80004fae:	ad7fe0ef          	jal	80003a84 <dirlink>
    80004fb2:	04054763          	bltz	a0,80005000 <sys_link+0xee>
  iunlockput(dp);
    80004fb6:	854a                	mv	a0,s2
    80004fb8:	d30fe0ef          	jal	800034e8 <iunlockput>
  iput(ip);
    80004fbc:	8526                	mv	a0,s1
    80004fbe:	c58fe0ef          	jal	80003416 <iput>
  end_op();
    80004fc2:	dd7fe0ef          	jal	80003d98 <end_op>
  return 0;
    80004fc6:	4781                	li	a5,0
    80004fc8:	64f2                	ld	s1,280(sp)
    80004fca:	6952                	ld	s2,272(sp)
    80004fcc:	a085                	j	8000502c <sys_link+0x11a>
    end_op();
    80004fce:	dcbfe0ef          	jal	80003d98 <end_op>
    return -1;
    80004fd2:	57fd                	li	a5,-1
    80004fd4:	64f2                	ld	s1,280(sp)
    80004fd6:	a899                	j	8000502c <sys_link+0x11a>
    iunlockput(ip);
    80004fd8:	8526                	mv	a0,s1
    80004fda:	d0efe0ef          	jal	800034e8 <iunlockput>
    end_op();
    80004fde:	dbbfe0ef          	jal	80003d98 <end_op>
    return -1;
    80004fe2:	57fd                	li	a5,-1
    80004fe4:	64f2                	ld	s1,280(sp)
    80004fe6:	a099                	j	8000502c <sys_link+0x11a>
    iunlockput(ip);
    80004fe8:	8526                	mv	a0,s1
    80004fea:	cfefe0ef          	jal	800034e8 <iunlockput>
    end_op();
    80004fee:	dabfe0ef          	jal	80003d98 <end_op>
    return -1;
    80004ff2:	57fd                	li	a5,-1
    80004ff4:	64f2                	ld	s1,280(sp)
    80004ff6:	a81d                	j	8000502c <sys_link+0x11a>
    iunlockput(dp);
    80004ff8:	854a                	mv	a0,s2
    80004ffa:	ceefe0ef          	jal	800034e8 <iunlockput>
    goto bad;
    80004ffe:	a021                	j	80005006 <sys_link+0xf4>
    iunlockput(dp);
    80005000:	854a                	mv	a0,s2
    80005002:	ce6fe0ef          	jal	800034e8 <iunlockput>
  ilock(ip);
    80005006:	8526                	mv	a0,s1
    80005008:	a8cfe0ef          	jal	80003294 <ilock>
  ip->nlink--;
    8000500c:	04a4d783          	lhu	a5,74(s1)
    80005010:	37fd                	addiw	a5,a5,-1
    80005012:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    80005016:	8526                	mv	a0,s1
    80005018:	9c8fe0ef          	jal	800031e0 <iupdate>
  iunlockput(ip);
    8000501c:	8526                	mv	a0,s1
    8000501e:	ccafe0ef          	jal	800034e8 <iunlockput>
  end_op();
    80005022:	d77fe0ef          	jal	80003d98 <end_op>
  return -1;
    80005026:	57fd                	li	a5,-1
    80005028:	64f2                	ld	s1,280(sp)
    8000502a:	6952                	ld	s2,272(sp)
}
    8000502c:	853e                	mv	a0,a5
    8000502e:	70b2                	ld	ra,296(sp)
    80005030:	7412                	ld	s0,288(sp)
    80005032:	6155                	addi	sp,sp,304
    80005034:	8082                	ret

0000000080005036 <sys_unlink>:
{
    80005036:	7151                	addi	sp,sp,-240
    80005038:	f586                	sd	ra,232(sp)
    8000503a:	f1a2                	sd	s0,224(sp)
    8000503c:	1980                	addi	s0,sp,240
  if (argstr(0, path, MAXPATH) < 0)
    8000503e:	08000613          	li	a2,128
    80005042:	f3040593          	addi	a1,s0,-208
    80005046:	4501                	li	a0,0
    80005048:	841fd0ef          	jal	80002888 <argstr>
    8000504c:	14054d63          	bltz	a0,800051a6 <sys_unlink+0x170>
    80005050:	eda6                	sd	s1,216(sp)
  begin_op();
    80005052:	cbbfe0ef          	jal	80003d0c <begin_op>
  if ((dp = nameiparent(path, name)) == 0) {
    80005056:	fb040593          	addi	a1,s0,-80
    8000505a:	f3040513          	addi	a0,s0,-208
    8000505e:	aebfe0ef          	jal	80003b48 <nameiparent>
    80005062:	84aa                	mv	s1,a0
    80005064:	c955                	beqz	a0,80005118 <sys_unlink+0xe2>
  ilock(dp);
    80005066:	a2efe0ef          	jal	80003294 <ilock>
  if (namecmp(name, ".") == 0 || namecmp(name, "..") == 0)
    8000506a:	00002597          	auipc	a1,0x2
    8000506e:	58e58593          	addi	a1,a1,1422 # 800075f8 <etext+0x5f8>
    80005072:	fb040513          	addi	a0,s0,-80
    80005076:	ff0fe0ef          	jal	80003866 <namecmp>
    8000507a:	10050b63          	beqz	a0,80005190 <sys_unlink+0x15a>
    8000507e:	00002597          	auipc	a1,0x2
    80005082:	58258593          	addi	a1,a1,1410 # 80007600 <etext+0x600>
    80005086:	fb040513          	addi	a0,s0,-80
    8000508a:	fdcfe0ef          	jal	80003866 <namecmp>
    8000508e:	10050163          	beqz	a0,80005190 <sys_unlink+0x15a>
    80005092:	e9ca                	sd	s2,208(sp)
  if ((ip = dirlookup(dp, name, &off)) == 0)
    80005094:	f2c40613          	addi	a2,s0,-212
    80005098:	fb040593          	addi	a1,s0,-80
    8000509c:	8526                	mv	a0,s1
    8000509e:	fdefe0ef          	jal	8000387c <dirlookup>
    800050a2:	892a                	mv	s2,a0
    800050a4:	0e050563          	beqz	a0,8000518e <sys_unlink+0x158>
    800050a8:	e5ce                	sd	s3,200(sp)
  ilock(ip);
    800050aa:	9eafe0ef          	jal	80003294 <ilock>
  if (ip->nlink < 1)
    800050ae:	04a91783          	lh	a5,74(s2)
    800050b2:	06f05863          	blez	a5,80005122 <sys_unlink+0xec>
  if (ip->type == T_DIR && !isdirempty(ip)) {
    800050b6:	04491703          	lh	a4,68(s2)
    800050ba:	4785                	li	a5,1
    800050bc:	06f70963          	beq	a4,a5,8000512e <sys_unlink+0xf8>
  memset(&de, 0, sizeof(de));
    800050c0:	fc040993          	addi	s3,s0,-64
    800050c4:	4641                	li	a2,16
    800050c6:	4581                	li	a1,0
    800050c8:	854e                	mv	a0,s3
    800050ca:	bdffb0ef          	jal	80000ca8 <memset>
  if (writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    800050ce:	4741                	li	a4,16
    800050d0:	f2c42683          	lw	a3,-212(s0)
    800050d4:	864e                	mv	a2,s3
    800050d6:	4581                	li	a1,0
    800050d8:	8526                	mv	a0,s1
    800050da:	e86fe0ef          	jal	80003760 <writei>
    800050de:	47c1                	li	a5,16
    800050e0:	08f51863          	bne	a0,a5,80005170 <sys_unlink+0x13a>
  if (ip->type == T_DIR) {
    800050e4:	04491703          	lh	a4,68(s2)
    800050e8:	4785                	li	a5,1
    800050ea:	08f70963          	beq	a4,a5,8000517c <sys_unlink+0x146>
  iunlockput(dp);
    800050ee:	8526                	mv	a0,s1
    800050f0:	bf8fe0ef          	jal	800034e8 <iunlockput>
  ip->nlink--;
    800050f4:	04a95783          	lhu	a5,74(s2)
    800050f8:	37fd                	addiw	a5,a5,-1
    800050fa:	04f91523          	sh	a5,74(s2)
  iupdate(ip);
    800050fe:	854a                	mv	a0,s2
    80005100:	8e0fe0ef          	jal	800031e0 <iupdate>
  iunlockput(ip);
    80005104:	854a                	mv	a0,s2
    80005106:	be2fe0ef          	jal	800034e8 <iunlockput>
  end_op();
    8000510a:	c8ffe0ef          	jal	80003d98 <end_op>
  return 0;
    8000510e:	4501                	li	a0,0
    80005110:	64ee                	ld	s1,216(sp)
    80005112:	694e                	ld	s2,208(sp)
    80005114:	69ae                	ld	s3,200(sp)
    80005116:	a061                	j	8000519e <sys_unlink+0x168>
    end_op();
    80005118:	c81fe0ef          	jal	80003d98 <end_op>
    return -1;
    8000511c:	557d                	li	a0,-1
    8000511e:	64ee                	ld	s1,216(sp)
    80005120:	a8bd                	j	8000519e <sys_unlink+0x168>
    panic("unlink: nlink < 1");
    80005122:	00002517          	auipc	a0,0x2
    80005126:	4e650513          	addi	a0,a0,1254 # 80007608 <etext+0x608>
    8000512a:	f0afb0ef          	jal	80000834 <panic>
  for (off = 2 * sizeof(de); off < dp->size; off += sizeof(de)) {
    8000512e:	04c92703          	lw	a4,76(s2)
    80005132:	02000793          	li	a5,32
    80005136:	f8e7f5e3          	bgeu	a5,a4,800050c0 <sys_unlink+0x8a>
    8000513a:	89be                	mv	s3,a5
    if (readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    8000513c:	4741                	li	a4,16
    8000513e:	86ce                	mv	a3,s3
    80005140:	f1840613          	addi	a2,s0,-232
    80005144:	4581                	li	a1,0
    80005146:	854a                	mv	a0,s2
    80005148:	d26fe0ef          	jal	8000366e <readi>
    8000514c:	47c1                	li	a5,16
    8000514e:	00f51b63          	bne	a0,a5,80005164 <sys_unlink+0x12e>
    if (de.inum != 0)
    80005152:	f1845783          	lhu	a5,-232(s0)
    80005156:	ebb1                	bnez	a5,800051aa <sys_unlink+0x174>
  for (off = 2 * sizeof(de); off < dp->size; off += sizeof(de)) {
    80005158:	29c1                	addiw	s3,s3,16
    8000515a:	04c92783          	lw	a5,76(s2)
    8000515e:	fcf9efe3          	bltu	s3,a5,8000513c <sys_unlink+0x106>
    80005162:	bfb9                	j	800050c0 <sys_unlink+0x8a>
      panic("isdirempty: readi");
    80005164:	00002517          	auipc	a0,0x2
    80005168:	4bc50513          	addi	a0,a0,1212 # 80007620 <etext+0x620>
    8000516c:	ec8fb0ef          	jal	80000834 <panic>
    panic("unlink: writei");
    80005170:	00002517          	auipc	a0,0x2
    80005174:	4c850513          	addi	a0,a0,1224 # 80007638 <etext+0x638>
    80005178:	ebcfb0ef          	jal	80000834 <panic>
    dp->nlink--;
    8000517c:	04a4d783          	lhu	a5,74(s1)
    80005180:	37fd                	addiw	a5,a5,-1
    80005182:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    80005186:	8526                	mv	a0,s1
    80005188:	858fe0ef          	jal	800031e0 <iupdate>
    8000518c:	b78d                	j	800050ee <sys_unlink+0xb8>
    8000518e:	694e                	ld	s2,208(sp)
  iunlockput(dp);
    80005190:	8526                	mv	a0,s1
    80005192:	b56fe0ef          	jal	800034e8 <iunlockput>
  end_op();
    80005196:	c03fe0ef          	jal	80003d98 <end_op>
  return -1;
    8000519a:	557d                	li	a0,-1
    8000519c:	64ee                	ld	s1,216(sp)
}
    8000519e:	70ae                	ld	ra,232(sp)
    800051a0:	740e                	ld	s0,224(sp)
    800051a2:	616d                	addi	sp,sp,240
    800051a4:	8082                	ret
    return -1;
    800051a6:	557d                	li	a0,-1
    800051a8:	bfdd                	j	8000519e <sys_unlink+0x168>
    iunlockput(ip);
    800051aa:	854a                	mv	a0,s2
    800051ac:	b3cfe0ef          	jal	800034e8 <iunlockput>
    goto bad;
    800051b0:	694e                	ld	s2,208(sp)
    800051b2:	69ae                	ld	s3,200(sp)
    800051b4:	bff1                	j	80005190 <sys_unlink+0x15a>

00000000800051b6 <sys_open>:

uint64
sys_open(void)
{
    800051b6:	7131                	addi	sp,sp,-192
    800051b8:	fd06                	sd	ra,184(sp)
    800051ba:	f922                	sd	s0,176(sp)
    800051bc:	0180                	addi	s0,sp,192
  int fd, omode;
  struct file *f;
  struct inode *ip;
  int n;

  argint(1, &omode);
    800051be:	f4c40593          	addi	a1,s0,-180
    800051c2:	4505                	li	a0,1
    800051c4:	e8cfd0ef          	jal	80002850 <argint>
  if ((n = argstr(0, path, MAXPATH)) < 0)
    800051c8:	08000613          	li	a2,128
    800051cc:	f5040593          	addi	a1,s0,-176
    800051d0:	4501                	li	a0,0
    800051d2:	eb6fd0ef          	jal	80002888 <argstr>
    800051d6:	87aa                	mv	a5,a0
    return -1;
    800051d8:	557d                	li	a0,-1
  if ((n = argstr(0, path, MAXPATH)) < 0)
    800051da:	0a07c363          	bltz	a5,80005280 <sys_open+0xca>
    800051de:	f526                	sd	s1,168(sp)

  begin_op();
    800051e0:	b2dfe0ef          	jal	80003d0c <begin_op>

  if (omode & O_CREATE) {
    800051e4:	f4c42783          	lw	a5,-180(s0)
    800051e8:	2007f793          	andi	a5,a5,512
    800051ec:	c3dd                	beqz	a5,80005292 <sys_open+0xdc>
    ip = create(path, T_FILE, 0, 0);
    800051ee:	4681                	li	a3,0
    800051f0:	4601                	li	a2,0
    800051f2:	4589                	li	a1,2
    800051f4:	f5040513          	addi	a0,s0,-176
    800051f8:	a5dff0ef          	jal	80004c54 <create>
    800051fc:	84aa                	mv	s1,a0
    if (ip == 0) {
    800051fe:	c549                	beqz	a0,80005288 <sys_open+0xd2>
      end_op();
      return -1;
    }
  }

  if (ip->type == T_DEVICE && (ip->major < 0 || ip->major >= NDEV)) {
    80005200:	04449703          	lh	a4,68(s1)
    80005204:	478d                	li	a5,3
    80005206:	00f71763          	bne	a4,a5,80005214 <sys_open+0x5e>
    8000520a:	0464d703          	lhu	a4,70(s1)
    8000520e:	47a5                	li	a5,9
    80005210:	0ae7ee63          	bltu	a5,a4,800052cc <sys_open+0x116>
    80005214:	f14a                	sd	s2,160(sp)
    iunlockput(ip);
    end_op();
    return -1;
  }

  if ((f = filealloc()) == 0 || (fd = fdalloc(f)) < 0) {
    80005216:	f0dfe0ef          	jal	80004122 <filealloc>
    8000521a:	892a                	mv	s2,a0
    8000521c:	c561                	beqz	a0,800052e4 <sys_open+0x12e>
    8000521e:	ed4e                	sd	s3,152(sp)
    80005220:	9f5ff0ef          	jal	80004c14 <fdalloc>
    80005224:	89aa                	mv	s3,a0
    80005226:	0a054b63          	bltz	a0,800052dc <sys_open+0x126>
    iunlockput(ip);
    end_op();
    return -1;
  }

  if (ip->type == T_DEVICE) {
    8000522a:	04449703          	lh	a4,68(s1)
    8000522e:	478d                	li	a5,3
    80005230:	0cf70363          	beq	a4,a5,800052f6 <sys_open+0x140>
    f->type = FD_DEVICE;
    f->major = ip->major;
  } else {
    f->type = FD_INODE;
    80005234:	4789                	li	a5,2
    80005236:	00f92023          	sw	a5,0(s2)
    f->off = 0;
    8000523a:	02092023          	sw	zero,32(s2)
  }
  f->ip = ip;
    8000523e:	00993c23          	sd	s1,24(s2)
  f->readable = !(omode & O_WRONLY);
    80005242:	f4c42783          	lw	a5,-180(s0)
    80005246:	0017f713          	andi	a4,a5,1
    8000524a:	00174713          	xori	a4,a4,1
    8000524e:	00e90423          	sb	a4,8(s2)
  f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
    80005252:	0037f713          	andi	a4,a5,3
    80005256:	00e03733          	snez	a4,a4
    8000525a:	00e904a3          	sb	a4,9(s2)

  if ((omode & O_TRUNC) && ip->type == T_FILE) {
    8000525e:	4007f793          	andi	a5,a5,1024
    80005262:	c791                	beqz	a5,8000526e <sys_open+0xb8>
    80005264:	04449703          	lh	a4,68(s1)
    80005268:	4789                	li	a5,2
    8000526a:	08f70d63          	beq	a4,a5,80005304 <sys_open+0x14e>
    itrunc(ip);
  }

  iunlock(ip);
    8000526e:	8526                	mv	a0,s1
    80005270:	8d2fe0ef          	jal	80003342 <iunlock>
  end_op();
    80005274:	b25fe0ef          	jal	80003d98 <end_op>

  return fd;
    80005278:	854e                	mv	a0,s3
    8000527a:	74aa                	ld	s1,168(sp)
    8000527c:	790a                	ld	s2,160(sp)
    8000527e:	69ea                	ld	s3,152(sp)
}
    80005280:	70ea                	ld	ra,184(sp)
    80005282:	744a                	ld	s0,176(sp)
    80005284:	6129                	addi	sp,sp,192
    80005286:	8082                	ret
      end_op();
    80005288:	b11fe0ef          	jal	80003d98 <end_op>
      return -1;
    8000528c:	557d                	li	a0,-1
    8000528e:	74aa                	ld	s1,168(sp)
    80005290:	bfc5                	j	80005280 <sys_open+0xca>
    if ((ip = namei(path)) == 0) {
    80005292:	f5040513          	addi	a0,s0,-176
    80005296:	899fe0ef          	jal	80003b2e <namei>
    8000529a:	84aa                	mv	s1,a0
    8000529c:	c11d                	beqz	a0,800052c2 <sys_open+0x10c>
    ilock(ip);
    8000529e:	ff7fd0ef          	jal	80003294 <ilock>
    if (ip->type == T_DIR && omode != O_RDONLY) {
    800052a2:	04449703          	lh	a4,68(s1)
    800052a6:	4785                	li	a5,1
    800052a8:	f4f71ce3          	bne	a4,a5,80005200 <sys_open+0x4a>
    800052ac:	f4c42783          	lw	a5,-180(s0)
    800052b0:	d3b5                	beqz	a5,80005214 <sys_open+0x5e>
      iunlockput(ip);
    800052b2:	8526                	mv	a0,s1
    800052b4:	a34fe0ef          	jal	800034e8 <iunlockput>
      end_op();
    800052b8:	ae1fe0ef          	jal	80003d98 <end_op>
      return -1;
    800052bc:	557d                	li	a0,-1
    800052be:	74aa                	ld	s1,168(sp)
    800052c0:	b7c1                	j	80005280 <sys_open+0xca>
      end_op();
    800052c2:	ad7fe0ef          	jal	80003d98 <end_op>
      return -1;
    800052c6:	557d                	li	a0,-1
    800052c8:	74aa                	ld	s1,168(sp)
    800052ca:	bf5d                	j	80005280 <sys_open+0xca>
    iunlockput(ip);
    800052cc:	8526                	mv	a0,s1
    800052ce:	a1afe0ef          	jal	800034e8 <iunlockput>
    end_op();
    800052d2:	ac7fe0ef          	jal	80003d98 <end_op>
    return -1;
    800052d6:	557d                	li	a0,-1
    800052d8:	74aa                	ld	s1,168(sp)
    800052da:	b75d                	j	80005280 <sys_open+0xca>
      fileclose(f);
    800052dc:	854a                	mv	a0,s2
    800052de:	ee9fe0ef          	jal	800041c6 <fileclose>
    800052e2:	69ea                	ld	s3,152(sp)
    iunlockput(ip);
    800052e4:	8526                	mv	a0,s1
    800052e6:	a02fe0ef          	jal	800034e8 <iunlockput>
    end_op();
    800052ea:	aaffe0ef          	jal	80003d98 <end_op>
    return -1;
    800052ee:	557d                	li	a0,-1
    800052f0:	74aa                	ld	s1,168(sp)
    800052f2:	790a                	ld	s2,160(sp)
    800052f4:	b771                	j	80005280 <sys_open+0xca>
    f->type = FD_DEVICE;
    800052f6:	00e92023          	sw	a4,0(s2)
    f->major = ip->major;
    800052fa:	04649783          	lh	a5,70(s1)
    800052fe:	02f91223          	sh	a5,36(s2)
    80005302:	bf35                	j	8000523e <sys_open+0x88>
    itrunc(ip);
    80005304:	8526                	mv	a0,s1
    80005306:	87cfe0ef          	jal	80003382 <itrunc>
    8000530a:	b795                	j	8000526e <sys_open+0xb8>

000000008000530c <sys_mkdir>:

uint64
sys_mkdir(void)
{
    8000530c:	7175                	addi	sp,sp,-144
    8000530e:	e506                	sd	ra,136(sp)
    80005310:	e122                	sd	s0,128(sp)
    80005312:	0900                	addi	s0,sp,144
  char path[MAXPATH];
  struct inode *ip;

  begin_op();
    80005314:	9f9fe0ef          	jal	80003d0c <begin_op>
  if (argstr(0, path, MAXPATH) < 0 || (ip = create(path, T_DIR, 0, 0)) == 0) {
    80005318:	08000613          	li	a2,128
    8000531c:	f7040593          	addi	a1,s0,-144
    80005320:	4501                	li	a0,0
    80005322:	d66fd0ef          	jal	80002888 <argstr>
    80005326:	02054363          	bltz	a0,8000534c <sys_mkdir+0x40>
    8000532a:	4681                	li	a3,0
    8000532c:	4601                	li	a2,0
    8000532e:	4585                	li	a1,1
    80005330:	f7040513          	addi	a0,s0,-144
    80005334:	921ff0ef          	jal	80004c54 <create>
    80005338:	c911                	beqz	a0,8000534c <sys_mkdir+0x40>
    end_op();
    return -1;
  }
  iunlockput(ip);
    8000533a:	9aefe0ef          	jal	800034e8 <iunlockput>
  end_op();
    8000533e:	a5bfe0ef          	jal	80003d98 <end_op>
  return 0;
    80005342:	4501                	li	a0,0
}
    80005344:	60aa                	ld	ra,136(sp)
    80005346:	640a                	ld	s0,128(sp)
    80005348:	6149                	addi	sp,sp,144
    8000534a:	8082                	ret
    end_op();
    8000534c:	a4dfe0ef          	jal	80003d98 <end_op>
    return -1;
    80005350:	557d                	li	a0,-1
    80005352:	bfcd                	j	80005344 <sys_mkdir+0x38>

0000000080005354 <sys_mknod>:

uint64
sys_mknod(void)
{
    80005354:	7135                	addi	sp,sp,-160
    80005356:	ed06                	sd	ra,152(sp)
    80005358:	e922                	sd	s0,144(sp)
    8000535a:	1100                	addi	s0,sp,160
  struct inode *ip;
  char path[MAXPATH];
  int major, minor;

  begin_op();
    8000535c:	9b1fe0ef          	jal	80003d0c <begin_op>
  argint(1, &major);
    80005360:	f6c40593          	addi	a1,s0,-148
    80005364:	4505                	li	a0,1
    80005366:	ceafd0ef          	jal	80002850 <argint>
  argint(2, &minor);
    8000536a:	f6840593          	addi	a1,s0,-152
    8000536e:	4509                	li	a0,2
    80005370:	ce0fd0ef          	jal	80002850 <argint>
  if ((argstr(0, path, MAXPATH)) < 0 ||
    80005374:	08000613          	li	a2,128
    80005378:	f7040593          	addi	a1,s0,-144
    8000537c:	4501                	li	a0,0
    8000537e:	d0afd0ef          	jal	80002888 <argstr>
    80005382:	02054563          	bltz	a0,800053ac <sys_mknod+0x58>
      (ip = create(path, T_DEVICE, major, minor)) == 0) {
    80005386:	f6841683          	lh	a3,-152(s0)
    8000538a:	f6c41603          	lh	a2,-148(s0)
    8000538e:	458d                	li	a1,3
    80005390:	f7040513          	addi	a0,s0,-144
    80005394:	8c1ff0ef          	jal	80004c54 <create>
  if ((argstr(0, path, MAXPATH)) < 0 ||
    80005398:	c911                	beqz	a0,800053ac <sys_mknod+0x58>
    end_op();
    return -1;
  }
  iunlockput(ip);
    8000539a:	94efe0ef          	jal	800034e8 <iunlockput>
  end_op();
    8000539e:	9fbfe0ef          	jal	80003d98 <end_op>
  return 0;
    800053a2:	4501                	li	a0,0
}
    800053a4:	60ea                	ld	ra,152(sp)
    800053a6:	644a                	ld	s0,144(sp)
    800053a8:	610d                	addi	sp,sp,160
    800053aa:	8082                	ret
    end_op();
    800053ac:	9edfe0ef          	jal	80003d98 <end_op>
    return -1;
    800053b0:	557d                	li	a0,-1
    800053b2:	bfcd                	j	800053a4 <sys_mknod+0x50>

00000000800053b4 <sys_chdir>:

uint64
sys_chdir(void)
{
    800053b4:	7135                	addi	sp,sp,-160
    800053b6:	ed06                	sd	ra,152(sp)
    800053b8:	e922                	sd	s0,144(sp)
    800053ba:	e14a                	sd	s2,128(sp)
    800053bc:	1100                	addi	s0,sp,160
  char path[MAXPATH];
  struct inode *ip;
  struct proc *p = myproc();
    800053be:	d4afc0ef          	jal	80001908 <myproc>
    800053c2:	892a                	mv	s2,a0

  begin_op();
    800053c4:	949fe0ef          	jal	80003d0c <begin_op>
  if (argstr(0, path, MAXPATH) < 0 || (ip = namei(path)) == 0) {
    800053c8:	08000613          	li	a2,128
    800053cc:	f6040593          	addi	a1,s0,-160
    800053d0:	4501                	li	a0,0
    800053d2:	cb6fd0ef          	jal	80002888 <argstr>
    800053d6:	04054363          	bltz	a0,8000541c <sys_chdir+0x68>
    800053da:	e526                	sd	s1,136(sp)
    800053dc:	f6040513          	addi	a0,s0,-160
    800053e0:	f4efe0ef          	jal	80003b2e <namei>
    800053e4:	84aa                	mv	s1,a0
    800053e6:	c915                	beqz	a0,8000541a <sys_chdir+0x66>
    end_op();
    return -1;
  }
  ilock(ip);
    800053e8:	eadfd0ef          	jal	80003294 <ilock>
  if (ip->type != T_DIR) {
    800053ec:	04449703          	lh	a4,68(s1)
    800053f0:	4785                	li	a5,1
    800053f2:	02f71963          	bne	a4,a5,80005424 <sys_chdir+0x70>
    iunlockput(ip);
    end_op();
    return -1;
  }
  iunlock(ip);
    800053f6:	8526                	mv	a0,s1
    800053f8:	f4bfd0ef          	jal	80003342 <iunlock>
  iput(p->cwd);
    800053fc:	15093503          	ld	a0,336(s2)
    80005400:	816fe0ef          	jal	80003416 <iput>
  end_op();
    80005404:	995fe0ef          	jal	80003d98 <end_op>
  p->cwd = ip;
    80005408:	14993823          	sd	s1,336(s2)
  return 0;
    8000540c:	4501                	li	a0,0
    8000540e:	64aa                	ld	s1,136(sp)
}
    80005410:	60ea                	ld	ra,152(sp)
    80005412:	644a                	ld	s0,144(sp)
    80005414:	690a                	ld	s2,128(sp)
    80005416:	610d                	addi	sp,sp,160
    80005418:	8082                	ret
    8000541a:	64aa                	ld	s1,136(sp)
    end_op();
    8000541c:	97dfe0ef          	jal	80003d98 <end_op>
    return -1;
    80005420:	557d                	li	a0,-1
    80005422:	b7fd                	j	80005410 <sys_chdir+0x5c>
    iunlockput(ip);
    80005424:	8526                	mv	a0,s1
    80005426:	8c2fe0ef          	jal	800034e8 <iunlockput>
    end_op();
    8000542a:	96ffe0ef          	jal	80003d98 <end_op>
    return -1;
    8000542e:	557d                	li	a0,-1
    80005430:	64aa                	ld	s1,136(sp)
    80005432:	bff9                	j	80005410 <sys_chdir+0x5c>

0000000080005434 <sys_exec>:

uint64
sys_exec(void)
{
    80005434:	7105                	addi	sp,sp,-480
    80005436:	ef86                	sd	ra,472(sp)
    80005438:	eba2                	sd	s0,464(sp)
    8000543a:	1380                	addi	s0,sp,480
  char path[MAXPATH], *argv[MAXARG];
  int i;
  uint64 uargv, uarg;

  argaddr(1, &uargv);
    8000543c:	e2840593          	addi	a1,s0,-472
    80005440:	4505                	li	a0,1
    80005442:	c2afd0ef          	jal	8000286c <argaddr>
  if (argstr(0, path, MAXPATH) < 0) {
    80005446:	08000613          	li	a2,128
    8000544a:	f3040593          	addi	a1,s0,-208
    8000544e:	4501                	li	a0,0
    80005450:	c38fd0ef          	jal	80002888 <argstr>
    80005454:	87aa                	mv	a5,a0
    return -1;
    80005456:	557d                	li	a0,-1
  if (argstr(0, path, MAXPATH) < 0) {
    80005458:	0e07c063          	bltz	a5,80005538 <sys_exec+0x104>
    8000545c:	e7a6                	sd	s1,456(sp)
    8000545e:	e3ca                	sd	s2,448(sp)
    80005460:	ff4e                	sd	s3,440(sp)
    80005462:	fb52                	sd	s4,432(sp)
    80005464:	f756                	sd	s5,424(sp)
    80005466:	f35a                	sd	s6,416(sp)
    80005468:	ef5e                	sd	s7,408(sp)
  }
  memset(argv, 0, sizeof(argv));
    8000546a:	e3040a13          	addi	s4,s0,-464
    8000546e:	10000613          	li	a2,256
    80005472:	4581                	li	a1,0
    80005474:	8552                	mv	a0,s4
    80005476:	833fb0ef          	jal	80000ca8 <memset>
  for (i = 0;; i++) {
    if (i >= NELEM(argv)) {
    8000547a:	84d2                	mv	s1,s4
  memset(argv, 0, sizeof(argv));
    8000547c:	89d2                	mv	s3,s4
    8000547e:	4901                	li	s2,0
      goto bad;
    }
    if (fetchaddr(uargv + sizeof(uint64) * i, (uint64 *)&uarg) < 0) {
    80005480:	e2040a93          	addi	s5,s0,-480
      break;
    }
    argv[i] = kalloc();
    if (argv[i] == 0)
      goto bad;
    if (fetchstr(uarg, argv[i], PGSIZE) < 0)
    80005484:	6b05                	lui	s6,0x1
    if (i >= NELEM(argv)) {
    80005486:	02000b93          	li	s7,32
    if (fetchaddr(uargv + sizeof(uint64) * i, (uint64 *)&uarg) < 0) {
    8000548a:	00391513          	slli	a0,s2,0x3
    8000548e:	85d6                	mv	a1,s5
    80005490:	e2843783          	ld	a5,-472(s0)
    80005494:	953e                	add	a0,a0,a5
    80005496:	b2efd0ef          	jal	800027c4 <fetchaddr>
    8000549a:	02054663          	bltz	a0,800054c6 <sys_exec+0x92>
    if (uarg == 0) {
    8000549e:	e2043783          	ld	a5,-480(s0)
    800054a2:	c7a1                	beqz	a5,800054ea <sys_exec+0xb6>
    argv[i] = kalloc();
    800054a4:	e6afb0ef          	jal	80000b0e <kalloc>
    800054a8:	85aa                	mv	a1,a0
    800054aa:	00a9b023          	sd	a0,0(s3)
    if (argv[i] == 0)
    800054ae:	cd01                	beqz	a0,800054c6 <sys_exec+0x92>
    if (fetchstr(uarg, argv[i], PGSIZE) < 0)
    800054b0:	865a                	mv	a2,s6
    800054b2:	e2043503          	ld	a0,-480(s0)
    800054b6:	b58fd0ef          	jal	8000280e <fetchstr>
    800054ba:	00054663          	bltz	a0,800054c6 <sys_exec+0x92>
    if (i >= NELEM(argv)) {
    800054be:	0905                	addi	s2,s2,1
    800054c0:	09a1                	addi	s3,s3,8
    800054c2:	fd7914e3          	bne	s2,s7,8000548a <sys_exec+0x56>
    kfree(argv[i]);

  return ret;

bad:
  for (i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    800054c6:	100a0a13          	addi	s4,s4,256
    800054ca:	6088                	ld	a0,0(s1)
    800054cc:	cd31                	beqz	a0,80005528 <sys_exec+0xf4>
    kfree(argv[i]);
    800054ce:	d58fb0ef          	jal	80000a26 <kfree>
  for (i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    800054d2:	04a1                	addi	s1,s1,8
    800054d4:	ff449be3          	bne	s1,s4,800054ca <sys_exec+0x96>
  return -1;
    800054d8:	557d                	li	a0,-1
    800054da:	64be                	ld	s1,456(sp)
    800054dc:	691e                	ld	s2,448(sp)
    800054de:	79fa                	ld	s3,440(sp)
    800054e0:	7a5a                	ld	s4,432(sp)
    800054e2:	7aba                	ld	s5,424(sp)
    800054e4:	7b1a                	ld	s6,416(sp)
    800054e6:	6bfa                	ld	s7,408(sp)
    800054e8:	a881                	j	80005538 <sys_exec+0x104>
      argv[i] = 0;
    800054ea:	0009079b          	sext.w	a5,s2
    800054ee:	e3040593          	addi	a1,s0,-464
    800054f2:	078e                	slli	a5,a5,0x3
    800054f4:	97ae                	add	a5,a5,a1
    800054f6:	0007b023          	sd	zero,0(a5)
  int ret = kexec(path, argv);
    800054fa:	f3040513          	addi	a0,s0,-208
    800054fe:	b62ff0ef          	jal	80004860 <kexec>
    80005502:	892a                	mv	s2,a0
  for (i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005504:	100a0a13          	addi	s4,s4,256
    80005508:	6088                	ld	a0,0(s1)
    8000550a:	c511                	beqz	a0,80005516 <sys_exec+0xe2>
    kfree(argv[i]);
    8000550c:	d1afb0ef          	jal	80000a26 <kfree>
  for (i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005510:	04a1                	addi	s1,s1,8
    80005512:	ff449be3          	bne	s1,s4,80005508 <sys_exec+0xd4>
  return ret;
    80005516:	854a                	mv	a0,s2
    80005518:	64be                	ld	s1,456(sp)
    8000551a:	691e                	ld	s2,448(sp)
    8000551c:	79fa                	ld	s3,440(sp)
    8000551e:	7a5a                	ld	s4,432(sp)
    80005520:	7aba                	ld	s5,424(sp)
    80005522:	7b1a                	ld	s6,416(sp)
    80005524:	6bfa                	ld	s7,408(sp)
    80005526:	a809                	j	80005538 <sys_exec+0x104>
  return -1;
    80005528:	557d                	li	a0,-1
    8000552a:	64be                	ld	s1,456(sp)
    8000552c:	691e                	ld	s2,448(sp)
    8000552e:	79fa                	ld	s3,440(sp)
    80005530:	7a5a                	ld	s4,432(sp)
    80005532:	7aba                	ld	s5,424(sp)
    80005534:	7b1a                	ld	s6,416(sp)
    80005536:	6bfa                	ld	s7,408(sp)
}
    80005538:	60fe                	ld	ra,472(sp)
    8000553a:	645e                	ld	s0,464(sp)
    8000553c:	613d                	addi	sp,sp,480
    8000553e:	8082                	ret

0000000080005540 <sys_pipe>:

uint64
sys_pipe(void)
{
    80005540:	7139                	addi	sp,sp,-64
    80005542:	fc06                	sd	ra,56(sp)
    80005544:	f822                	sd	s0,48(sp)
    80005546:	f426                	sd	s1,40(sp)
    80005548:	0080                	addi	s0,sp,64
  uint64 fdarray; // user pointer to array of two integers
  struct file *rf, *wf;
  int fd0, fd1;
  struct proc *p = myproc();
    8000554a:	bbefc0ef          	jal	80001908 <myproc>
    8000554e:	84aa                	mv	s1,a0

  argaddr(0, &fdarray);
    80005550:	fd840593          	addi	a1,s0,-40
    80005554:	4501                	li	a0,0
    80005556:	b16fd0ef          	jal	8000286c <argaddr>
  if (pipealloc(&rf, &wf) < 0)
    8000555a:	fc840593          	addi	a1,s0,-56
    8000555e:	fd040513          	addi	a0,s0,-48
    80005562:	f99fe0ef          	jal	800044fa <pipealloc>
    return -1;
    80005566:	57fd                	li	a5,-1
  if (pipealloc(&rf, &wf) < 0)
    80005568:	0a054963          	bltz	a0,8000561a <sys_pipe+0xda>
  fd0 = -1;
    8000556c:	fcf42223          	sw	a5,-60(s0)
  if ((fd0 = fdalloc(rf)) < 0 || (fd1 = fdalloc(wf)) < 0) {
    80005570:	fd043503          	ld	a0,-48(s0)
    80005574:	ea0ff0ef          	jal	80004c14 <fdalloc>
    80005578:	fca42223          	sw	a0,-60(s0)
    8000557c:	08054663          	bltz	a0,80005608 <sys_pipe+0xc8>
    80005580:	fc843503          	ld	a0,-56(s0)
    80005584:	e90ff0ef          	jal	80004c14 <fdalloc>
    80005588:	fca42023          	sw	a0,-64(s0)
    8000558c:	06054463          	bltz	a0,800055f4 <sys_pipe+0xb4>
      p->ofile[fd0] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  if (copyout(p->pagetable, p->sz, fdarray, (char *)&fd0, sizeof(fd0)) < 0 ||
    80005590:	4711                	li	a4,4
    80005592:	fc440693          	addi	a3,s0,-60
    80005596:	fd843603          	ld	a2,-40(s0)
    8000559a:	64ac                	ld	a1,72(s1)
    8000559c:	68a8                	ld	a0,80(s1)
    8000559e:	fa5fb0ef          	jal	80001542 <copyout>
    800055a2:	00054f63          	bltz	a0,800055c0 <sys_pipe+0x80>
      copyout(p->pagetable, p->sz, fdarray + sizeof(fd0), (char *)&fd1,
    800055a6:	4711                	li	a4,4
    800055a8:	fc040693          	addi	a3,s0,-64
    800055ac:	fd843603          	ld	a2,-40(s0)
    800055b0:	963a                	add	a2,a2,a4
    800055b2:	64ac                	ld	a1,72(s1)
    800055b4:	68a8                	ld	a0,80(s1)
    800055b6:	f8dfb0ef          	jal	80001542 <copyout>
    p->ofile[fd1] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  return 0;
    800055ba:	4781                	li	a5,0
  if (copyout(p->pagetable, p->sz, fdarray, (char *)&fd0, sizeof(fd0)) < 0 ||
    800055bc:	04055f63          	bgez	a0,8000561a <sys_pipe+0xda>
    p->ofile[fd0] = 0;
    800055c0:	fc442783          	lw	a5,-60(s0)
    800055c4:	078e                	slli	a5,a5,0x3
    800055c6:	0d078793          	addi	a5,a5,208
    800055ca:	97a6                	add	a5,a5,s1
    800055cc:	0007b023          	sd	zero,0(a5)
    p->ofile[fd1] = 0;
    800055d0:	fc042783          	lw	a5,-64(s0)
    800055d4:	078e                	slli	a5,a5,0x3
    800055d6:	0d078793          	addi	a5,a5,208
    800055da:	94be                	add	s1,s1,a5
    800055dc:	0004b023          	sd	zero,0(s1)
    fileclose(rf);
    800055e0:	fd043503          	ld	a0,-48(s0)
    800055e4:	be3fe0ef          	jal	800041c6 <fileclose>
    fileclose(wf);
    800055e8:	fc843503          	ld	a0,-56(s0)
    800055ec:	bdbfe0ef          	jal	800041c6 <fileclose>
    return -1;
    800055f0:	57fd                	li	a5,-1
    800055f2:	a025                	j	8000561a <sys_pipe+0xda>
    if (fd0 >= 0)
    800055f4:	fc442783          	lw	a5,-60(s0)
    800055f8:	0007c863          	bltz	a5,80005608 <sys_pipe+0xc8>
      p->ofile[fd0] = 0;
    800055fc:	078e                	slli	a5,a5,0x3
    800055fe:	0d078793          	addi	a5,a5,208
    80005602:	97a6                	add	a5,a5,s1
    80005604:	0007b023          	sd	zero,0(a5)
    fileclose(rf);
    80005608:	fd043503          	ld	a0,-48(s0)
    8000560c:	bbbfe0ef          	jal	800041c6 <fileclose>
    fileclose(wf);
    80005610:	fc843503          	ld	a0,-56(s0)
    80005614:	bb3fe0ef          	jal	800041c6 <fileclose>
    return -1;
    80005618:	57fd                	li	a5,-1
}
    8000561a:	853e                	mv	a0,a5
    8000561c:	70e2                	ld	ra,56(sp)
    8000561e:	7442                	ld	s0,48(sp)
    80005620:	74a2                	ld	s1,40(sp)
    80005622:	6121                	addi	sp,sp,64
    80005624:	8082                	ret
	...

0000000080005630 <kernelvec>:
.globl kerneltrap
.globl kernelvec
.align 4
kernelvec:
        # make room to save registers.
        addi sp, sp, -256
    80005630:	7111                	addi	sp,sp,-256

        # save caller-saved registers.
        sd ra, 0(sp)
    80005632:	e006                	sd	ra,0(sp)
        # sd sp, 8(sp)
        sd gp, 16(sp)
    80005634:	e80e                	sd	gp,16(sp)
        # sd tp, 24(sp)
        sd t0, 32(sp)
    80005636:	f016                	sd	t0,32(sp)
        sd t1, 40(sp)
    80005638:	f41a                	sd	t1,40(sp)
        sd t2, 48(sp)
    8000563a:	f81e                	sd	t2,48(sp)
        sd a0, 72(sp)
    8000563c:	e4aa                	sd	a0,72(sp)
        sd a1, 80(sp)
    8000563e:	e8ae                	sd	a1,80(sp)
        sd a2, 88(sp)
    80005640:	ecb2                	sd	a2,88(sp)
        sd a3, 96(sp)
    80005642:	f0b6                	sd	a3,96(sp)
        sd a4, 104(sp)
    80005644:	f4ba                	sd	a4,104(sp)
        sd a5, 112(sp)
    80005646:	f8be                	sd	a5,112(sp)
        sd a6, 120(sp)
    80005648:	fcc2                	sd	a6,120(sp)
        sd a7, 128(sp)
    8000564a:	e146                	sd	a7,128(sp)
        sd t3, 216(sp)
    8000564c:	edf2                	sd	t3,216(sp)
        sd t4, 224(sp)
    8000564e:	f1f6                	sd	t4,224(sp)
        sd t5, 232(sp)
    80005650:	f5fa                	sd	t5,232(sp)
        sd t6, 240(sp)
    80005652:	f9fe                	sd	t6,240(sp)

        # call the C trap handler in trap.c
        call kerneltrap
    80005654:	87efd0ef          	jal	800026d2 <kerneltrap>

        # restore registers.
        ld ra, 0(sp)
    80005658:	6082                	ld	ra,0(sp)
        # ld sp, 8(sp)
        ld gp, 16(sp)
    8000565a:	61c2                	ld	gp,16(sp)
        # not tp (contains hartid), in case we moved CPUs
        ld t0, 32(sp)
    8000565c:	7282                	ld	t0,32(sp)
        ld t1, 40(sp)
    8000565e:	7322                	ld	t1,40(sp)
        ld t2, 48(sp)
    80005660:	73c2                	ld	t2,48(sp)
        ld a0, 72(sp)
    80005662:	6526                	ld	a0,72(sp)
        ld a1, 80(sp)
    80005664:	65c6                	ld	a1,80(sp)
        ld a2, 88(sp)
    80005666:	6666                	ld	a2,88(sp)
        ld a3, 96(sp)
    80005668:	7686                	ld	a3,96(sp)
        ld a4, 104(sp)
    8000566a:	7726                	ld	a4,104(sp)
        ld a5, 112(sp)
    8000566c:	77c6                	ld	a5,112(sp)
        ld a6, 120(sp)
    8000566e:	7866                	ld	a6,120(sp)
        ld a7, 128(sp)
    80005670:	688a                	ld	a7,128(sp)
        ld t3, 216(sp)
    80005672:	6e6e                	ld	t3,216(sp)
        ld t4, 224(sp)
    80005674:	7e8e                	ld	t4,224(sp)
        ld t5, 232(sp)
    80005676:	7f2e                	ld	t5,232(sp)
        ld t6, 240(sp)
    80005678:	7fce                	ld	t6,240(sp)

        addi sp, sp, 256
    8000567a:	6111                	addi	sp,sp,256

        # return to whatever we were doing in the kernel.
        sret
    8000567c:	10200073          	sret
    80005680:	0001                	nop
    80005682:	00000013          	nop
    80005686:	00000013          	nop
    8000568a:	00000013          	nop

000000008000568e <plicinit>:
// the riscv Platform Level Interrupt Controller (PLIC).
//

void
plicinit(void)
{
    8000568e:	1141                	addi	sp,sp,-16
    80005690:	e406                	sd	ra,8(sp)
    80005692:	e022                	sd	s0,0(sp)
    80005694:	0800                	addi	s0,sp,16
  // set desired IRQ priorities non-zero (otherwise disabled).
  *(volatile uint32 *)(PLIC + UART0_IRQ * 4) = 1;
    80005696:	0c000737          	lui	a4,0xc000
    8000569a:	4785                	li	a5,1
    8000569c:	d71c                	sw	a5,40(a4)
  *(volatile uint32 *)(PLIC + VIRTIO0_IRQ * 4) = 1;
    8000569e:	c35c                	sw	a5,4(a4)
}
    800056a0:	60a2                	ld	ra,8(sp)
    800056a2:	6402                	ld	s0,0(sp)
    800056a4:	0141                	addi	sp,sp,16
    800056a6:	8082                	ret

00000000800056a8 <plicinithart>:

void
plicinithart(void)
{
    800056a8:	1141                	addi	sp,sp,-16
    800056aa:	e406                	sd	ra,8(sp)
    800056ac:	e022                	sd	s0,0(sp)
    800056ae:	0800                	addi	s0,sp,16
  int hart = cpuid();
    800056b0:	a24fc0ef          	jal	800018d4 <cpuid>

  // set enable bits for this hart's S-mode
  // for the uart and virtio disk.
  *(volatile uint32 *)PLIC_SENABLE(hart) =
    800056b4:	0085179b          	slliw	a5,a0,0x8
    800056b8:	0c002737          	lui	a4,0xc002
    800056bc:	08070713          	addi	a4,a4,128 # c002080 <_entry-0x73ffdf80>
    800056c0:	97ba                	add	a5,a5,a4
    800056c2:	40200713          	li	a4,1026
    800056c6:	c398                	sw	a4,0(a5)
    (1 << UART0_IRQ) | (1 << VIRTIO0_IRQ);

  // set this hart's S-mode priority threshold to 0.
  *(volatile uint32 *)PLIC_SPRIORITY(hart) = 0;
    800056c8:	00d5151b          	slliw	a0,a0,0xd
    800056cc:	0c2017b7          	lui	a5,0xc201
    800056d0:	953e                	add	a0,a0,a5
    800056d2:	00052023          	sw	zero,0(a0)
}
    800056d6:	60a2                	ld	ra,8(sp)
    800056d8:	6402                	ld	s0,0(sp)
    800056da:	0141                	addi	sp,sp,16
    800056dc:	8082                	ret

00000000800056de <plic_claim>:

// ask the PLIC what interrupt we should serve.
int
plic_claim(void)
{
    800056de:	1141                	addi	sp,sp,-16
    800056e0:	e406                	sd	ra,8(sp)
    800056e2:	e022                	sd	s0,0(sp)
    800056e4:	0800                	addi	s0,sp,16
  int hart = cpuid();
    800056e6:	9eefc0ef          	jal	800018d4 <cpuid>
  int irq = *(volatile uint32 *)PLIC_SCLAIM(hart);
    800056ea:	00d5151b          	slliw	a0,a0,0xd
    800056ee:	0c2017b7          	lui	a5,0xc201
    800056f2:	0791                	addi	a5,a5,4 # c201004 <_entry-0x73dfeffc>
    800056f4:	953e                	add	a0,a0,a5
    800056f6:	4108                	lw	a0,0(a0)
  return irq;
}
    800056f8:	60a2                	ld	ra,8(sp)
    800056fa:	6402                	ld	s0,0(sp)
    800056fc:	0141                	addi	sp,sp,16
    800056fe:	8082                	ret

0000000080005700 <plic_complete>:

// tell the PLIC we've served this IRQ.
void
plic_complete(int irq)
{
    80005700:	1101                	addi	sp,sp,-32
    80005702:	ec06                	sd	ra,24(sp)
    80005704:	e822                	sd	s0,16(sp)
    80005706:	e426                	sd	s1,8(sp)
    80005708:	1000                	addi	s0,sp,32
    8000570a:	84aa                	mv	s1,a0
  int hart = cpuid();
    8000570c:	9c8fc0ef          	jal	800018d4 <cpuid>
  *(volatile uint32 *)PLIC_SCLAIM(hart) = irq;
    80005710:	00d5179b          	slliw	a5,a0,0xd
    80005714:	0c201737          	lui	a4,0xc201
    80005718:	0711                	addi	a4,a4,4 # c201004 <_entry-0x73dfeffc>
    8000571a:	97ba                	add	a5,a5,a4
    8000571c:	c384                	sw	s1,0(a5)
}
    8000571e:	60e2                	ld	ra,24(sp)
    80005720:	6442                	ld	s0,16(sp)
    80005722:	64a2                	ld	s1,8(sp)
    80005724:	6105                	addi	sp,sp,32
    80005726:	8082                	ret

0000000080005728 <free_desc>:
}

// mark a descriptor as free.
static void
free_desc(int i)
{
    80005728:	1141                	addi	sp,sp,-16
    8000572a:	e406                	sd	ra,8(sp)
    8000572c:	e022                	sd	s0,0(sp)
    8000572e:	0800                	addi	s0,sp,16
  if (i >= NUM)
    80005730:	479d                	li	a5,7
    80005732:	04a7ca63          	blt	a5,a0,80005786 <free_desc+0x5e>
    panic("free_desc 1");
  if (disk.free[i])
    80005736:	0001e797          	auipc	a5,0x1e
    8000573a:	dda78793          	addi	a5,a5,-550 # 80023510 <disk>
    8000573e:	97aa                	add	a5,a5,a0
    80005740:	0187c783          	lbu	a5,24(a5)
    80005744:	e7b9                	bnez	a5,80005792 <free_desc+0x6a>
    panic("free_desc 2");
  disk.desc[i].addr = 0;
    80005746:	00451693          	slli	a3,a0,0x4
    8000574a:	0001e797          	auipc	a5,0x1e
    8000574e:	dc678793          	addi	a5,a5,-570 # 80023510 <disk>
    80005752:	6398                	ld	a4,0(a5)
    80005754:	9736                	add	a4,a4,a3
    80005756:	00073023          	sd	zero,0(a4)
  disk.desc[i].len = 0;
    8000575a:	6398                	ld	a4,0(a5)
    8000575c:	9736                	add	a4,a4,a3
    8000575e:	00072423          	sw	zero,8(a4)
  disk.desc[i].flags = 0;
    80005762:	00071623          	sh	zero,12(a4)
  disk.desc[i].next = 0;
    80005766:	00071723          	sh	zero,14(a4)
  disk.free[i] = 1;
    8000576a:	97aa                	add	a5,a5,a0
    8000576c:	4705                	li	a4,1
    8000576e:	00e78c23          	sb	a4,24(a5)
  wakeup(&disk.free[0]);
    80005772:	0001e517          	auipc	a0,0x1e
    80005776:	db650513          	addi	a0,a0,-586 # 80023528 <disk+0x18>
    8000577a:	805fc0ef          	jal	80001f7e <wakeup>
}
    8000577e:	60a2                	ld	ra,8(sp)
    80005780:	6402                	ld	s0,0(sp)
    80005782:	0141                	addi	sp,sp,16
    80005784:	8082                	ret
    panic("free_desc 1");
    80005786:	00002517          	auipc	a0,0x2
    8000578a:	ec250513          	addi	a0,a0,-318 # 80007648 <etext+0x648>
    8000578e:	8a6fb0ef          	jal	80000834 <panic>
    panic("free_desc 2");
    80005792:	00002517          	auipc	a0,0x2
    80005796:	ec650513          	addi	a0,a0,-314 # 80007658 <etext+0x658>
    8000579a:	89afb0ef          	jal	80000834 <panic>

000000008000579e <virtio_disk_init>:
{
    8000579e:	1101                	addi	sp,sp,-32
    800057a0:	ec06                	sd	ra,24(sp)
    800057a2:	e822                	sd	s0,16(sp)
    800057a4:	e426                	sd	s1,8(sp)
    800057a6:	e04a                	sd	s2,0(sp)
    800057a8:	1000                	addi	s0,sp,32
  initlock(&disk.vdisk_lock, "virtio_disk");
    800057aa:	00002597          	auipc	a1,0x2
    800057ae:	ebe58593          	addi	a1,a1,-322 # 80007668 <etext+0x668>
    800057b2:	0001e517          	auipc	a0,0x1e
    800057b6:	e8650513          	addi	a0,a0,-378 # 80023638 <disk+0x128>
    800057ba:	baefb0ef          	jal	80000b68 <initlock>
  if (*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    800057be:	100017b7          	lui	a5,0x10001
    800057c2:	4398                	lw	a4,0(a5)
    800057c4:	2701                	sext.w	a4,a4
    800057c6:	747277b7          	lui	a5,0x74727
    800057ca:	97678793          	addi	a5,a5,-1674 # 74726976 <_entry-0xb8d968a>
    800057ce:	14f71863          	bne	a4,a5,8000591e <virtio_disk_init+0x180>
      *R(VIRTIO_MMIO_VERSION) != 2 || *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    800057d2:	100017b7          	lui	a5,0x10001
    800057d6:	43dc                	lw	a5,4(a5)
    800057d8:	2781                	sext.w	a5,a5
  if (*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    800057da:	4709                	li	a4,2
    800057dc:	14e79163          	bne	a5,a4,8000591e <virtio_disk_init+0x180>
      *R(VIRTIO_MMIO_VERSION) != 2 || *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    800057e0:	100017b7          	lui	a5,0x10001
    800057e4:	479c                	lw	a5,8(a5)
    800057e6:	2781                	sext.w	a5,a5
    800057e8:	12e79b63          	bne	a5,a4,8000591e <virtio_disk_init+0x180>
      *R(VIRTIO_MMIO_VENDOR_ID) != 0x554d4551) {
    800057ec:	100017b7          	lui	a5,0x10001
    800057f0:	47d8                	lw	a4,12(a5)
    800057f2:	2701                	sext.w	a4,a4
      *R(VIRTIO_MMIO_VERSION) != 2 || *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    800057f4:	554d47b7          	lui	a5,0x554d4
    800057f8:	55178793          	addi	a5,a5,1361 # 554d4551 <_entry-0x2ab2baaf>
    800057fc:	12f71163          	bne	a4,a5,8000591e <virtio_disk_init+0x180>
  *R(VIRTIO_MMIO_STATUS) = status;
    80005800:	100017b7          	lui	a5,0x10001
    80005804:	0607a823          	sw	zero,112(a5) # 10001070 <_entry-0x6fffef90>
  *R(VIRTIO_MMIO_STATUS) = status;
    80005808:	4705                	li	a4,1
    8000580a:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    8000580c:	470d                	li	a4,3
    8000580e:	dbb8                	sw	a4,112(a5)
  uint64 features = *R(VIRTIO_MMIO_DEVICE_FEATURES);
    80005810:	10001737          	lui	a4,0x10001
    80005814:	4b18                	lw	a4,16(a4)
  features &= ~(1 << VIRTIO_RING_F_INDIRECT_DESC);
    80005816:	c7ffe6b7          	lui	a3,0xc7ffe
    8000581a:	55f68693          	addi	a3,a3,1375 # ffffffffc7ffe55f <end+0xffffffff47fdaf0f>
  *R(VIRTIO_MMIO_DRIVER_FEATURES) = features;
    8000581e:	8f75                	and	a4,a4,a3
    80005820:	100016b7          	lui	a3,0x10001
    80005824:	d298                	sw	a4,32(a3)
  *R(VIRTIO_MMIO_STATUS) = status;
    80005826:	472d                	li	a4,11
    80005828:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    8000582a:	07078793          	addi	a5,a5,112
  status = *R(VIRTIO_MMIO_STATUS);
    8000582e:	439c                	lw	a5,0(a5)
    80005830:	0007891b          	sext.w	s2,a5
  if (!(status & VIRTIO_CONFIG_S_FEATURES_OK))
    80005834:	8ba1                	andi	a5,a5,8
    80005836:	0e078a63          	beqz	a5,8000592a <virtio_disk_init+0x18c>
  *R(VIRTIO_MMIO_QUEUE_SEL) = 0;
    8000583a:	100017b7          	lui	a5,0x10001
    8000583e:	0207a823          	sw	zero,48(a5) # 10001030 <_entry-0x6fffefd0>
  if (*R(VIRTIO_MMIO_QUEUE_READY))
    80005842:	43fc                	lw	a5,68(a5)
    80005844:	2781                	sext.w	a5,a5
    80005846:	0e079863          	bnez	a5,80005936 <virtio_disk_init+0x198>
  uint32 max = *R(VIRTIO_MMIO_QUEUE_NUM_MAX);
    8000584a:	100017b7          	lui	a5,0x10001
    8000584e:	5bdc                	lw	a5,52(a5)
    80005850:	2781                	sext.w	a5,a5
  if (max == 0)
    80005852:	0e078863          	beqz	a5,80005942 <virtio_disk_init+0x1a4>
  if (max < NUM)
    80005856:	471d                	li	a4,7
    80005858:	0ef77b63          	bgeu	a4,a5,8000594e <virtio_disk_init+0x1b0>
  disk.desc = kalloc();
    8000585c:	ab2fb0ef          	jal	80000b0e <kalloc>
    80005860:	0001e497          	auipc	s1,0x1e
    80005864:	cb048493          	addi	s1,s1,-848 # 80023510 <disk>
    80005868:	e088                	sd	a0,0(s1)
  disk.avail = kalloc();
    8000586a:	aa4fb0ef          	jal	80000b0e <kalloc>
    8000586e:	e488                	sd	a0,8(s1)
  disk.used = kalloc();
    80005870:	a9efb0ef          	jal	80000b0e <kalloc>
    80005874:	87aa                	mv	a5,a0
    80005876:	e888                	sd	a0,16(s1)
  if (!disk.desc || !disk.avail || !disk.used)
    80005878:	6088                	ld	a0,0(s1)
    8000587a:	0e050063          	beqz	a0,8000595a <virtio_disk_init+0x1bc>
    8000587e:	0001e717          	auipc	a4,0x1e
    80005882:	c9a73703          	ld	a4,-870(a4) # 80023518 <disk+0x8>
    80005886:	cb71                	beqz	a4,8000595a <virtio_disk_init+0x1bc>
    80005888:	cbe9                	beqz	a5,8000595a <virtio_disk_init+0x1bc>
  memset(disk.desc, 0, PGSIZE);
    8000588a:	6605                	lui	a2,0x1
    8000588c:	4581                	li	a1,0
    8000588e:	c1afb0ef          	jal	80000ca8 <memset>
  memset(disk.avail, 0, PGSIZE);
    80005892:	0001e497          	auipc	s1,0x1e
    80005896:	c7e48493          	addi	s1,s1,-898 # 80023510 <disk>
    8000589a:	6605                	lui	a2,0x1
    8000589c:	4581                	li	a1,0
    8000589e:	6488                	ld	a0,8(s1)
    800058a0:	c08fb0ef          	jal	80000ca8 <memset>
  memset(disk.used, 0, PGSIZE);
    800058a4:	6605                	lui	a2,0x1
    800058a6:	4581                	li	a1,0
    800058a8:	6888                	ld	a0,16(s1)
    800058aa:	bfefb0ef          	jal	80000ca8 <memset>
  *R(VIRTIO_MMIO_QUEUE_NUM) = NUM;
    800058ae:	100017b7          	lui	a5,0x10001
    800058b2:	4721                	li	a4,8
    800058b4:	df98                	sw	a4,56(a5)
  *R(VIRTIO_MMIO_QUEUE_DESC_LOW) = (uint64)disk.desc;
    800058b6:	4098                	lw	a4,0(s1)
    800058b8:	08e7a023          	sw	a4,128(a5) # 10001080 <_entry-0x6fffef80>
  *R(VIRTIO_MMIO_QUEUE_DESC_HIGH) = (uint64)disk.desc >> 32;
    800058bc:	40d8                	lw	a4,4(s1)
    800058be:	08e7a223          	sw	a4,132(a5)
  *R(VIRTIO_MMIO_DRIVER_DESC_LOW) = (uint64)disk.avail;
    800058c2:	649c                	ld	a5,8(s1)
    800058c4:	0007869b          	sext.w	a3,a5
    800058c8:	10001737          	lui	a4,0x10001
    800058cc:	08d72823          	sw	a3,144(a4) # 10001090 <_entry-0x6fffef70>
  *R(VIRTIO_MMIO_DRIVER_DESC_HIGH) = (uint64)disk.avail >> 32;
    800058d0:	9781                	srai	a5,a5,0x20
    800058d2:	08f72a23          	sw	a5,148(a4)
  *R(VIRTIO_MMIO_DEVICE_DESC_LOW) = (uint64)disk.used;
    800058d6:	689c                	ld	a5,16(s1)
    800058d8:	0007869b          	sext.w	a3,a5
    800058dc:	0ad72023          	sw	a3,160(a4)
  *R(VIRTIO_MMIO_DEVICE_DESC_HIGH) = (uint64)disk.used >> 32;
    800058e0:	9781                	srai	a5,a5,0x20
    800058e2:	0af72223          	sw	a5,164(a4)
  *R(VIRTIO_MMIO_QUEUE_READY) = 0x1;
    800058e6:	4785                	li	a5,1
    800058e8:	c37c                	sw	a5,68(a4)
    disk.free[i] = 1;
    800058ea:	00f48c23          	sb	a5,24(s1)
    800058ee:	00f48ca3          	sb	a5,25(s1)
    800058f2:	00f48d23          	sb	a5,26(s1)
    800058f6:	00f48da3          	sb	a5,27(s1)
    800058fa:	00f48e23          	sb	a5,28(s1)
    800058fe:	00f48ea3          	sb	a5,29(s1)
    80005902:	00f48f23          	sb	a5,30(s1)
    80005906:	00f48fa3          	sb	a5,31(s1)
  status |= VIRTIO_CONFIG_S_DRIVER_OK;
    8000590a:	00496913          	ori	s2,s2,4
  *R(VIRTIO_MMIO_STATUS) = status;
    8000590e:	07272823          	sw	s2,112(a4)
}
    80005912:	60e2                	ld	ra,24(sp)
    80005914:	6442                	ld	s0,16(sp)
    80005916:	64a2                	ld	s1,8(sp)
    80005918:	6902                	ld	s2,0(sp)
    8000591a:	6105                	addi	sp,sp,32
    8000591c:	8082                	ret
    panic("could not find virtio disk");
    8000591e:	00002517          	auipc	a0,0x2
    80005922:	d5a50513          	addi	a0,a0,-678 # 80007678 <etext+0x678>
    80005926:	f0ffa0ef          	jal	80000834 <panic>
    panic("virtio disk FEATURES_OK unset");
    8000592a:	00002517          	auipc	a0,0x2
    8000592e:	d6e50513          	addi	a0,a0,-658 # 80007698 <etext+0x698>
    80005932:	f03fa0ef          	jal	80000834 <panic>
    panic("virtio disk should not be ready");
    80005936:	00002517          	auipc	a0,0x2
    8000593a:	d8250513          	addi	a0,a0,-638 # 800076b8 <etext+0x6b8>
    8000593e:	ef7fa0ef          	jal	80000834 <panic>
    panic("virtio disk has no queue 0");
    80005942:	00002517          	auipc	a0,0x2
    80005946:	d9650513          	addi	a0,a0,-618 # 800076d8 <etext+0x6d8>
    8000594a:	eebfa0ef          	jal	80000834 <panic>
    panic("virtio disk max queue too short");
    8000594e:	00002517          	auipc	a0,0x2
    80005952:	daa50513          	addi	a0,a0,-598 # 800076f8 <etext+0x6f8>
    80005956:	edffa0ef          	jal	80000834 <panic>
    panic("virtio disk kalloc");
    8000595a:	00002517          	auipc	a0,0x2
    8000595e:	dbe50513          	addi	a0,a0,-578 # 80007718 <etext+0x718>
    80005962:	ed3fa0ef          	jal	80000834 <panic>

0000000080005966 <virtio_disk_rw>:
  return 0;
}

void
virtio_disk_rw(struct buf *b, int write)
{
    80005966:	711d                	addi	sp,sp,-96
    80005968:	ec86                	sd	ra,88(sp)
    8000596a:	e8a2                	sd	s0,80(sp)
    8000596c:	e4a6                	sd	s1,72(sp)
    8000596e:	e0ca                	sd	s2,64(sp)
    80005970:	fc4e                	sd	s3,56(sp)
    80005972:	f852                	sd	s4,48(sp)
    80005974:	f456                	sd	s5,40(sp)
    80005976:	f05a                	sd	s6,32(sp)
    80005978:	ec5e                	sd	s7,24(sp)
    8000597a:	e862                	sd	s8,16(sp)
    8000597c:	1080                	addi	s0,sp,96
    8000597e:	89aa                	mv	s3,a0
    80005980:	8b2e                	mv	s6,a1
  uint64 sector = b->blockno * (BSIZE / 512);
    80005982:	00c52b83          	lw	s7,12(a0)
    80005986:	001b9b9b          	slliw	s7,s7,0x1
    8000598a:	1b82                	slli	s7,s7,0x20
    8000598c:	020bdb93          	srli	s7,s7,0x20

  acquire(&disk.vdisk_lock);
    80005990:	0001e517          	auipc	a0,0x1e
    80005994:	ca850513          	addi	a0,a0,-856 # 80023638 <disk+0x128>
    80005998:	a50fb0ef          	jal	80000be8 <acquire>
  for (int i = 0; i < NUM; i++) {
    8000599c:	44a1                	li	s1,8
      disk.free[i] = 0;
    8000599e:	0001ea97          	auipc	s5,0x1e
    800059a2:	b72a8a93          	addi	s5,s5,-1166 # 80023510 <disk>
  for (int i = 0; i < 3; i++) {
    800059a6:	4a0d                	li	s4,3
    idx[i] = alloc_desc();
    800059a8:	5c7d                	li	s8,-1
    800059aa:	a8a5                	j	80005a22 <virtio_disk_rw+0xbc>
      disk.free[i] = 0;
    800059ac:	00fa8733          	add	a4,s5,a5
    800059b0:	00070c23          	sb	zero,24(a4)
    idx[i] = alloc_desc();
    800059b4:	c19c                	sw	a5,0(a1)
    if (idx[i] < 0) {
    800059b6:	0207c563          	bltz	a5,800059e0 <virtio_disk_rw+0x7a>
  for (int i = 0; i < 3; i++) {
    800059ba:	2905                	addiw	s2,s2,1
    800059bc:	0611                	addi	a2,a2,4 # 1004 <_entry-0x7fffeffc>
    800059be:	07490663          	beq	s2,s4,80005a2a <virtio_disk_rw+0xc4>
    idx[i] = alloc_desc();
    800059c2:	85b2                	mv	a1,a2
  for (int i = 0; i < NUM; i++) {
    800059c4:	0001e717          	auipc	a4,0x1e
    800059c8:	b4c70713          	addi	a4,a4,-1204 # 80023510 <disk>
    800059cc:	4781                	li	a5,0
    if (disk.free[i]) {
    800059ce:	01874683          	lbu	a3,24(a4)
    800059d2:	fee9                	bnez	a3,800059ac <virtio_disk_rw+0x46>
  for (int i = 0; i < NUM; i++) {
    800059d4:	2785                	addiw	a5,a5,1
    800059d6:	0705                	addi	a4,a4,1
    800059d8:	fe979be3          	bne	a5,s1,800059ce <virtio_disk_rw+0x68>
    idx[i] = alloc_desc();
    800059dc:	0185a023          	sw	s8,0(a1)
      for (int j = 0; j < i; j++)
    800059e0:	01205d63          	blez	s2,800059fa <virtio_disk_rw+0x94>
        free_desc(idx[j]);
    800059e4:	fa042503          	lw	a0,-96(s0)
    800059e8:	d41ff0ef          	jal	80005728 <free_desc>
      for (int j = 0; j < i; j++)
    800059ec:	4785                	li	a5,1
    800059ee:	0127d663          	bge	a5,s2,800059fa <virtio_disk_rw+0x94>
        free_desc(idx[j]);
    800059f2:	fa442503          	lw	a0,-92(s0)
    800059f6:	d33ff0ef          	jal	80005728 <free_desc>
  int idx[3];
  while (1) {
    if (alloc3_desc(idx) == 0) {
      break;
    }
    sleep_prepare(&disk.free[0]);
    800059fa:	0001e517          	auipc	a0,0x1e
    800059fe:	b2e50513          	addi	a0,a0,-1234 # 80023528 <disk+0x18>
    80005a02:	d10fc0ef          	jal	80001f12 <sleep_prepare>
    release(&disk.vdisk_lock);
    80005a06:	0001e517          	auipc	a0,0x1e
    80005a0a:	c3250513          	addi	a0,a0,-974 # 80023638 <disk+0x128>
    80005a0e:	a62fb0ef          	jal	80000c70 <release>
    sleep();
    80005a12:	d3cfc0ef          	jal	80001f4e <sleep>
    acquire(&disk.vdisk_lock);
    80005a16:	0001e517          	auipc	a0,0x1e
    80005a1a:	c2250513          	addi	a0,a0,-990 # 80023638 <disk+0x128>
    80005a1e:	9cafb0ef          	jal	80000be8 <acquire>
  for (int i = 0; i < 3; i++) {
    80005a22:	fa040613          	addi	a2,s0,-96
    80005a26:	4901                	li	s2,0
    80005a28:	bf69                	j	800059c2 <virtio_disk_rw+0x5c>
  }

  // format the three descriptors.
  // qemu's virtio-blk.c reads them.

  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    80005a2a:	fa042503          	lw	a0,-96(s0)
    80005a2e:	00451693          	slli	a3,a0,0x4

  if (write)
    80005a32:	0001e797          	auipc	a5,0x1e
    80005a36:	ade78793          	addi	a5,a5,-1314 # 80023510 <disk>
    80005a3a:	00451713          	slli	a4,a0,0x4
    80005a3e:	0a070713          	addi	a4,a4,160
    80005a42:	973e                	add	a4,a4,a5
    80005a44:	01603633          	snez	a2,s6
    80005a48:	c710                	sw	a2,8(a4)
    buf0->type = VIRTIO_BLK_T_OUT; // write the disk
  else
    buf0->type = VIRTIO_BLK_T_IN; // read the disk
  buf0->reserved = 0;
    80005a4a:	00072623          	sw	zero,12(a4)
  buf0->sector = sector;
    80005a4e:	01773823          	sd	s7,16(a4)

  disk.desc[idx[0]].addr = (uint64)buf0;
    80005a52:	6398                	ld	a4,0(a5)
    80005a54:	9736                	add	a4,a4,a3
  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    80005a56:	0a868613          	addi	a2,a3,168 # 100010a8 <_entry-0x6fffef58>
    80005a5a:	963e                	add	a2,a2,a5
  disk.desc[idx[0]].addr = (uint64)buf0;
    80005a5c:	e310                	sd	a2,0(a4)
  disk.desc[idx[0]].len = sizeof(struct virtio_blk_req);
    80005a5e:	6390                	ld	a2,0(a5)
    80005a60:	00d60833          	add	a6,a2,a3
    80005a64:	4741                	li	a4,16
    80005a66:	00e82423          	sw	a4,8(a6)
  disk.desc[idx[0]].flags = VRING_DESC_F_NEXT;
    80005a6a:	4585                	li	a1,1
    80005a6c:	00b81623          	sh	a1,12(a6)
  disk.desc[idx[0]].next = idx[1];
    80005a70:	fa442703          	lw	a4,-92(s0)
    80005a74:	00e81723          	sh	a4,14(a6)

  disk.desc[idx[1]].addr = (uint64)b->data;
    80005a78:	0712                	slli	a4,a4,0x4
    80005a7a:	963a                	add	a2,a2,a4
    80005a7c:	05898813          	addi	a6,s3,88
    80005a80:	01063023          	sd	a6,0(a2)
  disk.desc[idx[1]].len = BSIZE;
    80005a84:	0007b883          	ld	a7,0(a5)
    80005a88:	9746                	add	a4,a4,a7
    80005a8a:	40000613          	li	a2,1024
    80005a8e:	c710                	sw	a2,8(a4)
  if (write)
    80005a90:	001b3613          	seqz	a2,s6
    80005a94:	0016161b          	slliw	a2,a2,0x1
    disk.desc[idx[1]].flags = 0; // device reads b->data
  else
    disk.desc[idx[1]].flags = VRING_DESC_F_WRITE; // device writes b->data
  disk.desc[idx[1]].flags |= VRING_DESC_F_NEXT;
    80005a98:	8e4d                	or	a2,a2,a1
    80005a9a:	00c71623          	sh	a2,12(a4)
  disk.desc[idx[1]].next = idx[2];
    80005a9e:	fa842603          	lw	a2,-88(s0)
    80005aa2:	00c71723          	sh	a2,14(a4)

  disk.info[idx[0]].status = 0xff; // device writes 0 on success
    80005aa6:	00451813          	slli	a6,a0,0x4
    80005aaa:	02080813          	addi	a6,a6,32
    80005aae:	983e                	add	a6,a6,a5
    80005ab0:	577d                	li	a4,-1
    80005ab2:	00e80823          	sb	a4,16(a6)
  disk.desc[idx[2]].addr = (uint64)&disk.info[idx[0]].status;
    80005ab6:	0612                	slli	a2,a2,0x4
    80005ab8:	98b2                	add	a7,a7,a2
    80005aba:	03068713          	addi	a4,a3,48
    80005abe:	973e                	add	a4,a4,a5
    80005ac0:	00e8b023          	sd	a4,0(a7)
  disk.desc[idx[2]].len = 1;
    80005ac4:	6398                	ld	a4,0(a5)
    80005ac6:	9732                	add	a4,a4,a2
    80005ac8:	c70c                	sw	a1,8(a4)
  disk.desc[idx[2]].flags = VRING_DESC_F_WRITE; // device writes the status
    80005aca:	4689                	li	a3,2
    80005acc:	00d71623          	sh	a3,12(a4)
  disk.desc[idx[2]].next = 0;
    80005ad0:	00071723          	sh	zero,14(a4)

  // record struct buf for virtio_disk_intr().
  b->disk = 1;
    80005ad4:	00b9a223          	sw	a1,4(s3)
  disk.info[idx[0]].b = b;
    80005ad8:	01383423          	sd	s3,8(a6)

  // tell the device the first index in our chain of descriptors.
  disk.avail->ring[disk.avail->idx % NUM] = idx[0];
    80005adc:	6794                	ld	a3,8(a5)
    80005ade:	0026d703          	lhu	a4,2(a3)
    80005ae2:	8b1d                	andi	a4,a4,7
    80005ae4:	0706                	slli	a4,a4,0x1
    80005ae6:	96ba                	add	a3,a3,a4
    80005ae8:	00a69223          	sh	a0,4(a3)

// fence for memory-mapped IO
static inline void
io_fence()
{
  asm volatile("fence iorw, iorw" ::: "memory");
    80005aec:	0ff0000f          	fence

  io_fence();

  // tell the device another avail ring entry is available.
  disk.avail->idx += 1; // not % NUM ...
    80005af0:	6798                	ld	a4,8(a5)
    80005af2:	00275783          	lhu	a5,2(a4)
    80005af6:	2785                	addiw	a5,a5,1
    80005af8:	00f71123          	sh	a5,2(a4)
    80005afc:	0ff0000f          	fence

  io_fence();

  *R(VIRTIO_MMIO_QUEUE_NOTIFY) = 0; // value is queue number
    80005b00:	100017b7          	lui	a5,0x10001
    80005b04:	0407a823          	sw	zero,80(a5) # 10001050 <_entry-0x6fffefb0>

  // Wait for virtio_disk_intr() to say request has finished.
  while (b->disk == 1) {
    80005b08:	0049a783          	lw	a5,4(s3)
    sleep_prepare(b);
    release(&disk.vdisk_lock);
    80005b0c:	0001e497          	auipc	s1,0x1e
    80005b10:	b2c48493          	addi	s1,s1,-1236 # 80023638 <disk+0x128>
  while (b->disk == 1) {
    80005b14:	892e                	mv	s2,a1
    80005b16:	02b79163          	bne	a5,a1,80005b38 <virtio_disk_rw+0x1d2>
    sleep_prepare(b);
    80005b1a:	854e                	mv	a0,s3
    80005b1c:	bf6fc0ef          	jal	80001f12 <sleep_prepare>
    release(&disk.vdisk_lock);
    80005b20:	8526                	mv	a0,s1
    80005b22:	94efb0ef          	jal	80000c70 <release>
    sleep();
    80005b26:	c28fc0ef          	jal	80001f4e <sleep>
    acquire(&disk.vdisk_lock);
    80005b2a:	8526                	mv	a0,s1
    80005b2c:	8bcfb0ef          	jal	80000be8 <acquire>
  while (b->disk == 1) {
    80005b30:	0049a783          	lw	a5,4(s3)
    80005b34:	ff2783e3          	beq	a5,s2,80005b1a <virtio_disk_rw+0x1b4>
  }

  disk.info[idx[0]].b = 0;
    80005b38:	fa042903          	lw	s2,-96(s0)
    80005b3c:	00491713          	slli	a4,s2,0x4
    80005b40:	02070713          	addi	a4,a4,32
    80005b44:	0001e797          	auipc	a5,0x1e
    80005b48:	9cc78793          	addi	a5,a5,-1588 # 80023510 <disk>
    80005b4c:	97ba                	add	a5,a5,a4
    80005b4e:	0007b423          	sd	zero,8(a5)
    int flag = disk.desc[i].flags;
    80005b52:	0001e997          	auipc	s3,0x1e
    80005b56:	9be98993          	addi	s3,s3,-1602 # 80023510 <disk>
    80005b5a:	00491713          	slli	a4,s2,0x4
    80005b5e:	0009b783          	ld	a5,0(s3)
    80005b62:	97ba                	add	a5,a5,a4
    80005b64:	00c7d483          	lhu	s1,12(a5)
    int nxt = disk.desc[i].next;
    80005b68:	854a                	mv	a0,s2
    80005b6a:	00e7d903          	lhu	s2,14(a5)
    free_desc(i);
    80005b6e:	bbbff0ef          	jal	80005728 <free_desc>
    if (flag & VRING_DESC_F_NEXT)
    80005b72:	8885                	andi	s1,s1,1
    80005b74:	f0fd                	bnez	s1,80005b5a <virtio_disk_rw+0x1f4>
  free_chain(idx[0]);

  release(&disk.vdisk_lock);
    80005b76:	0001e517          	auipc	a0,0x1e
    80005b7a:	ac250513          	addi	a0,a0,-1342 # 80023638 <disk+0x128>
    80005b7e:	8f2fb0ef          	jal	80000c70 <release>
}
    80005b82:	60e6                	ld	ra,88(sp)
    80005b84:	6446                	ld	s0,80(sp)
    80005b86:	64a6                	ld	s1,72(sp)
    80005b88:	6906                	ld	s2,64(sp)
    80005b8a:	79e2                	ld	s3,56(sp)
    80005b8c:	7a42                	ld	s4,48(sp)
    80005b8e:	7aa2                	ld	s5,40(sp)
    80005b90:	7b02                	ld	s6,32(sp)
    80005b92:	6be2                	ld	s7,24(sp)
    80005b94:	6c42                	ld	s8,16(sp)
    80005b96:	6125                	addi	sp,sp,96
    80005b98:	8082                	ret

0000000080005b9a <virtio_disk_intr>:

void
virtio_disk_intr()
{
    80005b9a:	1101                	addi	sp,sp,-32
    80005b9c:	ec06                	sd	ra,24(sp)
    80005b9e:	e822                	sd	s0,16(sp)
    80005ba0:	e426                	sd	s1,8(sp)
    80005ba2:	1000                	addi	s0,sp,32
  acquire(&disk.vdisk_lock);
    80005ba4:	0001e497          	auipc	s1,0x1e
    80005ba8:	96c48493          	addi	s1,s1,-1684 # 80023510 <disk>
    80005bac:	0001e517          	auipc	a0,0x1e
    80005bb0:	a8c50513          	addi	a0,a0,-1396 # 80023638 <disk+0x128>
    80005bb4:	834fb0ef          	jal	80000be8 <acquire>
  // we've seen this interrupt, which the following line does.
  // this may race with the device writing new entries to
  // the "used" ring, in which case we may process the new
  // completion entries in this interrupt, and have nothing to do
  // in the next interrupt, which is harmless.
  *R(VIRTIO_MMIO_INTERRUPT_ACK) = *R(VIRTIO_MMIO_INTERRUPT_STATUS) & 0x3;
    80005bb8:	100017b7          	lui	a5,0x10001
    80005bbc:	53bc                	lw	a5,96(a5)
    80005bbe:	8b8d                	andi	a5,a5,3
    80005bc0:	10001737          	lui	a4,0x10001
    80005bc4:	d37c                	sw	a5,100(a4)
    80005bc6:	0ff0000f          	fence
  io_fence();

  // the device increments disk.used->idx when it
  // adds an entry to the used ring.

  while (disk.used_idx != disk.used->idx) {
    80005bca:	689c                	ld	a5,16(s1)
    80005bcc:	0204d703          	lhu	a4,32(s1)
    80005bd0:	0027d783          	lhu	a5,2(a5) # 10001002 <_entry-0x6fffeffe>
    80005bd4:	04f70863          	beq	a4,a5,80005c24 <virtio_disk_intr+0x8a>
    80005bd8:	0ff0000f          	fence
    io_fence();
    int id = disk.used->ring[disk.used_idx % NUM].id;
    80005bdc:	6898                	ld	a4,16(s1)
    80005bde:	0204d783          	lhu	a5,32(s1)
    80005be2:	8b9d                	andi	a5,a5,7
    80005be4:	078e                	slli	a5,a5,0x3
    80005be6:	97ba                	add	a5,a5,a4
    80005be8:	43dc                	lw	a5,4(a5)

    if (disk.info[id].status != 0)
    80005bea:	00479713          	slli	a4,a5,0x4
    80005bee:	02070713          	addi	a4,a4,32 # 10001020 <_entry-0x6fffefe0>
    80005bf2:	9726                	add	a4,a4,s1
    80005bf4:	01074703          	lbu	a4,16(a4)
    80005bf8:	e329                	bnez	a4,80005c3a <virtio_disk_intr+0xa0>
      panic("virtio_disk_intr status");

    struct buf *b = disk.info[id].b;
    80005bfa:	0792                	slli	a5,a5,0x4
    80005bfc:	02078793          	addi	a5,a5,32
    80005c00:	97a6                	add	a5,a5,s1
    80005c02:	6788                	ld	a0,8(a5)
    b->disk = 0; // disk is done with buf
    80005c04:	00052223          	sw	zero,4(a0)
    wakeup(b);
    80005c08:	b76fc0ef          	jal	80001f7e <wakeup>

    disk.used_idx += 1;
    80005c0c:	0204d783          	lhu	a5,32(s1)
    80005c10:	2785                	addiw	a5,a5,1
    80005c12:	17c2                	slli	a5,a5,0x30
    80005c14:	93c1                	srli	a5,a5,0x30
    80005c16:	02f49023          	sh	a5,32(s1)
  while (disk.used_idx != disk.used->idx) {
    80005c1a:	6898                	ld	a4,16(s1)
    80005c1c:	00275703          	lhu	a4,2(a4)
    80005c20:	faf71ce3          	bne	a4,a5,80005bd8 <virtio_disk_intr+0x3e>
  }

  release(&disk.vdisk_lock);
    80005c24:	0001e517          	auipc	a0,0x1e
    80005c28:	a1450513          	addi	a0,a0,-1516 # 80023638 <disk+0x128>
    80005c2c:	844fb0ef          	jal	80000c70 <release>
}
    80005c30:	60e2                	ld	ra,24(sp)
    80005c32:	6442                	ld	s0,16(sp)
    80005c34:	64a2                	ld	s1,8(sp)
    80005c36:	6105                	addi	sp,sp,32
    80005c38:	8082                	ret
      panic("virtio_disk_intr status");
    80005c3a:	00002517          	auipc	a0,0x2
    80005c3e:	af650513          	addi	a0,a0,-1290 # 80007730 <etext+0x730>
    80005c42:	bf3fa0ef          	jal	80000834 <panic>
	...

0000000080006000 <_trampoline>:
    80006000:	14051073          	csrw	sscratch,a0
    80006004:	02000537          	lui	a0,0x2000
    80006008:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    8000600a:	0536                	slli	a0,a0,0xd
    8000600c:	02153423          	sd	ra,40(a0)
    80006010:	02253823          	sd	sp,48(a0)
    80006014:	02353c23          	sd	gp,56(a0)
    80006018:	04453023          	sd	tp,64(a0)
    8000601c:	04553423          	sd	t0,72(a0)
    80006020:	04653823          	sd	t1,80(a0)
    80006024:	04753c23          	sd	t2,88(a0)
    80006028:	f120                	sd	s0,96(a0)
    8000602a:	f524                	sd	s1,104(a0)
    8000602c:	fd2c                	sd	a1,120(a0)
    8000602e:	e150                	sd	a2,128(a0)
    80006030:	e554                	sd	a3,136(a0)
    80006032:	e958                	sd	a4,144(a0)
    80006034:	ed5c                	sd	a5,152(a0)
    80006036:	0b053023          	sd	a6,160(a0)
    8000603a:	0b153423          	sd	a7,168(a0)
    8000603e:	0b253823          	sd	s2,176(a0)
    80006042:	0b353c23          	sd	s3,184(a0)
    80006046:	0d453023          	sd	s4,192(a0)
    8000604a:	0d553423          	sd	s5,200(a0)
    8000604e:	0d653823          	sd	s6,208(a0)
    80006052:	0d753c23          	sd	s7,216(a0)
    80006056:	0f853023          	sd	s8,224(a0)
    8000605a:	0f953423          	sd	s9,232(a0)
    8000605e:	0fa53823          	sd	s10,240(a0)
    80006062:	0fb53c23          	sd	s11,248(a0)
    80006066:	11c53023          	sd	t3,256(a0)
    8000606a:	11d53423          	sd	t4,264(a0)
    8000606e:	11e53823          	sd	t5,272(a0)
    80006072:	11f53c23          	sd	t6,280(a0)
    80006076:	140022f3          	csrr	t0,sscratch
    8000607a:	06553823          	sd	t0,112(a0)
    8000607e:	00853103          	ld	sp,8(a0)
    80006082:	02053203          	ld	tp,32(a0)
    80006086:	01053283          	ld	t0,16(a0)
    8000608a:	00053303          	ld	t1,0(a0)
    8000608e:	12000073          	sfence.vma
    80006092:	18031073          	csrw	satp,t1
    80006096:	12000073          	sfence.vma
    8000609a:	9282                	jalr	t0

000000008000609c <userret>:
    8000609c:	0000100f          	fence.i
    800060a0:	12000073          	sfence.vma
    800060a4:	18051073          	csrw	satp,a0
    800060a8:	12000073          	sfence.vma
    800060ac:	02000537          	lui	a0,0x2000
    800060b0:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    800060b2:	0536                	slli	a0,a0,0xd
    800060b4:	02853083          	ld	ra,40(a0)
    800060b8:	03053103          	ld	sp,48(a0)
    800060bc:	03853183          	ld	gp,56(a0)
    800060c0:	04053203          	ld	tp,64(a0)
    800060c4:	04853283          	ld	t0,72(a0)
    800060c8:	05053303          	ld	t1,80(a0)
    800060cc:	05853383          	ld	t2,88(a0)
    800060d0:	7120                	ld	s0,96(a0)
    800060d2:	7524                	ld	s1,104(a0)
    800060d4:	7d2c                	ld	a1,120(a0)
    800060d6:	6150                	ld	a2,128(a0)
    800060d8:	6554                	ld	a3,136(a0)
    800060da:	6958                	ld	a4,144(a0)
    800060dc:	6d5c                	ld	a5,152(a0)
    800060de:	0a053803          	ld	a6,160(a0)
    800060e2:	0a853883          	ld	a7,168(a0)
    800060e6:	0b053903          	ld	s2,176(a0)
    800060ea:	0b853983          	ld	s3,184(a0)
    800060ee:	0c053a03          	ld	s4,192(a0)
    800060f2:	0c853a83          	ld	s5,200(a0)
    800060f6:	0d053b03          	ld	s6,208(a0)
    800060fa:	0d853b83          	ld	s7,216(a0)
    800060fe:	0e053c03          	ld	s8,224(a0)
    80006102:	0e853c83          	ld	s9,232(a0)
    80006106:	0f053d03          	ld	s10,240(a0)
    8000610a:	0f853d83          	ld	s11,248(a0)
    8000610e:	10053e03          	ld	t3,256(a0)
    80006112:	10853e83          	ld	t4,264(a0)
    80006116:	11053f03          	ld	t5,272(a0)
    8000611a:	11853f83          	ld	t6,280(a0)
    8000611e:	7928                	ld	a0,112(a0)
    80006120:	10200073          	sret
	...
